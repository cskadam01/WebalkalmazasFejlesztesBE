package hu.digitalis.alairas

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject

/**
 * Natív SQLite: két fő tábla (projektek + aláírások), egy minimális technikai napló.
 * Minden aláíró MINDEN kitölthető mezője egyetlen titkosított JSON/BLOB rekordban van.
 * A naplóban nincs név, cím, e-mail, telefon vagy kézírásos kép.
 * Az új mezők JSON-ban kompatibilisen bővíthetők; sémamigráció szükséges módosításkor.
 */
class PetitionStore(ctx: Context, private val cipher: RecordCipher) :
    SQLiteOpenHelper(ctx, "digitalis_alairas.db", null, 1) {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE campaigns (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           payload BLOB NOT NULL,
           created_at INTEGER NOT NULL,
           updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE signatures (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
           payload BLOB NOT NULL,
           signature_png BLOB NOT NULL,
           created_at INTEGER NOT NULL,
           updated_at INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX idx_signatures_campaign ON signatures(campaign_id)")
        db.execSQL("""CREATE TABLE audit (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           at INTEGER NOT NULL, action TEXT NOT NULL,
           campaign_id INTEGER NOT NULL, signature_id INTEGER
        )""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // Soha nem töröljük az éles adatokat automatikusan egy verzióváltás során.
        error("Nincs adatvesztésmentes migráció $oldVersion → $newVersion verzióra")
    }

    private fun audit(db: SQLiteDatabase, action: String, cid: Long, sid: Long? = null) {
        val cv = ContentValues().apply {
            put("at", System.currentTimeMillis()); put("action", action)
            put("campaign_id", cid); if (sid == null) putNull("signature_id") else put("signature_id", sid)
        }
        db.insertOrThrow("audit", null, cv)
    }

    fun saveCampaign(c: Campaign): Long {
        val now = System.currentTimeMillis()
        val cv = ContentValues().apply {
            put("payload", cipher.encryptText(c.toJson().toString())); put("updated_at", now)
        }
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = if (c.id == 0L) {
                cv.put("created_at", now); db.insertOrThrow("campaigns", null, cv)
            } else {
                check(db.update("campaigns", cv, "id=?", arrayOf(c.id.toString())) == 1)
                c.id
            }
            audit(db, if (c.id == 0L) "CAMPAIGN_CREATE" else "CAMPAIGN_EDIT", id)
            db.setTransactionSuccessful(); id
        } finally { db.endTransaction() }
    }

    fun campaigns(): List<Campaign> {
        val result = arrayListOf<Campaign>()
        readableDatabase.rawQuery("SELECT id,payload FROM campaigns ORDER BY id DESC", null).use { cur ->
            while (cur.moveToNext()) {
                result.add(Campaign.fromJson(cur.getLong(0),
                    JSONObject(cipher.decryptText(cur.getBlob(1)))))
            }
        }
        return result
    }

    fun campaign(id: Long): Campaign? = campaigns().firstOrNull { it.id == id }

    fun saveSigner(s: Signer): Long {
        require(s.fullName.isNotBlank() && s.privacyRead && s.explicitConsent && s.signaturePng.isNotEmpty())
        val now = System.currentTimeMillis()
        val cv = ContentValues().apply {
            put("campaign_id", s.campaignId)
            put("payload", cipher.encryptText(s.toJson().toString()))
            put("signature_png", cipher.encrypt(s.signaturePng))
            put("updated_at", now)
        }
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = if (s.id == 0L) {
                cv.put("created_at", now); db.insertOrThrow("signatures", null, cv)
            } else {
                check(db.update("signatures", cv, "id=?", arrayOf(s.id.toString())) == 1)
                s.id
            }
            audit(db, if (s.id == 0L) "SIGN" else "RESIGN_EDIT", s.campaignId, id)
            db.setTransactionSuccessful(); id
        } finally { db.endTransaction() }
    }

    fun signers(campaignId: Long): List<Signer> {
        val list = arrayListOf<Signer>()
        readableDatabase.rawQuery("""SELECT id,payload,signature_png,created_at,updated_at
            FROM signatures WHERE campaign_id=? ORDER BY id DESC""",
            arrayOf(campaignId.toString())).use { cur ->
            while (cur.moveToNext()) {
                list.add(Signer.fromJson(cur.getLong(0), campaignId,
                    JSONObject(cipher.decryptText(cur.getBlob(1))),
                    cipher.decrypt(cur.getBlob(2)), cur.getLong(3), cur.getLong(4)))
            }
        }
        return list
    }

    fun signer(campaignId: Long, signerId: Long): Signer? =
        signers(campaignId).firstOrNull { it.id == signerId }

    /**
     * Auditnapló: a készüléken létrehozott exporttény, címzett és személyes adat nélkül.
     * A tényleges küldést a külső Android-alkalmazás végzi, ezért azt itt nem állítjuk.
     */
    fun recordPreparedExport(campaignId: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            audit(db, "ENCRYPTED_EXPORT_PREPARED", campaignId)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun removeSigner(s: Signer) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("signatures", "id=? AND campaign_id=?",
                arrayOf(s.id.toString(), s.campaignId.toString()))
            audit(db, "SIGNATURE_DELETE", s.campaignId, s.id)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun removeCampaign(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("campaigns", "id=?", arrayOf(id.toString()))
            audit(db, "CAMPAIGN_DELETE_WITH_RECORDS", id)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

package hu.digitalis.alairas

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.BitmapFactory
import android.graphics.Color
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

/**
 * Kotlin, natív Android UI, telefonon és tableten fut.
 *
 * Képernyők:
 *  - helyi PIN belépés
 *  - kampány/projekt lista és létrehozás
 *  - projekten belüli aláíráslista, szerkesztés/törlés/keresés
 *  - adatlap: diktálás (élő részeredmények), ellenőrizhető mezők,
 *    külön hozzájárulások és érintőképernyős aláírás
 *
 * Ez technikai DEMÓ: nem választási ajánlóív és nem QES e-aláírás.
 */
class MainActivity : Activity() {
    private val green = Color.rgb(36, 110, 62)
    private val charcoal = Color.rgb(39, 51, 43)
    private val warning = Color.rgb(145, 77, 18)
    private val faint = Color.rgb(243, 247, 242)
    private lateinit var store: PetitionStore
    private lateinit var pinGate: PinGate
    private lateinit var speech: OfflineSpeech
    private lateinit var exporter: ExportShare
    private var screen: String = "AUTH"
    private var openCampaign: Long? = null
    private var voiceEdit: EditText? = null
    private var voiceStatus: TextView? = null
    private var lastBackgroundAt: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Képernyőmentés/előnézeti kép tiltása, mert politikai jellegű személyes adat látható.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = Color.rgb(32, 91, 52)
        pinGate = PinGate(this)
        speech = OfflineSpeech(this)
        exporter = ExportShare(this)
        exporter.cleanExpired() // korábbi, átmeneti csatolmányok eltávolítása
        try {
            store = PetitionStore(this, RecordCipher())
            showAuth()
        } catch (e: Exception) {
            showError("A titkosítás nem indítható: ${e.message}")
        }
    }

    override fun onStop() {
        // Ha a felhasználó elhagyta az appot, a mikrofonos felismerést leállítjuk.
        speech.stop()
        lastBackgroundAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        // 60 másodperc háttérben töltött idő után ismét PIN szükséges.
        if (lastBackgroundAt > 0 &&
            System.currentTimeMillis() - lastBackgroundAt > 60_000L &&
            screen != "AUTH" && ::store.isInitialized) {
            showAuth()
        }
        lastBackgroundAt = 0L
    }

    override fun onDestroy() {
        speech.stop()
        super.onDestroy()
    }

    @Deprecated("Legacy back handling")
    override fun onBackPressed() {
        speech.stop()
        when (screen) {
            "ENTRY", "CAMPAIGN_EDIT" -> openCampaign?.let { showCampaign(it) } ?: showCampaigns()
            "CAMPAIGN" -> showCampaigns()
            else -> super.onBackPressed()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(16), dp(18), dp(24))
        setBackgroundColor(Color.WHITE)
    }

    private fun page(layout: LinearLayout) {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            addView(layout)
        }
        setContentView(scroll)
    }

    private fun heading(parent: LinearLayout, title: String) {
        parent.addView(TextView(this).apply {
            text = title; textSize = 24f
            setTextColor(charcoal)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setPadding(0, dp(8), 0, dp(13))
        })
    }

    private fun label(parent: LinearLayout, value: String, bold: Boolean = false,
                      isWarning: Boolean = false): TextView {
        return TextView(this).also { t ->
            t.text = value; t.textSize = if (bold) 16f else 14f
            t.setTextColor(if (isWarning) warning else charcoal)
            if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            t.setPadding(0, dp(6), 0, dp(6))
            parent.addView(t)
        }
    }

    private fun button(parent: LinearLayout, title: String, action: () -> Unit): Button {
        return Button(this).also { b ->
            b.text = title; b.isAllCaps = false
            b.setTextColor(green)
            parent.addView(b, LinearLayout.LayoutParams(-1, dp(54)).apply {
                bottomMargin = dp(5)
            })
            b.setOnClickListener { action() }
        }
    }

    private fun input(parent: LinearLayout, caption: String, value: String = "",
                      kind: Int = InputType.TYPE_CLASS_TEXT, multi: Boolean = false): EditText {
        label(parent, caption, true)
        return EditText(this).also { e ->
            e.setSingleLine(!multi)
            e.inputType = if (multi) InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                else kind
            e.setText(value)
            e.setTextSize(16f)
            e.setPadding(dp(10), dp(8), dp(10), dp(8))
            if (multi) e.minLines = 3
            parent.addView(e, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(10)
            })
        }
    }

    private fun check(parent: LinearLayout, title: String, value: Boolean = false): CheckBox {
        return CheckBox(this).also { cb ->
            cb.text = title; cb.isChecked = value
            cb.textSize = 15f; cb.setTextColor(charcoal)
            cb.setPadding(0, dp(5), 0, dp(5))
            parent.addView(cb)
        }
    }

    private fun brand(parent: LinearLayout) {
        val im = ImageView(this).apply {
            setImageResource(R.drawable.mi_hazank)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }
        parent.addView(im, LinearLayout.LayoutParams(-1, dp(104)).apply { bottomMargin = dp(6) })
    }

    private fun showError(message: String) {
        val l = column()
        heading(l, "Az alkalmazás nem indítható")
        label(l, message, isWarning = true)
        page(l)
    }

    /** 6+ számjegyes helyi PIN létrehozása vagy bekérése; nincs hálózati bejelentkezés. */
    private fun showAuth() {
        screen = "AUTH"
        val root = column()
        brand(root)
        heading(root, "Digitális aláírásgyűjtő")
        label(root, "Helyi, titkosított kampányadatbázis. A próbaalkalmazás nem küld adatot az internetre.")
        val isNew = !pinGate.isConfigured()
        label(root, if (isNew) "Első indítás: legalább 6 számjegyű PIN beállítása" else "Belépés a korábban beállított PIN-kóddal", true)
        val code = input(root, "PIN", kind = InputType.TYPE_CLASS_NUMBER or
            InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val confirm = if (isNew) input(root, "PIN megismétlése", kind =
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD) else null
        button(root, if (isNew) "PIN mentése" else "Feloldás") {
            val text = code.text.toString()
            if (isNew) {
                if (text.length < 6 || text.any { !it.isDigit() }) {
                    toast("Legalább 6 számjegy szükséges")
                } else if (text != confirm?.text.toString()) {
                    toast("A két PIN nem egyezik")
                } else {
                    try { pinGate.register(text); afterAuth() }
                    catch (e: Exception) { toast("Nem sikerült: ${e.message}") }
                }
            } else if (pinGate.verify(text)) afterAuth()
            else toast(if (pinGate.isBlocked())
                "Túl sok sikertelen próbálkozás; 15 percig zárolva."
                else "Hibás PIN")
        }
        label(root, "Fontos: ez demonstrációs kiadás. Az éles adatkezeléshez külön jóváhagyás és biztonsági ellenőrzés szükséges.", isWarning = true)
        page(root)
    }

    private fun afterAuth() {
        try {
            val prefs = getSharedPreferences("app_state", MODE_PRIVATE)
            if (!prefs.getBoolean("seeded_v1", false)) {
                // A PDF fejlécéből vett MINTA kampány; nem kerülnek be a beszkennelt aláírók.
                store.saveCampaign(Campaign(
                    title = "STOP Palagáz!",
                    description = "Ne engedjük, hogy hidraulikus rétegrepesztéssel fúrjanak " +
                        "nemzetközi óriásvállalatok a vízszegény Homokhátságon a profitjuk " +
                        "érdekében, veszélyeztetve a felelős szénhidrogén-gazdálkodást és a vízkészletet!",
                    privacyNotice = "DEMO. A valódi adatkezelő által jóváhagyott, teljes " +
                        "adatkezelési tájékoztatót itt kell megjeleníteni. Ne gyűjtsön valós " +
                        "személyes adatot, amíg az adatkezelési feltételek nincsenek rendezve."
                ))
                prefs.edit().putBoolean("seeded_v1", true).apply()
            }
            showCampaigns()
        } catch (e: Exception) { showError("Adatbázishiba: ${e.message}") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun confirm(title: String, message: String, action: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setNegativeButton("Mégse", null)
            .setPositiveButton("Igen") { _, _ -> action() }
            .show()
    }

    private fun showCampaigns() {
        speech.stop(); screen = "PROJECTS"; openCampaign = null
        val root = column()
        brand(root)
        heading(root, "Aláírásgyűjtő projektek")
        label(root, "Válasszon egy kampányt, vagy hozzon létre új gyűjtést. Minden projektnek saját szövege és saját adatkezelési tájékoztatója van.")
        button(root, "+ Új projekt") { showCampaignEditor(null) }
        try {
            store.campaigns().forEach { c ->
                val count = store.signers(c.id).size
                button(root, "${c.title}  •  $count aláírás") { showCampaign(c.id) }
            }
        } catch (e: Exception) { label(root, "Betöltési hiba: ${e.message}", isWarning = true) }
        label(root, "A készülékhez kötött titkosítókulcs miatt az adatbázis egyszerű átmásolással nem olvasható más készüléken.", isWarning = true)
        page(root)
    }

    /** A projektszerkesztő biztosítja a felhasználó által kért tetszőleges kampányokat. */
    private fun showCampaignEditor(existing: Campaign?) {
        screen = "CAMPAIGN_EDIT"; openCampaign = existing?.id
        val root = column()
        heading(root, if (existing == null) "Új projekt" else "Projekt szerkesztése")
        val title = input(root, "Kampány címe *", existing?.title.orEmpty())
        val desc = input(root, "Rövid kampányleírás", existing?.description.orEmpty(), multi = true)
        label(root, "Adatvédelmi beállítások", true)
        val controller = input(root, "Adatkezelő teljes neve / szervezete",
            existing?.controller.orEmpty())
        val contact = input(root, "Adatvédelmi kapcsolattartási elérhetőség",
            existing?.contact.orEmpty())
        val privacy = input(root, "Jóváhagyott adatkezelési tájékoztató (teljes szöveg)",
            existing?.privacyNotice.orEmpty(), multi = true)
        val policy = input(root, "Tájékoztató verziója", existing?.policyVersion ?: "1.0")
        val retention = input(root, "Megőrzési idő (nap; jogilag jóváhagyandó)",
            (existing?.retentionDays ?: 180).toString(), InputType.TYPE_CLASS_NUMBER)
        val ready = check(root,
            "Az adatkezelő jóváhagyta a szövegeket és az éles adatgyűjtést.",
            existing?.approvedForRealData ?: false)
        label(root, "A pipa nem helyettesíti az adatvédelmi ellenőrzést, és nem automatikus GDPR-megfelelőségi igazolás.", isWarning = true)
        button(root, "Projekt mentése") {
            val days = retention.text.toString().toIntOrNull()
            if (title.text.isBlank() || days == null || days <= 0) {
                toast("Cím és pozitív megőrzési idő szükséges"); return@button
            }
            val data = Campaign(existing?.id ?: 0, title.text.toString().trim(),
                desc.text.toString().trim(), controller.text.toString().trim(),
                contact.text.toString().trim(), privacy.text.toString().trim(),
                policy.text.toString().trim(), days, ready.isChecked)
            if (ready.isChecked && !data.isReadyForRealData()) {
                toast("Éles mód: adatkezelő, kapcsolat, legalább 120 karakteres tájékoztató és megőrzési idő szükséges")
                return@button
            }
            try {
                val id = store.saveCampaign(data)
                showCampaign(id)
            } catch (e: Exception) { toast("Nem menthető: ${e.message}") }
        }
        if (existing != null) {
            button(root, "Projekt és aláírásai törlése") {
                confirm("Projekt végleges törlése",
                    "A(z) ${existing.title} projekt MINDEN aláírását is véglegesen törli. Folytatja?") {
                    try { store.removeCampaign(existing.id); showCampaigns() }
                    catch (e: Exception) { toast("Törlési hiba: ${e.message}") }
                }
            }
        }
        button(root, "Vissza") {
            if (existing == null) showCampaigns() else showCampaign(existing.id)
        }
        page(root)
    }

    private fun showCampaign(id: Long) {
        speech.stop(); screen = "CAMPAIGN"; openCampaign = id
        val campaign = store.campaign(id)
        if (campaign == null) { showCampaigns(); return }
        val root = column()
        brand(root)
        heading(root, campaign.title)
        label(root, campaign.description)
        if (!campaign.isReadyForRealData())
            label(root, "DEMO PROJEKT — kizárólag fiktív tesztadatokkal használható. Az éles használatot a projektszerkesztőben kell jóváhagyni.", isWarning = true)
        button(root, "+ Új aláírás rögzítése") { showSignerEditor(campaign, null) }
        button(root, "Projekt / leírás / adatkezelés szerkesztése") { showCampaignEditor(campaign) }
        val all = store.signers(id)
        label(root, "Mentett aláírások: ${all.size}", true)
        label(root, "Kérdőívek táblázatban – megosztás / e-mail", true)
        button(root, "Üres kérdőív megosztása (Excel CSV)") {
            try {
                val file = exporter.createBlankTemplate(campaign)
                exporter.openShareSheet(file, "text/csv", "Üres kérdőív – ${campaign.title}",
                    "A melléklet a kampány személyes adatokat nem tartalmazó, " +
                        "szerkeszthető táblázatsablonja.")
            } catch (e: Exception) { toast("Sablon megosztási hiba: ${e.message}") }
        }
        button(root, "Kitöltött adatlapok megosztása (AES-256 ZIP)") {
            showEncryptedShareDialog(campaign, all)
        }
        val search = input(root, "Keresés név vagy település szerint")
        val resultList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resultList)

        fun render(q: String) {
            resultList.removeAllViews()
            val matching = all.filter {
                it.fullName.contains(q, true) || it.city.contains(q, true)
            }
            if (matching.isEmpty()) label(resultList, "Nincs találat.")
            matching.forEach { s ->
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    setBackgroundColor(faint)
                }
                resultList.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(9)
                })
                label(box, s.fullName, true)
                label(box, listOf(s.postalCode, s.city).filter { it.isNotBlank() }
                    .joinToString(" ") + " • " +
                    DateFormat.getDateTimeInstance().format(Date(s.signedAt)))
                button(box, "Megtekintés / javítás (új aláírással)") {
                    showSignerEditor(campaign, s)
                }
                button(box, "Aláírás törlése") {
                    confirm("Aláírás törlése", "Törli a kiválasztott aláírást? A művelet nem vonható vissza.") {
                        try { store.removeSigner(s); showCampaign(id) }
                        catch (e: Exception) { toast("Törlési hiba: ${e.message}") }
                    }
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        render("")
        button(root, "Vissza a projektekhez") { showCampaigns() }
        page(root)
    }

    /**
     * A kitöltött adatlapok politikai véleményre utalhatnak: ezért NEM küldünk
     * nyitott CSV-t emailben. Erős ZIP-jelszót kérünk, és külön jogszerűségi
     * ellenőrzésre figyelmeztetünk. A jelszó sosem kerül az email szövegébe.
     */
    private fun showEncryptedShareDialog(campaign: Campaign, signers: List<Signer>) {
        if (signers.isEmpty()) {
            toast("Ebben a projektben még nincs exportálható adatlap")
            return
        }
        val content = column()
        label(content, "A csatolmány tartalmazza a neveket, elérhetőségeket, " +
            "címeket, hozzájárulásokat és az aláírások PNG-képeit.", isWarning = true)
        label(content, "A fájl AES-256-tal titkosított ZIP lesz. A megnyitáshoz " +
            "7-Zip vagy más AES-ZIP-kompatibilis program szükséges. " +
            "A jelszót másik, biztonságos csatornán közölje a címzettel.")
        val pass = input(content, "ZIP-jelszó (legalább 14 karakter)", kind =
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val repeat = input(content, "ZIP-jelszó megismétlése", kind =
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD)
        val authorized = check(content,
            "Jogosult vagyok a kiválasztott személyes adatok átadására a címzettnek.")
        val dialog = AlertDialog.Builder(this)
            .setTitle("Biztonságos, táblázatos adatmegosztás")
            .setView(ScrollView(this).apply { addView(content) })
            .setNegativeButton("Mégse", null)
            .setPositiveButton("Titkosított ZIP készítése", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!authorized.isChecked) {
                    toast("Az adatátadás jogosultságát igazolni kell")
                    return@setOnClickListener
                }
                val value = pass.text.toString()
                if (value.length < 14 || value != repeat.text.toString()) {
                    toast("Legalább 14 karakteres, kétszer azonos jelszó szükséges")
                    return@setOnClickListener
                }
                try {
                    val chars = value.toCharArray()
                    val file = try {
                        exporter.createEncryptedArchive(campaign, signers, chars)
                    } finally { chars.fill('\u0000') }
                    try { store.recordPreparedExport(campaign.id) } catch (error: Exception) {
                        file.delete() // audit nélkül személyesadat-export nem adható át
                        throw error
                    }
                    dialog.dismiss()
                    exporter.openShareSheet(
                        file, "application/zip", "Titkosított adatlapok – ${campaign.title}",
                        "A mellékelt ZIP titkosított táblázatot és aláírásképeket " +
                            "tartalmaz. A jelszót külön, biztonságos csatornán küldöm."
                    )
                } catch (e: Exception) {
                    toast("Titkosított export hiba: ${e.message}")
                }
            }
        }
        dialog.show()
    }

    /** Mikrofonos adatmező, a részeredmény azonnal ugyanabba az EditText-be kerül. */
    private fun dictatedInput(parent: LinearLayout, title: String, initial: String,
                              kind: Int = InputType.TYPE_CLASS_TEXT): EditText {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        parent.addView(row)
        val name = TextView(this).apply {
            text = title; textSize = 15f; setTextColor(charcoal)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }
        row.addView(name, LinearLayout.LayoutParams(0, -2, 1f))
        val ed = EditText(this).apply {
            setSingleLine(true); inputType = kind
            setText(initial); setTextSize(16f)
        }
        val mic = Button(this).apply { text = "🎤"; contentDescription = "$title diktálása" }
        row.addView(mic, LinearLayout.LayoutParams(dp(62), dp(52)))
        parent.addView(ed, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        mic.setOnClickListener { startVoice(ed) }
        return ed
    }

    private fun startVoice(target: EditText) {
        if (!speech.available()) {
            toast("Nincs helyi magyar beszédfelismerő. Diktálás helyett használjon billentyűzetet.")
            return
        }
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceEdit = target
            requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 400)
            return
        }
        speech.start({ words ->
            target.setText(words)
            target.setSelection(target.text.length)
        }, { status ->
            voiceStatus?.text = status
        })
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                           permissions: Array<out String>,
                                           grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 400) {
            val saved = voiceEdit
            voiceEdit = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && saved != null)
                startVoice(saved)
            else toast("A mikrofon engedélye nélkül billentyűzettel tölthető ki a mező.")
        }
    }

    private fun showSignerEditor(campaign: Campaign, old: Signer?) {
        speech.stop(); screen = "ENTRY"; openCampaign = campaign.id
        val root = column()
        heading(root, if (old == null) "Új digitális aláírás" else "Adatok módosítása")
        label(root, campaign.title, true)
        label(root, campaign.description)
        if (!campaign.isReadyForRealData())
            label(root, "DEMO — CSAK KITALÁLT SZEMÉLYES ADATOKKAL TESZTELJE!", true, true)
        label(root, "Adatok felvétele billentyűzettel vagy mezőnkénti mikrofonos diktálással. A felismerés azonnal szerkeszthető.")
        voiceStatus = label(root, "Mikrofon: csak eszközön futó felismerést használunk.")
        val name = dictatedInput(root, "Olvasható név *", old?.fullName.orEmpty())
        val email = dictatedInput(root, "E-mail-cím", old?.email.orEmpty(),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS)
        val phone = dictatedInput(root, "Mobiltelefon", old?.phone.orEmpty(),
            InputType.TYPE_CLASS_PHONE)
        val postal = dictatedInput(root, "Irányítószám", old?.postalCode.orEmpty(),
            InputType.TYPE_CLASS_NUMBER)
        val city = dictatedInput(root, "Település", old?.city.orEmpty())
        val address = dictatedInput(root, "Utca, házszám", old?.streetAddress.orEmpty())
        label(root, "Önkéntes, külön célú választások", true)
        val newsletter = check(root, "Hírlevélre feliratkozom (külön hozzájárulás)",
            old?.newsletter ?: false)
        val sympathizer = check(root, "Szimpatizánsnak jelentkezem (külön hozzájárulás)",
            old?.sympathizer ?: false)
        label(root, "Adatkezelő: ${campaign.controller.ifBlank { "NINCS MEGADVA – DEMO" }}")
        label(root, "Kapcsolat: ${campaign.contact.ifBlank { "NINCS MEGADVA – DEMO" }}")
        label(root, "Adatkezelési tájékoztató, ${campaign.policyVersion} verzió:", true)
        label(root, campaign.privacyNotice.ifBlank { "NINCS ADATKEZELÉSI TÁJÉKOZTATÓ – DEMO" })
        val readPrivacy = check(root, "Az adatkezelési tájékoztatót megismertem.")
        val explicit = check(root,
            "Kifejezetten hozzájárulok ahhoz, hogy adataimat és aláírásomat " +
                "kizárólag a fenti kampány támogatásának dokumentálásához kezeljék.")
        label(root, "Aláírás rajzolása ujjával vagy érintőtollal", true)
        if (old != null) {
            label(root, "Változtatás esetén ismét alá kell írni. A korábbi aláírás csak megtekinthető, nem vihető át változtatás nélkül.", isWarning = true)
            val bitmap = BitmapFactory.decodeByteArray(old.signaturePng, 0, old.signaturePng.size)
            if (bitmap != null) {
                root.addView(ImageView(this).apply {
                    setImageBitmap(bitmap); adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }, LinearLayout.LayoutParams(-1, dp(90)))
            }
        }
        val pad = SignaturePad(this)
        root.addView(pad, LinearLayout.LayoutParams(-1, dp(220)).apply {
            topMargin = dp(8); bottomMargin = dp(8)
        })
        button(root, "Aláírás törlése / újrarajzolás") { pad.clear() }
        button(root, "Ellenőrzött adatok és aláírás mentése") {
            speech.stop()
            if (name.text.toString().isBlank()) { toast("A név kötelező"); return@button }
            if (!readPrivacy.isChecked || !explicit.isChecked) {
                toast("A tájékoztató megismerése és a kifejezett hozzájárulás szükséges")
                return@button
            }
            if (!pad.hasNewSignature()) { toast("Kérjük az aláírás megrajzolását"); return@button }
            val mail = email.text.toString().trim()
            if (mail.isNotEmpty() && !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                toast("Az e-mail-cím hibásnak tűnik – ellenőrizze"); return@button
            }
            val save = {
                try {
                    val time = System.currentTimeMillis()
                    val signer = Signer(id = old?.id ?: 0, campaignId = campaign.id,
                        fullName = name.text.toString().trim(), email = mail,
                        phone = phone.text.toString().trim(),
                        postalCode = postal.text.toString().trim(),
                        city = city.text.toString().trim(),
                        streetAddress = address.text.toString().trim(),
                        newsletter = newsletter.isChecked,
                        sympathizer = sympathizer.isChecked,
                        privacyRead = true, explicitConsent = true,
                        policyVersion = campaign.policyVersion,
                        consentAt = time, signedAt = time,
                        signaturePng = pad.exportPng(),
                        createdAt = old?.createdAt ?: time,
                        updatedAt = time)
                    store.saveSigner(signer)
                    toast("Titkosítva mentve")
                    showCampaign(campaign.id)
                } catch (e: Exception) { toast("Mentési hiba: ${e.message}") }
            }
            if (campaign.isReadyForRealData()) save()
            else confirm("Csak DEMO adatok",
                "A kampány adatkezelési beállításai nincsenek éles használatra jóváhagyva. " +
                    "Kizárólag fiktív, tesztelési adatokat adhat meg. Biztosan tesztadatokat használ?") {
                save()
            }
        }
        button(root, "Mégse / vissza") { showCampaign(campaign.id) }
        page(root)
    }
}

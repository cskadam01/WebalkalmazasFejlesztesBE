package hu.digitalis.alairas

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Kifejezetten helyi Android SpeechRecognizer (API 31+).
 * NEM esik vissza automatikusan online felismerésre.
 * Részeredményeket azonnal visszaad a szerkeszthető mezőnek.
 * A nyers hangot nem tárolja, nem tölti fel és nem továbbítja.
 */
class OfflineSpeech(private val context: Context) {
    private var recognizer: SpeechRecognizer? = null

    fun available(): Boolean = SpeechRecognizer.isOnDeviceRecognitionAvailable(context)

    fun start(onText: (String) -> Unit, onStatus: (String) -> Unit) {
        if (!available()) {
            onStatus("A telefonon nincs helyi beszédfelismerő. Írja be kézzel, vagy telepítsen offline magyar beszédmodellt a rendszerhez.")
            return
        }
        stop()
        val sr = SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
        recognizer = sr
        sr.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) = onStatus("Beszélhet – magyar diktálás")
            override fun onBeginningOfSpeech() = onStatus("Felismerés folyamatban…")
            override fun onRmsChanged(rmsdB: Float) = Unit
            override fun onBufferReceived(buffer: ByteArray?) = Unit
            override fun onEndOfSpeech() = onStatus("Feldolgozás…")
            override fun onError(error: Int) = onStatus("Beszédfelismerési hiba ($error). Gépeléssel javítható.")
            override fun onResults(results: Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                    ?.firstOrNull()
                if (!text.isNullOrBlank()) onText(text)
                onStatus("Felismerve – szükség esetén javítsa a mezőt")
            }
            override fun onPartialResults(partialResults: Bundle?) {
                val text = partialResults
                    ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!text.isNullOrBlank()) onText(text)
            }
            override fun onEvent(eventType: Int, params: Bundle?) = Unit
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag("hu-HU").toLanguageTag())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        sr.startListening(intent)
    }

    fun stop() {
        recognizer?.cancel()
        recognizer?.destroy()
        recognizer = null
    }
}

package hu.digitalis.alairas

import java.util.Locale

/**
 * V14: Kulcsszavak nélküli, óvatos magyar adatlap-felismerés.
 * A számokat és címeket kizárólag helyben értelmezi. Nincs modell-letöltés,
 * nincs hálózati hívás, nincs automatikus adattárolás vagy hozzájárulás.
 * A kimenetet a felhasználó mindig szerkeszti / hagyja jóvá.
 */
data class SmartDictationReview(
    val fields: DictatedSignerFields,
    val uncertain: Set<String>,
    val notes: List<String>
) {
    fun summary(): String = fields.summary() + if (notes.isNotEmpty())
        "\n\nEllenőrzendő:\n" + notes.distinct().joinToString("\n") { "• $it" } else ""
    fun score(): Int = listOf(fields.name, fields.email, fields.phone, fields.postal,
        fields.city, fields.street).count { it.isNotBlank() } * 10 - uncertain.size * 2
}

object HungarianSmartDictation {
    private val hu = Locale.forLanguageTag("hu-HU")
    private val postal = Regex("(?<!\\d)[1-9]\\d{3}(?!\\d)")
    private val phone = Regex(
        "(?iu)(?<![\\d])(?:\\+\\s*36\\s*|0036\\s*|06\\s*)?" +
            "(?:(?:20|30|31|50|70)[\\s:.,\\-]*\\d{3}[\\s:.,\\-]*\\d{4}|" +
            "1[\\s:.,\\-]*\\d{3}[\\s:.,\\-]*\\d{4}|" +
            "[2-9]\\d[\\s:.,\\-]*\\d{3}[\\s:.,\\-]*\\d{3})(?!\\d)"
    )
    private val email = Regex("(?i)(?<![\\w.])[a-z0-9._%+\\-]+@[a-z0-9.\\-]+\\.[a-z]{2,}(?![\\w])")
    private val streetType = Regex("(?iu)(?<![\\p{L}])(utca|út|útja|körút|tér|tere|köz|sor|sétány|fasor|park|dűlő|rakpart)(?![\\p{L}])")
    private val wordOnly = Regex("(?iu)^[\\p{L}.'\\-]{2,35}$")
    private val noiseWords = setOf("és", "meg", "az", "a", "akkor", "hát", "kérem", "itt", "van", "pedig", "vagyok")
    private val numberOnes = mapOf("nulla" to 0, "egy" to 1, "kettő" to 2, "kettö" to 2,
        "két" to 2, "három" to 3, "négy" to 4, "öt" to 5,
        "hat" to 6, "hét" to 7, "nyolc" to 8, "kilenc" to 9)
    private val tens = listOf("kilencven" to 90, "nyolcvan" to 80, "hetven" to 70,
        "hatvan" to 60, "ötven" to 50, "negyven" to 40, "harminc" to 30,
        "huszon" to 20, "húsz" to 20, "tizen" to 10, "tíz" to 10)
    private val ignoreName = setOf("nevem", "név", "teljes", "én", "dr", "dr.", "kedves")
    private val labelPrefix = Regex("(?iu)^(?:az?\\s+)?(?:nevem|teljes\\s+nevem|név|én|lakcímem|lakcím|címem|cím|telefonszámom|telefonszám|mobilom|telefonom|e-?mail\\s*címem|e-?mail\\s*cím|e-?mail|irányítószám|településem|városom)[:\\s]*")
    private val wordsAndNumbers = Regex("(?iu)[+]?\\d+|[\\p{L}]+(?:-[\\p{L}]+)?")
    private val disallowedEmail = setOf("a", "az", "és", "meg", "címem", "email", "ímél", "e-mail", "telefonszámom")

    private data class Token(val text: String, val start: Int, val end: Int)

    /** Kiemelten fontos: '23:70', '23.70', '23 70' irányítószám legyen 2370,
     * de a telefonszámban a csoportokat csak később értékeljük. */
    private fun tidy(raw: String): String = raw.trim()
        .replace(Regex("[\\r\\n]+"), ", ")
        .replace(Regex("(?<!\\d)([1-9]\\d)\\s*[:.]\\s*(\\d{2})(?!\\d)"), "$1$2")
        .replace(Regex("\\s+"), " ")

    private fun digitValue(raw: String): Int? {
        val s = raw.lowercase(hu).replace("-", "").trim()
        if (s.matches(Regex("\\d{1,4}"))) return s.toInt()
        numberOnes[s]?.let { return it }
        if (s.isEmpty()) return 0
        if (s.contains("ezer")) {
            val a = s.substringBefore("ezer")
            val b = s.substringAfter("ezer")
            val thousands = if (a.isEmpty()) 1 else digitValue(a) ?: return null
            val rest = if (b.isEmpty()) 0 else digitValue(b) ?: return null
            if (thousands in 1..9 && rest in 0..999) return thousands * 1000 + rest
            return null
        }
        if (s.contains("száz")) {
            val a = s.substringBefore("száz")
            val b = s.substringAfter("száz")
            val hundreds = if (a.isEmpty()) 1 else digitValue(a) ?: return null
            val rest = if (b.isEmpty()) 0 else digitValue(b) ?: return null
            if (hundreds in 1..9 && rest in 0..99) return hundreds * 100 + rest
            return null
        }
        for ((prefix, count) in tens) {
            if (s == prefix) return count
            if (s.startsWith(prefix)) {
                val rest = numberOnes[s.removePrefix(prefix)]
                if (rest != null && rest > 0) return count + rest
            }
        }
        return null
    }

    private fun spokenPostcode(text: String): Pair<String, IntRange>? {
        val words = wordsAndNumbers.findAll(text).map { Token(it.value, it.range.first, it.range.last + 1) }.toList()
        for (i in words.indices) {
            val first = digitValue(words[i].text) ?: continue
            // 'kétezer-háromszázhetven' önálló tokenként, 'kétezer háromszáz hetven' összegezve.
            for (size in 4 downTo 1) {
                if (i + size > words.size) break
                val vals = words.subList(i, i + size).map { digitValue(it.text) }
                if (vals.any { it == null }) continue
                val ints = vals.filterNotNull()
                val possible = when {
                    size == 1 && ints[0] in 1000..9999 -> ints[0]
                    ints.any { it >= 1000 } && ints.sum() in 1000..9999 -> ints.sum()
                    size == 4 && ints.all { it in 0..9 } -> ints.joinToString("").toIntOrNull() ?: 0
                    else -> 0
                }
                if (possible in 1000..9999 && possible.toString().length == 4) {
                    // A házszám/telefon túl sok találatot adhat; irányítószámnak csak
                    // a telefon előtt vagy helynév mellett értelmezhető számot vesszük.
                    val tail = text.substring(words[i+size-1].end).trimStart(' ', ',', ':')
                    val nextWord = words.getOrNull(i + size)?.text
                    if ((nextWord == null || digitValue(nextWord) == null) &&
                        (tail.firstOrNull()?.isLetter() == true || size >= 2))
                        return possible.toString() to (words[i].start until words[i+size-1].end)
                }
            }
            if (first !in 0..9999) continue
        }
        return null
    }

    private fun removeSpan(text: String, span: IntRange): String = text.replaceRange(span.first,
        span.last + 1, " ".repeat(span.last - span.first + 1))

    private fun emailFromSpeech(text: String): Pair<String, IntRange>? {
        email.find(text)?.let { return it.value to it.range }
        val tokens = Regex("\\S+").findAll(text).map {
            Token(it.value.trim(',', ';', ':', '!'), it.range.first, it.range.last + 1)
        }.toList()
        for (i in tokens.indices) {
            val anchor = tokens[i].text.lowercase(hu).trim('.', ',')
            if (anchor !in setOf("kukac", "kukacjel", "@", "atjel")) continue
            var left = i - 1
            if (left < 0) continue
            while (left >= 2) {
                val connector = tokens[left-1].text.lowercase(hu).trim('.', ',')
                if (connector !in setOf("pont", "alsóvonás", "alsóvonal", "aláhúzás", "kötőjel")) break
                if (tokens[left-2].text.lowercase(hu) in disallowedEmail) break
                left -= 2
            }
            var right = i + 1
            if (right >= tokens.size) continue
            while (right + 2 < tokens.size) {
                val connector = tokens[right+1].text.lowercase(hu).trim('.', ',')
                if (connector != "pont") break
                right += 2
            }
            val candidate = (tokens.subList(left,i).joinToString(" ") { it.text } + " kukac " +
                tokens.subList(i+1,right+1).joinToString(" ") { it.text })
            val formatted = FieldFormatter.normalize(FieldFormatter.Kind.EMAIL,candidate)
                .trimEnd('.')
            if (Regex("(?i)^[a-z0-9._%+\\-]+@[a-z0-9.-]+\\.[a-z]{2,}$").matches(formatted)) {
                return formatted to (tokens[left].start until tokens[right].end)
            }
        }
        return null
    }

    private fun phoneFromSpeech(text: String): Pair<String, IntRange>? {
        val toks = wordsAndNumbers.findAll(text).map { Token(it.value, it.range.first,it.range.last+1) }.toList()
        for (start in toks.indices) {
            val first = toks[start].text.lowercase(hu)
            val firstNumber = digitValue(first) ?: continue
            // Irányítószámmal / több ezres számmal soha ne kezdjünk telefonszámot.
            if (firstNumber !in setOf(1, 20, 23, 30, 31, 36, 50, 70) &&
                firstNumber !in 21..29 && firstNumber !in 32..39 && firstNumber !in 40..49 &&
                firstNumber !in 51..59 && firstNumber !in 60..69 && firstNumber !in 71..99) continue
            for (length in 2..7) {
                if (start+length>toks.size) break
                val group=toks.subList(start,start+length)
                val vals=group.map { digitValue(it.text) }
                if (vals.any{it==null}) break
                val raw=vals.filterNotNull().joinToString("")
                if (raw.length !in 8..12) continue
                val formatted=FieldFormatter.phone(raw)
                if (FieldFormatter.validPhone(formatted) && formatted.startsWith("+36")) {
                    return formatted to (group.first().start until group.last().end)
                }
            }
        }
        return null
    }

    private fun cleanPart(raw:String):String = raw.replace(labelPrefix, "")
        .trim(' ', ',', ';', ':', '.', '!', '\t')
        .replace(Regex("(?iu)^és\\s+"), "")
        .trim()

    private fun reasonableName(text:String):String {
        val s=cleanPart(text).replace(Regex("(?iu)\\s+vagyok\\b.*$"),"")
        val candidate=s.split(Regex("\\s+")).filter{it.isNotBlank()}
        if (candidate.size !in 2..5) return ""
        if (candidate.any{!wordOnly.matches(it) || it.lowercase(hu) in noiseWords}) return ""
        return FieldFormatter.normalize(FieldFormatter.Kind.NAME,candidate.joinToString(" "))
    }

    fun parse(raw: String): SmartDictationReview {
        val text=tidy(raw)
        if(text.isBlank()) return SmartDictationReview(DictatedSignerFields(), setOf("minden"),
            listOf("Nem érkezett szöveg. Próbáljon újra, vagy töltse ki kézzel."))
        val original=HungarianFullDictation.parse(text)
        val notes=mutableListOf<String>()
        val uncertain=mutableSetOf<String>()
        var rest=text
        // A beszéd utolsó e-mail- és telefonszakaszát külön kinyerjük, hogy
        // egy címrészlet ne legyen véletlenül számnak tekintve.
        val mailHit=emailFromSpeech(rest)
        val mail=mailHit?.first ?: original.email
        if (mailHit!=null) rest=removeSpan(rest, mailHit.second)
        val rawPhone=phone.find(rest)?.let{ FieldFormatter.phone(it.value) to it.range }
            ?: phoneFromSpeech(rest)
        val number=rawPhone?.first ?: original.phone
        if(rawPhone!=null) rest=removeSpan(rest,rawPhone.second)
        val postcodeHit=postal.find(rest)?.let { it.value to it.range } ?: spokenPostcode(rest)
        val code=postcodeHit?.first ?: original.postal
        if(postcodeHit!=null) rest=removeSpan(rest, postcodeHit.second)
        var city=original.city
        var street=original.street
        var name=original.name

        // A szám nélküli maradékból keressük a közterületet. A postai kódhoz
        // képest JOBBRA keresünk, így a név nem válhat véletlenül településsé.
        val road=streetType.find(rest)
        if(road!=null) {
            val before=if(postcodeHit!=null && postcodeHit.second.last < road.range.first)
                rest.substring(postcodeHit.second.last+1,road.range.first)
                else rest.substring(0,road.range.first)
            val pieces=before.split(Regex("[,;]"))
            val tailPrefix=cleanPart(pieces.lastOrNull().orEmpty())
            val prefixWords=tailPrefix.split(Regex("\\s+")).filter{it.isNotBlank()}
            val afterRoad=rest.substring(road.range.first).trim()
            val suffix=afterRoad.split(Regex("[,;]"),limit=2).first()
                .split(Regex("(?iu)\\b(?:telefonszám|telefon|mobil|e-?mail|email|címem)\\b"),limit=2)
                .first().trim(' ','.',',',';')
            val suffixWords=suffix.split(Regex("\\s+")).toMutableList()
            // 'Fő út tizenkettő' → 'Fő út 12' (a felhasználó ellenőrzi).
            if(suffixWords.size>=2) {
                val lastWord=suffixWords.last().trim('.',',')
                val n=digitValue(lastWord)
                if(n!=null && n in 1..999) suffixWords[suffixWords.lastIndex]=n.toString()
            }
            val suffixFixed=suffixWords.joinToString(" ")
            if(postcodeHit!=null) {
                val cityPart=if(pieces.size>1) cleanPart(pieces.dropLast(1).lastOrNull().orEmpty())
                    else prefixWords.firstOrNull().orEmpty()
                val streetName=if(pieces.size>1) tailPrefix
                    else prefixWords.drop(1).joinToString(" ")
                if(city.isBlank() && cityPart.isNotBlank())
                    city=FieldFormatter.normalize(FieldFormatter.Kind.CITY,cityPart)
                if(street.isBlank()) street=FieldFormatter.normalize(FieldFormatter.Kind.ADDRESS,
                    (streetName+" "+suffixFixed).trim())
                if(pieces.size==1 && prefixWords.size>2) {
                    uncertain+="city"
                    notes+="A többszavas településnév vagy utcanév felosztását ellenőrizze."
                }
            } else if(prefixWords.isNotEmpty()) {
                if (pieces.size>1 && city.isBlank()) {
                    city=FieldFormatter.normalize(FieldFormatter.Kind.CITY,
                        cleanPart(pieces[pieces.size-2]).split(Regex("\\s+")).lastOrNull().orEmpty())
                }
                if(street.isBlank()) street=FieldFormatter.normalize(FieldFormatter.Kind.ADDRESS,
                    (tailPrefix+" "+suffixFixed).trim())
                uncertain+="address"
                notes+="Irányítószám nélkül a címet külön ellenőrizze."
            }
        }
        // A házszám nélküli lakcímet nem találjuk ki.
        if(city.isBlank() && postcodeHit!=null) {
            val after=rest.substring(postcodeHit.second.last+1).trim(' ', ',', ';')
            val found=Regex("(?iu)^[\\p{L}][\\p{L}\\-]{2,}").find(after)
            if(found!=null) city=FieldFormatter.normalize(FieldFormatter.Kind.CITY,found.value)
        }

        // A 'nevem' címke nem feltétel: az első, jól elkülöníthető 2-4 szó is lehet név.
        val prefix=(if(postcodeHit!=null) rest.substring(0,postcodeHit.second.first) else rest)
            .split(Regex("[,;]"),limit=2).firstOrNull().orEmpty()
        val head=Regex("(?iu)\\b(?:lakcím|címem|telefon|mobil|irányítószám|e-?mail|utca|út)\\b").find(prefix)?.let { prefix.take(it.range.first) } ?: prefix
        val possibleName=reasonableName(head)
        if(possibleName.isNotBlank()) name=possibleName
        else if(name.isBlank()) {
            val words=cleanPart(rest.substringBefore(',')).split(Regex("\\s+"))
                .filter{it.isNotBlank()}.take(2)
            val firstTwo=reasonableName(words.joinToString(" "))
            if(firstTwo.isNotBlank()) {name=firstTwo;uncertain+="name";notes+="A név szövegkörnyezetből következtetett; ellenőrizze."}
        }
        if(name.isNotBlank() && (name.split(" ").size>5 || name.any{it.isDigit()})){name="";uncertain+="name"}
        // A címzett e-mail-címét soha nem generáljuk a felismert névből.
        val final=DictatedSignerFields(name=name,email=mail,phone=number,postal=code,
            city=city,street=street)
        if(name.isBlank()) notes+="A név bizonytalan vagy hiányzik."
        if(code.isBlank() || city.isBlank() || street.isBlank()) notes+="A cím egyik része hiányzik; ne hagyja ellenőrzés nélkül."
        if(code.isNotBlank() && !code.matches(Regex("[1-9]\\d{3}"))) {uncertain+="postal";notes+="Az irányítószám nem pontosan négy számjegy."}
        if(number.isBlank()) notes+="A telefonszám hiányzik."
        else if(!FieldFormatter.validPhone(number)) {uncertain+="phone";notes+="A telefonszám alakját ellenőrizze."}
        if(mail.isBlank()) notes+="Az e-mail-cím hiányzik."
        else if(!email.matches(mail)) {uncertain+="email";notes+="Az e-mail-cím nem tűnik érvényesnek."}
        if(mailHit!=null && mailHit.first!=original.email && original.email.isNotBlank()) uncertain+="email"
        return SmartDictationReview(final, uncertain, notes.distinct())
    }
}

package hu.digitalis.alairas

import android.content.Context
import java.util.Locale

/** Felhasználó által jóváhagyott, kizárólag közismert helynevekre / közterületnevekre
 * szánt javítótár. Nem gyűjt beszédmintát és nem tanít modellt. A bevitt párok
 * a készülék privát alkalmazástárában maradnak. */
object PublicPlaceLexicon {
    private const val PREFERENCES = "public_place_lexicon_v14"
    private const val ENTRIES = "approved_words"
    private val hu = Locale.forLanguageTag("hu-HU")
    private val safeWord = Regex("[\\p{L}\\- ]{2,50}")

    fun entries(context: Context): List<Pair<String,String>> = context
        .getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        .getString(ENTRIES, "").orEmpty().lineSequence()
        .mapNotNull { line ->
            val parts = line.split("\t", limit = 2)
            if (parts.size == 2 && parts.all { safeWord.matches(it) }) parts[0] to parts[1]
            else null
        }.take(50).toList()

    fun add(context: Context, heard: String, correct: String): Boolean {
        val from = heard.trim()
        val to = correct.trim()
        if (!safeWord.matches(from) || !safeWord.matches(to) || from.equals(to,true)) return false
        val items = entries(context).filterNot { it.first.equals(from,true) }.takeLast(49) + (from to to)
        context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE).edit()
            .putString(ENTRIES, items.joinToString("\n") { "${it.first}\t${it.second}" }).apply()
        return true
    }

    fun clear(context: Context) = context.getSharedPreferences(PREFERENCES, Context.MODE_PRIVATE)
        .edit().remove(ENTRIES).apply()

    fun correct(context: Context, source: String): String {
        var text = source
        for ((heard,correct) in entries(context)) {
            text = text.replace(Regex("(?iu)(?<![\\p{L}])${Regex.escape(heard)}(?![\\p{L}])"), correct)
        }
        return text
    }
}

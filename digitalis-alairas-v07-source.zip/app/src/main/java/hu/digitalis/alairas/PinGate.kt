package hu.digitalis.alairas

import android.content.Context
import android.util.Base64
import java.security.MessageDigest
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

/**
 * Demó helyi belépési PIN: sózott, PBKDF2-SHA256 lenyomatot tárolunk,
 * nem a PIN-t. A Keystore-os titkosítástól független második védelmi réteg.
 * Éles kiadásban: MDM, biometria/eszközhitelesítés, időzített zárolás,
 * jogosultsági szerepek és próbálkozás-korlátozás szükséges.
 */
class PinGate(context: Context) {
    private val prefs = context.getSharedPreferences("local_pin", Context.MODE_PRIVATE)
    fun isConfigured(): Boolean = prefs.contains("hash")

    fun register(pin: String) {
        require(pin.length >= 6 && pin.all { it.isDigit() })
        require(!isConfigured()) { "PIN már beállítva" }
        val salt = ByteArray(32).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        prefs.edit()
            .putString("salt", Base64.encodeToString(salt, Base64.NO_WRAP))
            .putString("hash", Base64.encodeToString(hash, Base64.NO_WRAP))
            .apply()
    }

    fun isBlocked(): Boolean =
        System.currentTimeMillis() < prefs.getLong("blocked_until", 0L)

    fun verify(pin: String): Boolean {
        if (isBlocked()) return false
        if (pin.length < 6) return false
        val saltString = prefs.getString("salt", null) ?: return false
        val hashString = prefs.getString("hash", null) ?: return false
        val salt = Base64.decode(saltString, Base64.NO_WRAP)
        val expected = Base64.decode(hashString, Base64.NO_WRAP)
        val valid = MessageDigest.isEqual(derive(pin, salt), expected)
        if (valid) {
            prefs.edit().putInt("failures", 0).putLong("blocked_until", 0).apply()
        } else {
            val failures = prefs.getInt("failures", 0) + 1
            prefs.edit()
                .putInt("failures", if (failures >= 5) 0 else failures)
                .putLong("blocked_until", if (failures >= 5)
                    System.currentTimeMillis() + 15L * 60_000L else 0L)
                .apply()
        }
        return valid
    }

    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 180_000, 256)
        return try {
            SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
        } finally { spec.clearPassword() }
    }
}

package hu.digitalis.alairas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Path
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import java.io.ByteArrayOutputStream

/**
 * Egyszerű helyi érintéses aláírófelület; az ujj és a toll egyaránt működik.
 * A kézírás raszteres PNG-ként menthető és az adatbázis AES-GCM-mel titkosítja.
 * Ez NEM minősített (QES) elektronikus aláírási megoldás.
 */
class SignaturePad @JvmOverloads constructor(
    ctx: Context, attrs: AttributeSet? = null
) : View(ctx, attrs) {
    private val path = Path()
    private val ink = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.rgb(28, 57, 83)
        strokeWidth = 4.4f * resources.displayMetrics.density
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val frame = Paint().apply {
        color = Color.LTGRAY; strokeWidth = 1f
        style = Paint.Style.STROKE
    }
    private var strokes = 0

    init { setBackgroundColor(Color.WHITE); isFocusable = true }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)
        canvas.drawPath(path, ink)
        canvas.drawRect(0f, 0f, width.toFloat() - 1, height.toFloat() - 1, frame)
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                parent?.requestDisallowInterceptTouchEvent(true)
                path.moveTo(event.x, event.y); strokes++
                invalidate(); return true
            }
            MotionEvent.ACTION_MOVE -> {
                path.lineTo(event.x, event.y)
                invalidate(); return true
            }
            MotionEvent.ACTION_UP -> {
                path.lineTo(event.x, event.y)
                parent?.requestDisallowInterceptTouchEvent(false)
                invalidate(); return true
            }
            MotionEvent.ACTION_CANCEL -> {
                parent?.requestDisallowInterceptTouchEvent(false)
                return true
            }
        }
        return false
    }

    fun hasNewSignature(): Boolean = strokes > 0
    fun clear() { path.reset(); strokes = 0; invalidate() }

    /** PNG-t az app privát memóriájában gyártunk, nem tesszük a Galériába. */
    fun exportPng(): ByteArray {
        require(hasNewSignature()) { "Még nem történt aláírás." }
        val w = width.coerceAtLeast(1)
        val h = height.coerceAtLeast(1)
        val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        val canvas = Canvas(bitmap)
        canvas.drawColor(Color.WHITE)
        canvas.drawPath(path, ink)
        return ByteArrayOutputStream().use { out ->
            bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
            bitmap.recycle()
            out.toByteArray()
        }
    }
}

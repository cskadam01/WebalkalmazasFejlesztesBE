# V0.9 – előkészített módosítások (APK még nincs fordítva)

A felhasználó még gyűjti a fejlesztési javaslatokat; ez a köztes forráscsomag.

- Minden új projektbe bekerül az előző beszélgetésben megírt rövid **adatkezelési mintaszöveg**. A régi, üres tájékoztatók kitöltése egyszeri; a korábban egyedileg megadott/jóváhagyott szövegeket nem írjuk felül.
- Az adatkezelő alapértelmezetten: **Omega Code Hungary Kft.**. Kapcsolat: **+36 70 613 2776**. Az első beállítás titkosítva kerül az app adatbázisába; korábban mentett profil nem íródik felül.
- Az aláírás teljes rajzfelülete halványzöld (`#EDF8ED`); 3 dp vastagabb zöld szegély (`#52975D`), 12 dp lekerekítéssel.
- A PNG-export fehér hátterű marad, az aláírás tartalmát nem színezzük át.
- A kampány újonnan betöltött sablonja **nem jelent automatikus jogi/adatkezelői jóváhagyást**, az éles gyűjtésre vonatkozó korábbi kapu változatlan.
- A projektlap „Standard adatkezelési tájékoztató betöltése” külön gombbal visszaállíthatja a mintát, amely feloldja a korábbi jóváhagyás jelölését.

**Megjegyzés:** a 6 számjegyű export PIN kriptográfiailag gyenge a politikai kötődésre utaló személyes adatoknál; a forrásban fennálló, korábban jelzett kockázatot az új UI nem oldja meg.

A korábbi V08 teljes forrása megtartva, a további változtatásokat érdemes egy következő, egyetlen közös APK-ban lefordítani.

package hu.digitalis.alairas

import org.json.JSONObject

/**
 * Egy kampány/ügy konfigurációja. A tájékoztató kampányonként különbözhet.
 * A projekt adatai ugyanúgy titkosított JSON-ként kerülnek az SQLite-ba.
 */
data class Campaign(
    val id: Long = 0,
    val title: String = "",
    val description: String = "",
    val controller: String = "",
    val contact: String = "",
    val privacyNotice: String = "",
    val policyVersion: String = "1.0",
    val retentionDays: Int = 180,
    val approvedForRealData: Boolean = false,
) {
    /** Gyűjtés csak jóváhagyott tájékoztatóval és adatkezelővel indítható. */
    fun isReadyForRealData(): Boolean =
        approvedForRealData && title.isNotBlank() && controller.isNotBlank() &&
            contact.isNotBlank() && privacyNotice.length >= 120 && retentionDays > 0

    fun toJson(): JSONObject = JSONObject()
        .put("title", title).put("description", description)
        .put("controller", controller).put("contact", contact)
        .put("privacyNotice", privacyNotice).put("policyVersion", policyVersion)
        .put("retentionDays", retentionDays).put("approvedForRealData", approvedForRealData)

    companion object {
        fun fromJson(id: Long, o: JSONObject): Campaign = Campaign(
            id, o.optString("title"), o.optString("description"),
            o.optString("controller"), o.optString("contact"),
            o.optString("privacyNotice"), o.optString("policyVersion", "1.0"),
            o.optInt("retentionDays", 180), o.optBoolean("approvedForRealData", false)
        )
    }
}

/**
 * Egyetlen aláírói rekord: nincs külön személyprofil, célzás vagy automata üzenetküldés.
 * A kézzel rajzolt PNG a táblában külön, titkosított BLOB oszlopban tárolódik.
 */
data class Signer(
    val id: Long = 0,
    val campaignId: Long = 0,
    val fullName: String = "",
    val email: String = "",
    val phone: String = "",
    val postalCode: String = "",
    val city: String = "",
    val streetAddress: String = "",
    val newsletter: Boolean = false,
    val sympathizer: Boolean = false,
    val privacyRead: Boolean = false,
    val explicitConsent: Boolean = false,
    val policyVersion: String = "",
    val consentAt: Long = 0,
    val signedAt: Long = 0,
    val signaturePng: ByteArray = byteArrayOf(),
    val createdAt: Long = 0,
    val updatedAt: Long = 0,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("fullName", fullName).put("email", email).put("phone", phone)
        .put("postalCode", postalCode).put("city", city)
        .put("streetAddress", streetAddress)
        .put("newsletter", newsletter).put("sympathizer", sympathizer)
        .put("privacyRead", privacyRead).put("explicitConsent", explicitConsent)
        .put("policyVersion", policyVersion).put("consentAt", consentAt)
        .put("signedAt", signedAt)

    companion object {
        fun fromJson(id: Long, campaignId: Long, o: JSONObject, png: ByteArray,
                     createdAt: Long, updatedAt: Long): Signer = Signer(
            id, campaignId, o.optString("fullName"), o.optString("email"),
            o.optString("phone"), o.optString("postalCode"),
            o.optString("city"), o.optString("streetAddress"),
            o.optBoolean("newsletter"), o.optBoolean("sympathizer"),
            o.optBoolean("privacyRead"), o.optBoolean("explicitConsent"),
            o.optString("policyVersion"), o.optLong("consentAt"),
            o.optLong("signedAt"), png, createdAt, updatedAt
        )
    }
}

/** Ugyanaz az adatkezelő minden kampányban. Titkosítva a SQLite-ban tároljuk. */
data class ControllerProfile(
    val name: String = DefaultPrivacy.CONTROLLER_NAME,
    val contact: String = DefaultPrivacy.CONTROLLER_CONTACT
) {
    fun complete(): Boolean = name.isNotBlank() && contact.isNotBlank()
    fun toJson(): JSONObject = JSONObject().put("name", name).put("contact", contact)
    companion object {
        fun fromJson(o: JSONObject) = ControllerProfile(o.optString("name"), o.optString("contact"))
    }
}

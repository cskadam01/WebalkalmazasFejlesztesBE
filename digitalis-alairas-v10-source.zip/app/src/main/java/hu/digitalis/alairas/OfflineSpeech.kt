package hu.digitalis.alairas

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import java.util.Locale

/**
 * Android beszédfelismerő adapter. Minden hívás a főszálon történik.
 * Az OFFLINE mód csak a készüléken elérhető szolgáltatást használja.
 * A SYSTEM módot kizárólag külön felhasználói jóváhagyás után indítjuk,
 * mert a rendszer szolgáltatója a beszédet esetenként a hálózaton dolgozhatja fel.
 * Hangfájlt ez az alkalmazás egyik módban sem tárol.
 */
class OfflineSpeech(private val context: Context) {
    enum class Mode { OFFLINE, SYSTEM }
    private var recognizer: SpeechRecognizer? = null
    private var sessionId: Long = 0

    fun available(): Boolean = SpeechRecognizer.isOnDeviceRecognitionAvailable(context)
    fun systemAvailable(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(mode: Mode, onText: (String) -> Unit,
              onStatus: (String) -> Unit, onError: (Int) -> Unit,
              onFinal: (String) -> Unit = onText) {
        stop()
        if (mode == Mode.OFFLINE && !available()) {
            onStatus("Nincs telepített eszközön működő beszédfelismerő.")
            onError(SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE)
            return
        }
        if (mode == Mode.SYSTEM && !systemAvailable()) {
            onStatus("Nem érhető el Android beszédfelismerő szolgáltatás.")
            onError(SpeechRecognizer.ERROR_CLIENT)
            return
        }
        val mySession = ++sessionId
        try {
            val service = if (mode == Mode.OFFLINE)
                SpeechRecognizer.createOnDeviceSpeechRecognizer(context)
            else SpeechRecognizer.createSpeechRecognizer(context)
            recognizer = service
            service.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) = onStatus("Beszélhet magyarul…")
                override fun onBeginningOfSpeech() = onStatus("Diktálás folyamatban…")
                override fun onRmsChanged(rmsdB: Float) = Unit
                override fun onBufferReceived(buffer: ByteArray?) = Unit
                override fun onEndOfSpeech() = onStatus("Beszéd feldolgozása…")
                override fun onError(error: Int) {
                    if (sessionId != mySession) return
                    releaseService()
                    onStatus(when (error) {
                        SpeechRecognizer.ERROR_SERVER_DISCONNECTED ->
                            "A beszédfelismerő kapcsolata megszakadt (11). Választhat másik felismerőt."
                        SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE,
                        SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED ->
                            "A magyar nyelvi modell nem érhető el a kiválasztott felismerőben."
                        SpeechRecognizer.ERROR_NO_MATCH -> "Nem sikerült felismerni a szöveget. Ismételje meg."
                        SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "Nem érzékelt beszédet. Próbálja újra."
                        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "A mikrofon foglalt, próbálja újra."
                        else -> "Beszédfelismerési hiba ($error). Gépeléssel is kitölthető."
                    })
                    onError(error)
                }
                override fun onResults(results: Bundle?) {
                    if (sessionId != mySession) return
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) onFinal(text)
                    onStatus(if (text.isNullOrBlank()) "Nem érkezett szöveg; próbálja újra."
                             else "Felismerve – ellenőrizze és javíthatja a szöveget.")
                    releaseService()
                }
                override fun onPartialResults(partialResults: Bundle?) {
                    if (sessionId != mySession) return
                    val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                    if (!text.isNullOrBlank()) onText(text)
                }
                override fun onEvent(eventType: Int, params: Bundle?) = Unit
            })
            service.startListening(Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.forLanguageTag("hu-HU").toLanguageTag())
                putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hu-HU")
                putExtra(RecognizerIntent.EXTRA_ONLY_RETURN_LANGUAGE_PREFERENCE, false)
                putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, mode == Mode.OFFLINE)
                putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
            })
            onStatus(if (mode == Mode.OFFLINE) "Helyi magyar beszédfelismerés indul…"
                     else "Android rendszer-beszédfelismerés indul…")
        } catch (e: Exception) {
            releaseService()
            onStatus("A felismerő nem indult: ${e.message ?: "ismeretlen hiba"}")
            onError(SpeechRecognizer.ERROR_CLIENT)
        }
    }

    private fun releaseService() {
        try { recognizer?.destroy() } catch (_: Exception) {}
        recognizer = null
    }

    fun stop() {
        sessionId++
        try { recognizer?.cancel() } catch (_: Exception) {}
        releaseService()
    }
}

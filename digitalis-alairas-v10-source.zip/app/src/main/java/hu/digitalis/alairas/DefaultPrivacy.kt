package hu.digitalis.alairas

/**
 * Egységes, szerkeszthető ALAPMINTA minden új kampányhoz.
 * Nem jelent automatikus adatkezelői vagy jogi jóváhagyást.
 * Az adatkezelő neve / elérhetősége központi profilban szerepel, nem másoljuk
 * a sablonba, ezért a későbbi központi változtatásokkal is konzisztens marad.
 */
object DefaultPrivacy {
    const val CONTROLLER_NAME = "Omega Code Hungary Kft."
    const val CONTROLLER_CONTACT = "+36 70 613 2776"

    const val NOTICE = "Az aláírásgyűjtés során megadott személyes adatokat " +
        "(név, lakcím, telefonszám, e-mail-cím és digitális aláírás) " +
        "kizárólag az adott kampány támogatásának dokumentálása és az " +
        "önkéntesen választott kapcsolattartás céljából kezeljük. " +
        "Az adatkezelés önkéntes, a politikai véleményre utaló adatok " +
        "kezeléséhez kifejezett hozzájárulás szükséges. " +
        "Az adatokat illetéktelen személyek számára nem tesszük hozzáférhetővé. " +
        "Az érintettek kérhetik adataik megismerését, helyesbítését, törlését, " +
        "valamint hozzájárulásukat visszavonhatják. " +
        "A hírlevélküldéshez külön hozzájárulás szükséges."
}

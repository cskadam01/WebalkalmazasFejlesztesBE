package hu.digitalis.alairas

import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.nio.ByteBuffer
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/**
 * Android Keystore + AES-256-GCM. A titkosító kulcs nem szerepel forrásfájlban,
 * a Keystore-ból nem exportálható. Minden BLOB saját véletlenszerű IV-t kap.
 *
 * Tárolt forma: 1 bájt verzió, 1 bájt IV hossz, 12 bájt IV, ciphertext + tag.
 * Nem helyettesít vállalati MDM-et, eszköztitkosítást és hozzáférés-kezelést!
 */
class RecordCipher {
    private val alias = "hu.digitalis.alairas.data.v1"
    private val store = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }

    private fun key(): SecretKey {
        (store.getKey(alias, null) as? SecretKey)?.let { return it }
        val generator = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        generator.init(
            KeyGenParameterSpec.Builder(alias,
                KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .setRandomizedEncryptionRequired(true)
                .build()
        )
        return generator.generateKey()
    }

    fun encrypt(plain: ByteArray): ByteArray {
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.ENCRYPT_MODE, key())
        val iv = cipher.iv
        val body = cipher.doFinal(plain)
        return ByteBuffer.allocate(2 + iv.size + body.size)
            .put(1.toByte()).put(iv.size.toByte()).put(iv).put(body).array()
    }

    fun decrypt(data: ByteArray): ByteArray {
        require(data.size > 30 && data[0] == 1.toByte()) { "Sérült/támogatás nélküli titkosított mező" }
        val ivSize = data[1].toInt() and 0xFF
        require(ivSize == 12 && data.size > 2 + ivSize + 16) { "Érvénytelen IV/hitelesítő címke" }
        val cipher = Cipher.getInstance("AES/GCM/NoPadding")
        cipher.init(Cipher.DECRYPT_MODE, key(),
            GCMParameterSpec(128, data.copyOfRange(2, 2 + ivSize)))
        return cipher.doFinal(data.copyOfRange(2 + ivSize, data.size))
    }

    fun encryptText(text: String): ByteArray = encrypt(text.toByteArray(Charsets.UTF_8))
    fun decryptText(data: ByteArray): String = decrypt(data).toString(Charsets.UTF_8)
}

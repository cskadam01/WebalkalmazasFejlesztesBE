package hu.digitalis.alairas

import java.util.Locale

/**
 * Adatmezők óvatos, determinisztikus normalizálása.
 * - Nem egészíti ki találgatással a hiányzó személyes adatokat.
 * - A részeredményeket soha nem formázzuk: csak végleges felismeréskor,
 *   mezőelhagyáskor és a felhasználó által indított mentés előtt.
 * - A kimenet minden esetben szerkeszthető marad.
 */
object FieldFormatter {
    enum class Kind { RAW, NAME, EMAIL, PHONE, POSTAL, CITY, ADDRESS }
    private val hu = Locale.forLanguageTag("hu-HU")
    private val word = Regex("[\\p{L}]+")
    private val streetTypes = setOf("út", "utca", "tér", "köz", "körút", "sétány", "rakpart", "sor", "dűlő", "fasor", "park", "tere", "útja", "utca")

    fun normalize(kind: Kind, input: String): String = when (kind) {
        Kind.NAME -> title(input)
        Kind.CITY -> title(input)
        Kind.ADDRESS -> address(input)
        Kind.EMAIL -> email(input)
        Kind.PHONE -> phone(input)
        Kind.POSTAL -> postal(input)
        Kind.RAW -> clean(input)
    }

    private fun clean(value: String) = value.trim().replace(Regex("\\s+"), " ")

    private fun title(value: String): String {
        val cleaned = clean(value)
        if (cleaned.isEmpty()) return cleaned
        return word.replace(cleaned) { match ->
            val w = match.value.lowercase(hu)
            w.replaceFirstChar { c -> c.titlecase(hu) }
        }
    }

    private fun address(value: String): String {
        val normalized = title(value)
        if (normalized.isEmpty()) return normalized
        var wordNumber = 0
        return word.replace(normalized) { match ->
            val raw = match.value
            val lowered = raw.lowercase(hu)
            val out = if (wordNumber > 0 && lowered in streetTypes) lowered else raw
            wordNumber++
            out
        }
    }

    private fun email(value: String): String {
        var v = clean(value).lowercase(hu)
        if (v.isEmpty()) return v
        // Példa: 'jakab pont david kukac gmail pont com' -> 'jakab.david@gmail.com'.
        // Az egybeírt értékek közepén nem cserélünk szórészeket.
        v = v.replace(Regex("(?i)\\s*\\b(kukacjel|kukac|et|at)\\b\\s*"), "@")
            .replace(Regex("(?i)\\s*\\b(pont)\\b\\s*"), ".")
            .replace(Regex("(?i)\\s*\\b(alsóvonás|alsóvonal)\\b\\s*"), "_")
            .replace(Regex("(?i)\\s*\\b(kötőjel|kötővonal)\\b\\s*"), "-")
            .replace(" ", "")
        return v
    }

    private fun phone(value: String): String {
        var valueClean = clean(value).replace(Regex("(?i)^plusz\\s*"), "+")
        // A szöveggé alakult számneveket nem találgatjuk: maradjanak ellenőrizhetők.
        if (valueClean.any { it.isLetter() }) return valueClean
        valueClean = valueClean.replace(Regex("[\\s()./-]+"), "")
        val canonical = if (valueClean.startsWith("0036")) "+36" + valueClean.drop(4) else valueClean
        val digits = canonical.filter { it.isDigit() }
        if (canonical.startsWith("+36") && digits.length == 11) {
            return "+36 ${digits.substring(2,4)} ${digits.substring(4,7)} ${digits.substring(7,11)}"
        }
        if (canonical.startsWith("06") && digits.length == 11) {
            return "06 ${digits.substring(2,4)} ${digits.substring(4,7)} ${digits.substring(7,11)}"
        }
        if (!canonical.startsWith("+") && digits.length == 9) {
            return "${digits.substring(0,2)} ${digits.substring(2,5)} ${digits.substring(5,9)}"
        }
        return canonical
    }

    private fun postal(value: String): String {
        val cleaned = clean(value)
        val digitsWithSpaces = cleaned.replace(" ", "")
        return if (digitsWithSpaces.matches(Regex("\\d{4}"))) digitsWithSpaces else cleaned
    }
}

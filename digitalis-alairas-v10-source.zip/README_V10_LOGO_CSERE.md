# V10 – logócsere

Ebben a változatban a Mi Hazánk logó a felhasználó által megadott, jobb minőségű PNG-re lett cserélve.

Módosítás:
- app/src/main/res/drawable-nodpi/mi_hazank.png

Cél:
- jobb vizuális minőség a fejlécben és az alkalmazás releváns képernyőin.

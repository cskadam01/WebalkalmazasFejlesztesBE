# V0.5 - Gradle 404 hibajavítás, közvetlen Gradle 8.13 build

## Mi okozta a hibát?

A V0.4 `GET_WRAPPER.ps1` egy nem létező URL-t hívott:
`https://services.gradle.org/distributions/gradle-8.13-wrapper.jar`.
A Gradle itt **csak a wrapper JAR checksumát** publikálja; a JAR bináris nem ezen az URL-en tölthető le.

## Mit javítottunk?

- A BUILD_WINDOWS.ps1 **nem használ többé** gradle-wrapper.jar fájlt.
- A GRADLE_SETUP.ps1 **a hivatalos `gradle-8.13-bin.zip` csomagot** tölti le, és a Gradle hivatalos SHA-256 értékével ellenőrzi.
- A Gradle 8.13 csomag cache-be kerül a `%LOCALAPPDATA%\DigitalisAlairasgyujtoBuildTools` könyvtárban. A következő build nem tölti újra.
- A gradlew.bat is ezen a közvetlen Gradle-indítón keresztül működik.
- A korábbi Java és SDK felismerés, valamint a részletes build_naplo.txt naplózás megmarad.

## APK létrehozása

1. Teljesen csomagold ki a ZIP-et (régi fájlokat ne keverj bele).
2. Indítsd a `BUILD_WINDOWS.bat` fájlt.
3. A már telepített Android SDK API 36 és Build Tools 35.0.0 használatba kerül.
4. A Gradle 8.13 első alkalommal letöltődik, ellenőrződik, majd a `:app:assembleDebug` fut.
5. Siker esetén az APK itt található: `Digitalis_Alairasgyujto_TESZT.apk`.

**NEM tesztelt APK:** ebből a környezetből a fordítás nem volt lehetséges, mert nincs Android SDK, és a szükséges letöltések sem érhetők el. Ez a csomag nem tartalmaz APK-t, és nem állítjuk, hogy a teljes alkalmazás lefordult.

**Biztonság:** a projekt politikai kötődésre utaló személyes adatokat is kezelhet. Kizárólag tesztadatokkal használd az adatvédelmi felülvizsgálatig.

Hivatalos SHA-256 érték: `20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78`
Forrás: https://gradle.org/release-checksums/

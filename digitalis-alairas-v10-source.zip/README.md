# Digitális aláírásgyűjtő – 1.0.0 (Kotlin / Android)

## A változat funkciói
- Több projekt, aláírói adatlap és szerkeszthető magyar diktálás.
- Android SpeechRecognizer 11-es hiba (ERROR_SERVER_DISCONNECTED) esetén érthető hibaüzenet, helyi újrapróbálás és **csak külön jóváhagyással** a rendszer-beszédfelismerő használata. A rendszer-beszédfelismerő külső szolgáltatóhoz továbbíthat hangot. Sem a hangot, sem az átiratot nem küldi az alkalmazás önmagától szerverre.
- Zöld, kiemelt új személy felvétele gomb, nagyobb (360dp mobil / 460dp tablet) aláírásmező.
- A felület nem tartalmaz demo/teszt feliratot.
- Titkosított központi adatkezelő beállítás; minden kampányban közös adatkezelő. Projektenként külön jogszerűségi feltételek és adatkezelési tájékoztató.
- A korábbi titkosított ZIP+CSV export és üres Excel-kompatibilis CSV sablon megtartva.

## Különösen fontos: telepítés és adatok
Az előző APK GitHubon generált **debug aláírókulcsa** nem áll rendelkezésre. Ezért az 1.0.0 változat a `hu.digitalis.alairas.v07` alkalmazásazonosítót használja, és **a korábbi alkalmazás mellé települ**. A korábbi adatbázist így nem módosítja, de az adatok nem jelennek meg automatikusan az új alkalmazásban. A régi alkalmazást ne távolítsa el, ha fontos adatok vannak benne! A két alkalmazás között még nincs adatimport/migráció. A későbbi éles frissítésekhez stabil, biztonságosan megőrzött kiadói aláírókulcs szükséges.

## Adatvédelem
Politikai kampányhoz kötődő személyes adat érzékeny lehet. A központi adatkezelő megnevezése és kapcsolattartása előbb kitöltendő. A projekt jóváhagyott adatkezelési szövege, megőrzési ideje, külön hozzájárulásai és további jogi/biztonsági megfelelősége szervezeti feladat, amelyet a program nem tud automatikusan igazolni. Az éles bevezetést adatvédelmi szakértői és biztonsági felülvizsgálatnak kell megelőznie.

## Építés
Android Studio, Java 17, Android SDK 36, Gradle 8.13.

`gradle --no-daemon :app:assembleDebug`

Kimenet: `app/build/outputs/apk/debug/app-debug.apk` (debug aláírással).

## A jelen kiadás fordítása
A V0.7 változatot GitHub Actions alatt ténylegesen lefordítottuk Android SDK 36 / Gradle 8.13 segítségével. A keletkezett APK Zip-szerkezeti és Android aláírás-ellenőrzése sikeres. Telefonos funkcionális ellenőrzés még szükséges.

## Első indítás
1. Adjon meg legalább hatjegyű PIN-kódot.
2. A projektek főképernyőjén adja meg a közös adatkezelő nevét és kapcsolattartási elérhetőségét.
3. Nyissa meg a kampányt, és adja meg a jogilag jóváhagyott adatkezelési tájékoztatót, megőrzési időt és jóváhagyást.
4. Az Új személy felvétele zöld gombbal nyitható az adatlap. Az engedélyt kért mikrofon elindítható a mezők mellett.
5. A beszédfelismerő 11-es hibájánál a rendszer felajánlja az újrapróbálást vagy a rendszer-beszédfelismerő használatát külön hozzájárulás után. A szöveg utólag szerkeszthető.
6. A nagy aláírásmezőn ujj vagy érintőtoll használható; mentés előtt minden mezőt és hozzájárulást ellenőrizzen.

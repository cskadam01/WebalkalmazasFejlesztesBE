# Digitális aláírásgyűjtő – V10 (1.2.0)

A V0.9 előkészített forrásból és a felhasználó eredeti, jó minőségű logójából fordított Android-alkalmazás.

## Mi változott?
- A `res/drawable-nodpi/mi_hazank.png` fájl a felhasználó által 2026-11-07-én megadott 1000×579 px transzparens PNG.
- A korábban előkészített adatkezelői alapbeállítás, alap tájékoztató és világoszöld, vastagon keretezett aláírásmező a forrásban szerepel.
- A csomagban az alkalmazás neve nem tartalmaz „demo” jelölést.
- `applicationId: hu.digitalis.alairas.v10`, `versionCode: 10`, `versionName: 1.2.0`.

## Telepítési megjegyzés
Mivel a V08/V07 APK-k egyszeri GitHub debug aláírókulcsokat használtak, ez a verzió másik azonosítót kapott, ezért a régi mellé települ. Az ott tárolt adatok nem kerülnek át automatikusan. **Ne töröld a régi alkalmazást, ha abban valós adatok vannak.**

A GitHub Actions build debug APK-t készít; a sikeres fordítás és APK-aláírás ellenőrzése nem egyenlő a fizikai telefonon végzett funkcionalitási/adatvédelmi teszttel.

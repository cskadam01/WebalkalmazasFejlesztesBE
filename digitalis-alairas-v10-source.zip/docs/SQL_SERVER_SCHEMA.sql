-- Microsoft SQL Server 2022+ TERVVÁZLAT: NINCS AZ ANDROID APP-HOZ BEKÖTVE.
-- Politikai szimpátiára utaló adatokhoz az adatkezelési és jogosultsági
-- megfelelőséget, oszlopszintű titkosítást és szerveroldali kulcskezelést
-- külön implementálni szükséges. NEM kész produkciós DDL.
CREATE TABLE dbo.PetitionCampaigns (
    CampaignId UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PetitionCampaigns PRIMARY KEY,
    CampaignTitle NVARCHAR(300) NOT NULL,
    Description NVARCHAR(MAX) NULL,
    PrivacyNoticeVersion NVARCHAR(50) NOT NULL,
    ControllerName NVARCHAR(300) NOT NULL,
    RetentionDays INT NOT NULL,
    CreatedAt DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    CONSTRAINT CK_RetentionDays CHECK (RetentionDays > 0)
);
GO
CREATE TABLE dbo.PetitionSignatures (
    SignatureId UNIQUEIDENTIFIER NOT NULL CONSTRAINT PK_PetitionSignatures PRIMARY KEY,
    CampaignId UNIQUEIDENTIFIER NOT NULL,
    -- Szerveroldali KMS-sel külön titkosítandó személyes adatcsomag
    ProtectedPersonalData VARBINARY(MAX) NOT NULL,
    ProtectedSignaturePng VARBINARY(MAX) NOT NULL,
    NoticeVersion NVARCHAR(50) NOT NULL,
    SignedAt DATETIME2(3) NOT NULL,
    ConsentedAt DATETIME2(3) NOT NULL,
    -- E két adat feldolgozása is érzékeny, élesben titkosítás/ACL szükséges:
    NewsletterOptIn BIT NOT NULL DEFAULT 0,
    SympathizerOptIn BIT NOT NULL DEFAULT 0,
    UpdatedAt DATETIME2(3) NOT NULL DEFAULT SYSUTCDATETIME(),
    DeletedAt DATETIME2(3) NULL,
    CONSTRAINT FK_Signatures_Campaign FOREIGN KEY (CampaignId)
        REFERENCES dbo.PetitionCampaigns(CampaignId)
);
GO
CREATE INDEX IX_Signatures_Campaign ON dbo.PetitionSignatures(CampaignId);
GO

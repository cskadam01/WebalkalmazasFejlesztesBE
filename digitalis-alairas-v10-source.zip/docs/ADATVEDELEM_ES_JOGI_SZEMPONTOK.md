# Adatvédelmi és jogi ellenőrzőlista az élesítéshez

**Ez nem jogi szakvélemény.** A megadott követelmények a GDPR, a NAIH 2026-os
kampány-adatkezelési tájékoztatója és az aláírásgyűjtő papírsablon alapján készültek.

## Az eredeti íven szereplő mezők

- Olvasható név
- E-mail-cím
- Mobiltelefon
- Lakcím (irányítószám, település, utca, házszám)
- „Hírlevélre feliratkozom” jelölés
- „Szimpatizánsnak jelentkezem” jelölés
- Kézi aláírás

A digitális modellben ezekhez hozzátartozik a kampány azonosítója, a tájékoztató
verziója és a hozzájárulási/aláírási időpont. A tényleges adatkezelő nevét,
kapcsolattartását, céljait, jogalapját, címzetteket, tárolási időt, jogokat,
panaszlehetőséget és leiratkozást **nem lehet a régi lapról automatikusan átvenni**.

## Kötelező döntések használat előtt

1. Megállapítani, hogy **petíciós aláírásgyűjtésről** vagy valamely szigorú
   törvényi formát előíró **választási ajánlásról/népszavazási eljárásról** van-e szó.
   A sima képernyőaláírás nem helyettesít automatikusan minden előírt formát.
2. Meghatározni adatkezelőket, feldolgozókat, adatkezelési célokat,
   jogalapokat és a **politikai véleményre utaló különleges adatok** megfelelő
   GDPR 9. cikk szerinti feltételeit. A kampány támogatása nem jelent
   automatikus feliratkozást politikai hírlevélre.
3. Teljes és érthető adatkezelési tájékoztatót készíteni, és a képernyőn
   megjeleníteni. A két opcionális cél külön-külön, üres alapállapotú választás.
4. A petícióhoz szükséges lehető legkisebb adatkört gyűjteni; *különösen* nem
   kötelező az e-mail és a telefonszám, ha a petíció céljához nem szükséges.
5. Dokumentálni a tájékoztató verzióját, hozzájárulás idejét és a visszavonás,
   helyesbítés, törlés, valamint hozzáférés kérelmezésének folyamatát.
6. Adatvédelmi hatásvizsgálat szükségességét felmérni, hatósági útmutatás szerint.
7. Aktivista/eszköz jogosultságokat, auditot, titkosított biztonsági mentést,
   készülékvesztési folyamatot és automatikus megőrzési/törlési időt bevezetni.
8. Az adatkezelés és aláírás érvényességének formai megfelelőségét külön
   szakértővel ellenőriztetni.

## Korlátok ebben a demóban

- Nincs központi felhasználókezelés, MDM vagy adatvédelmi hatásvizsgálat.
- Nincs visszavonási kérelem-ügyintéző és automata megőrzés-kikényszerítés.
- Nincs vállalati szintű támadás-ellenállósági teszt, külső audit, végpontvédelem.
- A PIN belépés demonstrációs szintű, a titkosítás Android KeyStore-t használ.
- Az aláírás átrajzolható, de a felvett kézjegy nem biztosít minősített
  elektronikus aláírást és nem garantálja az aláíró személyazonosságát.
- Az "éles mód" checkbox nem helyettesíti a valós jogi jóváhagyást.

## Ellenőrzött hivatalos források

- Európai Bizottság: személyes adatok különleges kategóriái:
  https://commission.europa.eu/law/law-topic/data-protection/information-individuals_en
- GDPR (EU 2016/679), 5., 6., 9., 13., 32. cikk:
  https://eur-lex.europa.eu/legal-content/HU/TXT/?uri=CELEX:32016R0679
- NAIH: Tájékoztató a 2026. évi országgyűlési választási kampány adatvédelmi
  vonatkozásairól:
  https://naih.hu/tajekoztatok-kozlemenyek?download=1321:a-nemzeti-adatvedelmi-es-informacioszabadsag-hatosag-tajekoztatoja-a-2026-evi-orszaggyulesi-valasztasi-kampany-adatvedelmi-vonatkozasairol

# Projektadatok táblázatos megosztása (v0.2.0)

## 1. Megosztási funkciók

A projekt adatlapján két külön művelet található:

**Üres kérdőív megosztása (Excel CSV)**
- A kampány címével, leírásával és a rögzítendő mezőkkel előkészített, kitölthető CSV.
- Semmilyen felvett aláíró személyes adata nem kerül bele.
- A telefon rendszermegosztójában e-mail, üzenetküldő vagy más megfelelő alkalmazás választható.

**Kitöltött adatlapok megosztása (AES-256 ZIP)**
- Kampányonként valamennyi elmentett aláíró külön sorban szerepel a `adatok.csv` fájlban.
- Oszlopok: kampány címe/leírása; rekordazonosító; olvasható név; e-mail; mobiltelefon;
  irányítószám; település; utca/házszám; hírlevél-választás; szimpatizánsi választás;
  tájékoztató megismerésének jelzése; kifejezett hozzájárulás; adatkezelési verzió;
  hozzájárulás/aláírás/rögzítés/módosítás időpontjai; aláírás képfájljának neve.
- A rajzolt aláírásokat az `alairasok/alairas_<azonosító>.png` fájlok tartalmazzák.
- **Minden ZIP-be írt fájl titkosított AES-256 módban; az alkalmazás nem ment
  külön, védelem nélküli átmeneti CSV- vagy PNG-fájlt.**
- Az export előtt jogosultságnyilatkozat és pontosan hat számjegyű, kétszer megadott
  ZIP PIN kell. E-mail vagy más célalkalmazás kizárólag explicit választással indul.

## 2. Megnyitás Windows alatt

1. A címzett mentse el a `.zip` mellékletet.
2. Nyissa meg AES-256 ZIP-et ismerő alkalmazással (például 7-Zip).
   A Windows beépített ZIP-nézegetője nem minden verzióban kompatibilis az AES-ZIP-pel.
3. A hatjegyű PIN-t *ne* ugyanabban az e-mailben küldje el a feladó, amelyben a ZIP-et.
4. A kibontott `adatok.csv` Excelben UTF-8 kódolással, **pontosvessző** elválasztóval
   jeleníthető meg oszlopokban. A CSV elején UTF-8 BOM van az ékezetekhez.
5. A felhasználó gondoskodjon a kibontott fájlok védelméről és törléséről is.

## 3. Fontos biztonsági megjegyzések

- **Politikai véleményre utaló, különleges személyes adatot** tartalmazhat az export.
  A jogosultsági pipa nem önmagában jogalap; csak jogszerűen jogosult címzettnek továbbítható.
- Titkosított csatolmány sem jelenti azt, hogy bármely külső megosztó- vagy e-mail-szolgáltatás
  automatikusan megfelel az adatkezelő szervezeti előírásainak.
- A PIN nem kerül be az e-mailbe, és az alkalmazás nem tárolja beállításként.
- A kész ZIP az alkalmazás privát gyorsítótárában marad legfeljebb addig, amíg
  a következő indítás/export során a **24 óránál régebbi** csatolmányok törlődnek.
  Ez a prototípus nem garantál azonnali törlést és nem távolítja el a már elküldött másolatokat.
- Android `FileProvider` ideiglenes hozzáférést ad a kiválasztott fogadó appnak;
  az eredeti titkosított SQLite-adatbázis nem megosztható.
- A fájl készülékek közötti átvitelével a titkosított ZIP egyszerű átmásolása
  **nem importálja** az eredeti adatokat az alkalmazás SQLite-adatbázisába.
- A CSV-képletinjektálás ellen az értékeket idézőjelezzük és védjük; nem biztosítunk
  automatikus képletértékelést sem az importálás során.
- Nincs tömeges automatikus levélküldés aláíróknak, és nem gyűjtünk információkat arról,
  ki melyik üzenetet kapta meg. A megosztási műveletet a felhasználó maga indítja.

## 4. Tesztelési forgatókönyv

1. A mintakampányban hozz létre két **kitalált** aláírót, különböző
   hírlevél- és szimpatizánsi opciókkal.
2. Válaszd az üres kérdőív megosztását, és ellenőrizd, hogy egy CSV-t ad át az app.
3. Válaszd a kitöltött exportot; ötjegyű vagy nem numerikus PIN-t utasítson el.
4. Pontosan hat számmal (például `042971`), kétszeri egyező bevitellel készüljön AES-256 ZIP;
   PIN nélkül a `adatok.csv` ne legyen olvasható.
5. Jó jelszóval a CSV két rekordot és a megfelelő `alairasok/` PNG-ket tartalmazza.
6. Ellenőrizd, hogy az ékezetes magyar cím és az aláíráskép helyesen jelenik meg.
7. Próbáld ki a Gmail/Outlook megosztási lehetőséget; ne küldj valódi adatot teszteléskor.
8. Adatbázis-bejegyzés törlése után új export már ne tartalmazza a törölt sort.

**Élesítés:** Android SDK/Gradle build és eszközteszt, jogosultsági felülvizsgálat,
export-/adat-hozzáférési audit és adatvédelmi kontrollok ellenőrzése szükséges.

## 5. 6 számjegyű PIN biztonsági korlátja

A felhasználói kérés alapján az export 6 számjegyű PIN-nel védett,
az AES-256 ZIP-formátum változatlanul megmarad. Ez **nem erős adatvédelem**:
csupán egymillió PIN-lehetőség van, a másolat birtokában offline próbálkozás
lehetséges. Különösen politikai kötődésre utaló személyes adatok továbbítása előtt
adatvédelmi felülvizsgálat javasolt. A PIN külön csatornán közlendő.

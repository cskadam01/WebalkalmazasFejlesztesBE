# Opcionális MSSQL szinkron — következő fejlesztési ütem

**A ZIP-ben lévő Android app NEM csatlakozik MS SQL Serverhez.**
Egy natív mobilalkalmazás SOHA ne csatlakozzon közvetlen SQL Serverhez
adatbázis-jelszóval; ehelyett az alábbi architektúrát javasoljuk:

```
[Android / Kotlin]
  ├── Android Keystore + AES-GCM titkosított SQLite
  ├── helyi magyar SpeechRecognizer (nyers hang nem hagyja el a készüléket)
  └── hitelesített HTTPS API kérés, csak kifejezett szinkronfelhatalmazással
                         │ TLS 1.3, token/MTLS, eszközregisztráció
                         ▼
[ASP.NET Core .NET 10 Web API]
  ├── szervezeti identitáskezelés, szerepkörök, eszköz-visszavonás
  ├── célhoz kötöttség, szervezeti és kampány jogosultság
  ├── szerveroldali kulcskezelés (KMS/HSM), titkosítás, napló
  ├── konfliktuskezelés, idempotens adatküldés, törlési kérelmek
  └── [Microsoft SQL Server 2022+]
```

## Szinkron rekordja

- `campaign_uuid`, `signature_uuid`: Globálisan egyedi azonosító, ne azonosító
  alapján lehessen más kampány rekordjaihoz hozzáférni.
- `client_version`, `device_id`, `updated_at`, `signed_at`, `policy_version`.
- `full_name`, `postal_code`, `city`, `street`, `phone`, `email`.
- `newsletter_opt_in`, `sympathizer_opt_in` (nem keverhetők).
- `explicit_consent`, `consent_at`, aláírás PNG vagy hash + szerveroldali tárhely.
- `deleted_at` csak törlési szinkron céljára; törlés visszajátszás elleni védelem.

**FONTOS:** Az Android KeyStore AES-kulcsa a telefonon marad. A helyi adatbázis
BLOB-ját nem lehet egyszerűen feltölteni és SQL Serveren dekódolni. Biztonságos
szinkronnál a mobilapp a feloldott rekordot TLS-en át, megfelelő jogosultsággal
küldi az API-nak; az API szerveroldali titkosítással újratitkosítva tárolja.

## Követelmények

1. OpenID Connect/OAuth2 PKCE, eszközregisztráció, szükségesen szűk szerepkörök.
2. TLS 1.3, nincs HTTP, nincs API-kulcs a telefon forráskódjába égetve.
3. Nincs teljes adatbázis-CSV automatikus megosztás; csak jogosult export.
4. At-rest szerveroldali titkosítás, kulcsrotáció, TDE + oszlopszintű védelem.
5. Audit, támadásfigyelés, hozzáférés-felülvizsgálat, szervezeti több-bérlős izoláció.
6. Visszavont hozzájárulás és törlés szinkronja minden eszközre.
7. Ki mit és mikor javított: naplózás személyes adatok ismétlése nélkül.
8. Külön integrációs és jogosultságtesztek.

A `SQL_SERVER_SCHEMA.sql` adatbázisvázlat, nem egy elkészült szerver.

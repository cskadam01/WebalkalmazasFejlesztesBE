# Digitális aláírásgyűjtő – 1.1.0 (V08)

## Fő változások

- A Mi Hazánk-logó és a mögötte következő címsor felül további 20 dp távolságot kapott.
- Az „Ellenőrzött adatok és aláírás mentése” gomb teljes felületű zöld, fehér feliratos elsődleges gomb.
- A 12-es `ERROR_LANGUAGE_NOT_SUPPORTED` hibakódra külön magyarázat jelenik meg. Az app nem feltételezi, hogy minden telefon támogatja az offline magyar nyelvet.
- Az offline-ról Android rendszerfelismerőre váltás **csak felhasználói jóváhagyással** történhet, a jóváhagyott választás később is megmarad és az adatlapon bármikor módosítható.
- A hibás helyi felismerés után **nem** nyitunk automatikusan ismétlődő párbeszédablakot.
- A mikrofon Android-jogosultságát csak akkor kéri a program, ha azt a rendszer szerint még nem kapta meg. Ha a készülék beállítása „Minden alkalommal kérdezzen”, ezt az Android beállításaiban lehet módosítani „Csak az alkalmazás használata közben” engedélyre; az app nem kerülheti meg a rendszer döntését.
- Mezőnkénti formázás: magyar név- és településkezdőbetűk, e-mailben „kukac”, „pont”, „alsóvonal” és „kötőjel”, telefonszám-formázás, négyjegyű irányítószám, utca/tér/út írásmód.
- A diktálás részeredménye nyersen látszik, a **végleges felismerési szöveg** kerül formázásra. Kézi beírásnál mezőelhagyáskor és mentés előtt normalizálódik.
- A korábbi nagy aláírásmező, titkosított SQLite, központi adatkezelő, CSV-táblázat és jelszóvédett ZIP megosztás változatlan.

## Nem része ennek a változatnak

Az **összes mező egyetlen diktálásból történő automatikus szétosztása** egy külön, további fejlesztési javaslat; a jelenlegi verzió továbbra is mezőnként diktál. A jövőbeli megoldásban a nyers leiratból „kitöltési javaslat” készülhet, amelyet a felhasználó ellenőriz és külön elfogad. Nevet, utcát vagy telefonszámot nem szabad találgatással kitölteni.

## Telepítés és adatvédelem

A V07 Android debug aláírókulcsa nem őrzött, a V08 ezért `hu.digitalis.alairas.v08` package azonosítóval **külön alkalmazásként** települ. A V07 meglévő adatai nem törlődnek, de automatikusan nem érhetők el a V08-ban. Ne törölje a régit fontos adatok esetén. Végleges kiadás előtt stabil kiadói kulcs és biztonságos migráció szükséges.

A politikai kampány során kezelt adatok és kézi aláírások fokozottan védendők. A rendszerfelismerő szolgáltatója az Android beállításaitól függően hálózaton feldolgozhatja a beszédet. Éles adatgyűjtés előtt külön adatvédelmi és biztonsági felülvizsgálat, adatmegőrzési és törlési folyamat szükséges.

## Build

JDK 17, Gradle 8.13, Android SDK API 36, Build Tools 35.0.0.

`gradle --no-daemon :app:assembleDebug`

A GitHub Actions által épített aláírt debug APK nem helyettesíti a Play-disztribúcióhoz szükséges release aláírást.

### ZIP-export PIN (frissítés)
A kitöltött adatok AES-256 titkosított ZIP-be kerülnek. Az exportablak pontosan **6 számjegyű** PIN-t kér, kétszer. Ez kényelmes, de kriptográfiailag gyenge; ne tekintsd megfelelő önálló védelemnek különleges személyes adatok továbbításához. A PIN-t a csatolmánytól elkülönítve add át.

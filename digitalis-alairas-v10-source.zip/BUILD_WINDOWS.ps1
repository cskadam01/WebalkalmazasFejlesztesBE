# Android APK builder for Windows PowerShell 5.1+.
# Uses a verified Gradle 8.13 ZIP; Android SDK tools are downloaded only with approval.
# The Android SDK licenses are accepted interactively, never silently by this script.
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
Set-Location -LiteralPath $project
$log = Join-Path $project 'build_naplo.txt'
$transcriptStarted = $false
$exitCode = 1

function Resolve-Java {
    $candidates = @()
    if ($env:JAVA_HOME) { $candidates += $env:JAVA_HOME }
    if ($env:ProgramFiles) {
        $candidates += (Join-Path $env:ProgramFiles 'Android\Android Studio\jbr')
        $candidates += (Join-Path $env:ProgramFiles 'Eclipse Adoptium')
    }
    foreach ($javaCandidateHome in $candidates) {
        if (Test-Path -LiteralPath (Join-Path $javaCandidateHome 'bin\java.exe')) {
            $env:JAVA_HOME = $javaCandidateHome
            return (Join-Path $javaCandidateHome 'bin\java.exe')
        }
    }
    $javaCmd = Get-Command java.exe -ErrorAction SilentlyContinue
    if ($javaCmd) { return $javaCmd.Source }
    throw 'No Java JDK found. Install Android Studio (bundled JDK 17+) or a JDK 17+.'
}

function Resolve-SdkRoot {
    $candidates = @()
    if ($env:ANDROID_HOME) { $candidates += $env:ANDROID_HOME }
    if ($env:ANDROID_SDK_ROOT) { $candidates += $env:ANDROID_SDK_ROOT }
    if ($env:LOCALAPPDATA) { $candidates += (Join-Path $env:LOCALAPPDATA 'Android\Sdk') }
    foreach ($sdk in $candidates) {
        if ((Test-Path -LiteralPath (Join-Path $sdk 'platforms')) -or
            (Test-Path -LiteralPath (Join-Path $sdk 'cmdline-tools'))) { return $sdk }
    }
    if ($env:LOCALAPPDATA) { return (Join-Path $env:LOCALAPPDATA 'Android\Sdk') }
    throw 'Cannot determine an Android SDK directory. Install Android Studio.'
}

function Get-SdkManager([string] $sdkRoot) {
    $cmdTools = Join-Path $sdkRoot 'cmdline-tools'
    $firstChoice = Join-Path $cmdTools 'latest\bin\sdkmanager.bat'
    if (Test-Path -LiteralPath $firstChoice) { return $firstChoice }
    if (Test-Path -LiteralPath $cmdTools) {
        $found = Get-ChildItem -Path $cmdTools -Filter 'sdkmanager.bat' -File -Recurse -ErrorAction SilentlyContinue |
            Select-Object -First 1
        if ($found) { return $found.FullName }
    }
    $legacy = Join-Path $sdkRoot 'tools\bin\sdkmanager.bat'
    if (Test-Path -LiteralPath $legacy) { return $legacy }
    return $null
}

function Install-SdkManager([string] $sdkRoot) {
    $downloadUrl = 'https://dl.google.com/android/repository/commandlinetools-win-15859902_latest.zip'
    $expectedHash = '90ae805d20434428bffcb699c290860f19bb5f66a67e6b330067e3de801fb04a'
    Write-Host 'Missing Android SDK command-line tools.' -ForegroundColor Yellow
    Write-Host 'Review the official Android SDK license: https://developer.android.com/studio'
    $answer = Read-Host 'After reading the Google terms, download the official SDK command-line tools? [I/N]'
    if ($answer.Trim().ToUpperInvariant() -ne 'I') {
        throw 'SDK tools installation cancelled. Use Android Studio > Settings > Android SDK.'
    }
    $tempDir = Join-Path $env:TEMP ("android_sdk_bootstrap_" + [Guid]::NewGuid().ToString('N'))
    $zipFile = Join-Path $tempDir 'cmdline-tools.zip'
    New-Item -ItemType Directory -Path $tempDir -Force | Out-Null
    try {
        Write-Host 'Downloading official Android SDK command-line tools...'
        Invoke-WebRequest -Uri $downloadUrl -OutFile $zipFile -UseBasicParsing
        $hash = (Get-FileHash -LiteralPath $zipFile -Algorithm SHA256).Hash.ToLowerInvariant()
        if ($hash -ne $expectedHash) { throw 'SDK command-line tools checksum mismatch.' }
        $expandedDir = Join-Path $tempDir 'expanded'
        Expand-Archive -LiteralPath $zipFile -DestinationPath $expandedDir -Force
        $from = Join-Path $expandedDir 'cmdline-tools'
        if (-not (Test-Path -LiteralPath (Join-Path $from 'bin\sdkmanager.bat'))) {
            throw 'SDK command-line tools archive has an unexpected structure.'
        }
        $to = Join-Path $sdkRoot 'cmdline-tools\latest'
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $to) | Out-Null
        if (Test-Path -LiteralPath $to) { throw 'The target cmdline-tools/latest directory already exists; please resolve manually.' }
        Move-Item -LiteralPath $from -Destination $to
    } finally {
        Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    }
    return (Join-Path $sdkRoot 'cmdline-tools\latest\bin\sdkmanager.bat')
}

try {
    Start-Transcript -LiteralPath $log -Force | Out-Null
    $transcriptStarted = $true
    Write-Host '==============================================='
    Write-Host 'Digitalis alairasgyujto - Android APK build'
    Write-Host '==============================================='

    $javaExe = Resolve-Java
    Write-Host "Java: $javaExe"
    & $javaExe -version
    if ($LASTEXITCODE -ne 0) { throw 'Java runtime test failed.' }

    $sdkRoot = Resolve-SdkRoot
    $env:ANDROID_HOME = $sdkRoot
    $env:ANDROID_SDK_ROOT = $sdkRoot
    Write-Host "Android SDK: $sdkRoot"
    $platform = Join-Path $sdkRoot 'platforms\android-36\android.jar'
    $buildTools = Join-Path $sdkRoot 'build-tools\35.0.0'
    if (-not (Test-Path -LiteralPath $platform) -or -not (Test-Path -LiteralPath $buildTools)) {
        $sdkManager = Get-SdkManager $sdkRoot
        if (-not $sdkManager) { $sdkManager = Install-SdkManager $sdkRoot }
        Write-Host 'Android SDK licenses: review the prompts and accept only if you agree.'
        & $sdkManager "--sdk_root=$sdkRoot" '--licenses'
        if ($LASTEXITCODE -ne 0) { throw 'Android SDK licenses were not accepted or sdkmanager failed.' }
        Write-Host 'Installing Android API 36 and Build Tools 35.0.0...'
        & $sdkManager "--sdk_root=$sdkRoot" '--install' 'platforms;android-36' 'build-tools;35.0.0' 'platform-tools'
        if ($LASTEXITCODE -ne 0) { throw 'Android SDK package installation failed.' }
    }
    if (-not (Test-Path -LiteralPath $platform)) { throw "Missing SDK platform: $platform" }

    # Use verified Gradle distribution directly; no wrapper JAR and no 404-prone URL.
    $gradleSetup = Join-Path $project 'GRADLE_SETUP.ps1'
    if (-not (Test-Path -LiteralPath $gradleSetup)) { throw 'GRADLE_SETUP.ps1 is missing.' }
    Write-Host 'Building :app:assembleDebug with verified Gradle 8.13 ...'
    & powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File $gradleSetup -BuildApk
    if ($LASTEXITCODE -ne 0) { throw "Gradle build failed (exit code $LASTEXITCODE)." }
    $builtApk = Join-Path $project 'app\build\outputs\apk\debug\app-debug.apk'
    if (-not (Test-Path -LiteralPath $builtApk)) { throw "Gradle exited successfully but APK not found: $builtApk" }
    $deliverableApk = Join-Path $project 'Digitalis_Alairasgyujto_1_0.apk'
    Copy-Item -LiteralPath $builtApk -Destination $deliverableApk -Force
    Write-Host "SUCCESS - APK: $deliverableApk" -ForegroundColor Green
    Write-Host 'This is a DEBUG build for testing, not a production/privacy-audited release.'
    $exitCode = 0
} catch {
    Write-Host ("BUILD ERROR: " + $_.Exception.Message) -ForegroundColor Red
    Write-Host 'Open build_naplo.txt or use Android Studio > Build for more details.'
    $exitCode = 1
} finally {
    if ($transcriptStarted) { Stop-Transcript | Out-Null }
}
exit $exitCode

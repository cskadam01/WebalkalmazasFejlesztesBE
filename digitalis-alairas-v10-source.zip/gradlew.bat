@echo off
setlocal EnableExtensions
set "APP_HOME=%~dp0"
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%APP_HOME%GRADLE_SETUP.ps1" %*
exit /b %ERRORLEVEL%

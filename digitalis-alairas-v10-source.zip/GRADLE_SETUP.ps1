﻿# V0.5 - Gradle 8.13 full distribution bootstrap, without a wrapper JAR.
# This file can also be called directly through gradlew.bat with any Gradle arguments.
param([switch]$BuildApk, [Parameter(ValueFromRemainingArguments=$true)][string[]]$GradleArguments)
$ErrorActionPreference = 'Stop'
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
$expectedZipHash = '20f1b1176237254a6fc204d8434196fa11a4cfb387567519c61556e8710aed78'
$url = 'https://services.gradle.org/distributions/gradle-8.13-bin.zip'
$project = Split-Path -Parent $MyInvocation.MyCommand.Path
$cacheRoot = if ($env:LOCALAPPDATA) { Join-Path $env:LOCALAPPDATA 'DigitalisAlairasgyujtoBuildTools' } else { Join-Path $project '.gradle-build-tools' }
$gradleHome = Join-Path $cacheRoot 'gradle-8.13'
$gradleExe = Join-Path $gradleHome 'bin\gradle.bat'
$archive = Join-Path $cacheRoot 'gradle-8.13-bin.zip'
try {
    New-Item -Path $cacheRoot -ItemType Directory -Force | Out-Null
    if (-not (Test-Path -LiteralPath $gradleExe)) {
        $archiveOK = $false
        if (Test-Path -LiteralPath $archive) {
            $actual = (Get-FileHash -LiteralPath $archive -Algorithm SHA256).Hash.ToLowerInvariant()
            $archiveOK = ($actual -eq $expectedZipHash)
            if (-not $archiveOK) { Remove-Item -LiteralPath $archive -Force }
        }
        if (-not $archiveOK) {
            Write-Host 'Downloading official Gradle 8.13 binary distribution (~131 MB)...'
            $partial = $archive + '.partial'
            if (Test-Path -LiteralPath $partial) { Remove-Item -LiteralPath $partial -Force }
            Invoke-WebRequest -Uri $url -OutFile $partial -UseBasicParsing -TimeoutSec 600
            $actual = (Get-FileHash -LiteralPath $partial -Algorithm SHA256).Hash.ToLowerInvariant()
            if ($actual -ne $expectedZipHash) {
                Remove-Item -LiteralPath $partial -Force -ErrorAction SilentlyContinue
                throw "Gradle ZIP checksum does not match official Gradle 8.13 checksum. Got: $actual"
            }
            Move-Item -LiteralPath $partial -Destination $archive -Force
        }
        Write-Host 'Gradle ZIP SHA-256 OK. Extracting...'
        $stage = Join-Path $cacheRoot ('stage_' + [Guid]::NewGuid().ToString('N'))
        New-Item -ItemType Directory -Path $stage | Out-Null
        try {
            Expand-Archive -LiteralPath $archive -DestinationPath $stage -Force
            $unpacked = Join-Path $stage 'gradle-8.13'
            if (-not (Test-Path -LiteralPath (Join-Path $unpacked 'bin\gradle.bat'))) { throw 'Unexpected Gradle archive layout.' }
            if (Test-Path -LiteralPath $gradleHome) { Remove-Item -LiteralPath $gradleHome -Recurse -Force }
            Move-Item -LiteralPath $unpacked -Destination $gradleHome
        } finally {
            Remove-Item -LiteralPath $stage -Recurse -Force -ErrorAction SilentlyContinue
        }
    }
    if (-not (Test-Path -LiteralPath $gradleExe)) { throw 'Gradle executable missing after installation.' }
    Write-Host "Gradle executable: $gradleExe"
    if ($BuildApk) { $GradleArguments = @('--no-daemon', ':app:assembleDebug') }
    if (-not $GradleArguments -or $GradleArguments.Count -eq 0) { $GradleArguments = @('--version') }
    & $gradleExe @GradleArguments
    exit $LASTEXITCODE
} catch {
    Write-Host "GRADLE SETUP ERROR: $($_.Exception.Message)" -ForegroundColor Red
    exit 1
}

@echo off
setlocal EnableExtensions
cd /d "%~dp0"
echo ===========================================================
echo DIGITALIS ALAIRASGYUJTO - WINDOWS APK BUILD
echo ===========================================================
powershell.exe -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0BUILD_WINDOWS.ps1"
set "BUILD_RC=%ERRORLEVEL%"
if not "%BUILD_RC%"=="0" (
  echo.
  echo HIBA - Lasd: build_naplo.txt
) else (
  echo.
  echo Az APK elkeszult: Digitalis_Alairasgyujto_1_0.apk
)
echo.
pause
exit /b %BUILD_RC%

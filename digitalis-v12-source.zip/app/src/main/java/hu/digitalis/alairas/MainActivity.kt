package hu.digitalis.alairas

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.content.Intent
import android.net.Uri
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.text.InputFilter
import android.widget.Space
import android.graphics.BitmapFactory
import android.content.res.ColorStateList
import android.speech.SpeechRecognizer
import android.graphics.Color
import android.graphics.Bitmap
import android.graphics.pdf.PdfRenderer
import android.os.ParcelFileDescriptor
import java.io.File
import android.graphics.Typeface
import android.os.Bundle
import android.text.Editable
import android.text.InputType
import android.text.TextWatcher
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.CheckBox
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.text.DateFormat
import java.util.Date

/**
 * Kotlin, natív Android UI, telefonon és tableten fut.
 *
 * Képernyők:
 *  - helyi PIN belépés
 *  - kampány/projekt lista és létrehozás
 *  - projekten belüli aláíráslista, szerkesztés/törlés/keresés
 *  - adatlap: diktálás (élő részeredmények), ellenőrizhető mezők,
 *    külön hozzájárulások és érintőképernyős aláírás
 *
 * Az aláírás rögzítése nem minősített (QES) e-aláírási szolgáltatás.
 */
class MainActivity : Activity() {
    // V11: egységes, a felhasználó által jóváhagyott látványterv szerinti paletta.
    private val green = Color.rgb(19, 105, 31)             // elsődleges sötétzöld
    private val greenDark = Color.rgb(12, 74, 25)          // fejléc, ikonok
    private val greenLight = Color.rgb(230, 247, 226)      // teljes oldal háttere
    private val greenBorder = Color.rgb(179, 213, 172)     // panel/mező keret
    private val greenHighlight = Color.rgb(239, 250, 236)  // finom kártyakiemelés
    private val charcoal = Color.rgb(28, 48, 31)
    private val muted = Color.rgb(83, 105, 87)
    private val warning = Color.rgb(125, 72, 16)
    private val faint = Color.rgb(242, 250, 239)
    private lateinit var store: PetitionStore
    private lateinit var pinGate: PinGate
    private lateinit var speech: OfflineSpeech
    private lateinit var exporter: ExportShare
    private lateinit var transfers: ProjectTransfer
    private val importProjectRequest = 710
    private var screen: String = "AUTH"
    private var openCampaign: Long? = null
    private var voiceEdit: EditText? = null
    private var activeVoiceMode = OfflineSpeech.Mode.OFFLINE
    private var voiceStatus: TextView? = null
    private val speechPrefs by lazy { getSharedPreferences("speech_preferences_v08", MODE_PRIVATE) }
    private var lastBackgroundAt: Long = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // Képernyőmentés/előnézeti kép tiltása, mert politikai jellegű személyes adat látható.
        window.setFlags(WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE)
        window.statusBarColor = greenDark
        window.navigationBarColor = greenLight
        @Suppress("DEPRECATION")
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
        pinGate = PinGate(this)
        speech = OfflineSpeech(this)
        exporter = ExportShare(this)
        transfers = ProjectTransfer(this)
        exporter.cleanExpired() // korábbi, átmeneti csatolmányok eltávolítása
        try {
            store = PetitionStore(this, RecordCipher())
            showAuth()
        } catch (e: Exception) {
            showError("A titkosítás nem indítható: ${e.message}")
        }
    }

    override fun onStop() {
        // Ha a felhasználó elhagyta az appot, a mikrofonos felismerést leállítjuk.
        speech.stop()
        lastBackgroundAt = System.currentTimeMillis()
        super.onStop()
    }

    override fun onStart() {
        super.onStart()
        // 60 másodperc háttérben töltött idő után ismét PIN szükséges.
        if (lastBackgroundAt > 0 &&
            System.currentTimeMillis() - lastBackgroundAt > 60_000L &&
            screen != "AUTH" && ::store.isInitialized) {
            showAuth()
        }
        lastBackgroundAt = 0L
    }

    override fun onDestroy() {
        speech.stop()
        super.onDestroy()
    }

    @Deprecated("Legacy back handling")
    override fun onBackPressed() {
        speech.stop()
        when (screen) {
            "ENTRY", "CAMPAIGN_EDIT", "CONTROLLER" -> openCampaign?.let { showCampaign(it) } ?: showCampaigns()
            "CAMPAIGN" -> showCampaigns()
            "DETAIL" -> openCampaign?.let { showCampaign(it) } ?: showCampaigns()
            "GUIDE" -> showCampaigns()
            else -> super.onBackPressed()
        }
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()

    /** Egyetlen vizuális nyelv valamennyi V11-es képernyőn és dialóguson. */
    private fun rounded(fill: Int = Color.WHITE, radius: Int = 16,
                        border: Int = greenBorder, borderDp: Int = 1): GradientDrawable =
        GradientDrawable().apply {
            shape = GradientDrawable.RECTANGLE
            cornerRadius = dp(radius).toFloat()
            setColor(fill)
            if (borderDp > 0) setStroke(dp(borderDp), border)
        }

    private fun touchBackground(fill: Int, radius: Int, stroke: Int,
                                borderWidth: Int = 1): RippleDrawable =
        RippleDrawable(ColorStateList.valueOf(Color.argb(48, 18, 105, 31)),
            rounded(fill, radius, stroke, borderWidth), null)

    private fun column(): LinearLayout = LinearLayout(this).apply {
        orientation = LinearLayout.VERTICAL
        setPadding(dp(18), dp(18), dp(18), dp(26))
        setBackgroundColor(greenLight)
    }

    private fun page(layout: LinearLayout) {
        val scroll = ScrollView(this).apply {
            isFillViewport = true
            clipToPadding = false
            setBackgroundColor(greenLight)
            addView(layout)
        }
        setContentView(scroll)
    }

    private fun heading(parent: LinearLayout, title: String) {
        // Kontrasztos zöld fejléc, középre zárt felirattal és visszalépéssel.
        val header = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            background = GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT,
                intArrayOf(greenDark, green)).apply { cornerRadius = dp(16).toFloat() }
            elevation = dp(3).toFloat()
            setPadding(dp(6), dp(3), dp(6), dp(3))
        }
        val backAllowed = screen != "PROJECTS" && screen != "AUTH"
        val back = TextView(this).apply {
            text = if (backAllowed) "‹" else ""
            textSize = 32f
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            if (backAllowed) {
                contentDescription = "Vissza"
                isClickable = true
                setOnClickListener { onBackPressed() }
            }
        }
        header.addView(back, LinearLayout.LayoutParams(dp(42), dp(52)))
        header.addView(TextView(this).apply {
            text = title
            textSize = 20f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
            maxLines = 2
        }, LinearLayout.LayoutParams(0, -2, 1f))
        header.addView(Space(this), LinearLayout.LayoutParams(dp(42), dp(5)))
        parent.addView(header, LinearLayout.LayoutParams(-1, dp(70)).apply {
            bottomMargin = dp(18)
        })
    }

    private fun label(parent: LinearLayout, value: String, bold: Boolean = false,
                      isWarning: Boolean = false): TextView {
        return TextView(this).also { t ->
            t.text = value
            t.textSize = if (bold) 16f else 14f
            t.setTextColor(if (isWarning) warning else if (bold) greenDark else charcoal)
            if (bold) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            t.setPadding(dp(if (isWarning) 11 else 1), dp(if (isWarning) 10 else 5),
                dp(if (isWarning) 11 else 1), dp(if (isWarning) 10 else 6))
            if (isWarning) {
                t.background = rounded(Color.rgb(255, 248, 233), 11,
                    Color.rgb(228, 202, 151), 1)
            }
            parent.addView(t, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(if (isWarning) 8 else 3)
            })
        }
    }

    private fun button(parent: LinearLayout, title: String, action: () -> Unit): Button {
        return Button(this).also { b ->
            b.text = title
            b.isAllCaps = false
            b.textSize = 15f
            b.setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            b.setTextColor(greenDark)
            b.backgroundTintList = null
            b.background = touchBackground(Color.WHITE, 14, greenBorder)
            b.elevation = dp(1).toFloat()
            b.setPadding(dp(10), dp(6), dp(10), dp(6))
            parent.addView(b, LinearLayout.LayoutParams(-1, dp(55)).apply {
                bottomMargin = dp(9)
            })
            b.setOnClickListener { action() }
        }
    }

    /** Erős, jól felismerhető CTA az 1.11-es egységes design szerint. */
    private fun primaryButton(parent: LinearLayout, title: String, action: () -> Unit): Button {
        return button(parent, title, action).apply {
            background = touchBackground(green, 14, greenDark, 0)
            setTextColor(Color.WHITE)
            textSize = 16f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            elevation = dp(3).toFloat()
            minHeight = dp(58)
            layoutParams = (layoutParams as LinearLayout.LayoutParams).apply { height = dp(60) }
        }
    }

    private fun fieldStyle(e: EditText, multi: Boolean = false) {
        e.textSize = 16f
        e.setTextColor(charcoal)
        e.setHintTextColor(muted)
        e.setPadding(dp(14), dp(10), dp(14), dp(10))
        e.background = rounded(Color.WHITE, 11, greenBorder, 1)
        e.minHeight = dp(if (multi) 112 else 52)
    }

    private fun input(parent: LinearLayout, caption: String, value: String = "",
                      kind: Int = InputType.TYPE_CLASS_TEXT, multi: Boolean = false): EditText {
        label(parent, caption, true).apply { textSize = 14f }
        return EditText(this).also { e ->
            e.setSingleLine(!multi)
            e.inputType = if (multi) InputType.TYPE_CLASS_TEXT or
                InputType.TYPE_TEXT_FLAG_MULTI_LINE or InputType.TYPE_TEXT_FLAG_CAP_SENTENCES
                else kind
            e.setText(value)
            if (multi) e.minLines = 3
            fieldStyle(e, multi)
            parent.addView(e, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(13)
            })
        }
    }

    private fun check(parent: LinearLayout, title: String, value: Boolean = false): CheckBox {
        return CheckBox(this).also { cb ->
            cb.text = title
            cb.isChecked = value
            cb.textSize = 14f
            cb.setTextColor(charcoal)
            cb.buttonTintList = ColorStateList.valueOf(green)
            cb.setPadding(dp(10), dp(7), dp(10), dp(7))
            cb.background = rounded(Color.WHITE, 12, greenBorder, 1)
            cb.minHeight = dp(52)
            parent.addView(cb, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(10)
            })
        }
    }

    /** Fehér, lekerekített információs kártya az új képernyőkompozícióhoz. */
    private fun informationCard(parent: LinearLayout, title: String, body: String): LinearLayout {
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(Color.WHITE, 16, greenBorder)
            setPadding(dp(14), dp(12), dp(14), dp(12))
            elevation = dp(1).toFloat()
        }
        parent.addView(card, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(13)
        })
        label(card, title, true)
        label(card, body)
        return card
    }

    /** Nagy, a bemutató látványtervéhez illő navigációs kártya. */
    private fun menuCard(parent: LinearLayout, symbol: String, title: String,
                         subtitle: String = "", action: () -> Unit) {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(12), dp(10), dp(12), dp(10))
            background = touchBackground(Color.WHITE, 14, greenBorder)
            elevation = dp(2).toFloat()
            isClickable = true
            isFocusable = true
            contentDescription = title
            setOnClickListener { action() }
        }
        parent.addView(row, LinearLayout.LayoutParams(-1, -2).apply {
            bottomMargin = dp(10)
        })
        row.addView(TextView(this).apply {
            text = symbol
            gravity = Gravity.CENTER
            textSize = 25f
            setTextColor(greenDark)
            background = rounded(greenHighlight, 12, greenBorder)
        }, LinearLayout.LayoutParams(dp(48), dp(48)).apply { rightMargin = dp(12) })
        val textGroup = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        row.addView(textGroup, LinearLayout.LayoutParams(0, -2, 1f))
        textGroup.addView(TextView(this).apply {
            text = title
            textSize = 16f
            setTextColor(greenDark)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        })
        if (subtitle.isNotBlank()) textGroup.addView(TextView(this).apply {
            text = subtitle
            textSize = 12f
            setTextColor(muted)
            maxLines = 2
        })
        row.addView(TextView(this).apply {
            text = "›"
            textSize = 30f
            gravity = Gravity.CENTER
            setTextColor(greenDark)
        }, LinearLayout.LayoutParams(dp(24), -2))
    }

    private fun brand(parent: LinearLayout) {
        val hero = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            background = rounded(greenHighlight, 18, greenBorder)
            setPadding(dp(14), dp(16), dp(14), dp(14))
        }
        parent.addView(hero, LinearLayout.LayoutParams(-1, -2).apply {
            topMargin = dp(10) // 20dp-rel lejjebb, a korábbi kérés szerint
            bottomMargin = dp(14)
        })
        hero.addView(ImageView(this).apply {
            setImageResource(R.drawable.mi_hazank)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(-1, dp(115)))
        hero.addView(TextView(this).apply {
            text = "Digitális aláírásgyűjtő"
            gravity = Gravity.CENTER
            textSize = 18f
            setTextColor(greenDark)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(8) })
        hero.addView(TextView(this).apply {
            text = "Verzió 1.12"
            gravity = Gravity.CENTER
            textSize = 13f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(2) })
    }

    private fun showError(message: String) {
        val l = column()
        heading(l, "Az alkalmazás nem indítható")
        label(l, message, isWarning = true)
        page(l)
    }

    /** V11: teljes halványzöld, minden elemében középre rendezett PIN-kezdőlap. */
    private fun showAuth() {
        speech.stop()
        screen = "AUTH"
        val isNew = !pinGate.isConfigured()
        val shell = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setBackgroundColor(greenLight)
            setPadding(dp(20), dp(15), dp(20), dp(16))
        }
        shell.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
        }
        val pageWidth = (resources.displayMetrics.widthPixels - dp(40)).coerceAtMost(dp(440))
        shell.addView(content, LinearLayout.LayoutParams(pageWidth, -2))
        content.addView(ImageView(this).apply {
            setImageResource(R.drawable.mi_hazank)
            adjustViewBounds = true
            scaleType = ImageView.ScaleType.FIT_CENTER
        }, LinearLayout.LayoutParams(-1, dp(135)))
        content.addView(TextView(this).apply {
            text = "Digitális aláírásgyűjtő"
            gravity = Gravity.CENTER
            setTextColor(greenDark)
            textSize = 23f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4) })
        content.addView(TextView(this).apply {
            text = "Adatgyűjtő alkalmazás"
            gravity = Gravity.CENTER
            setTextColor(greenDark)
            textSize = 15f
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(4); bottomMargin = dp(18) })

        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER_HORIZONTAL
            setPadding(dp(16), dp(16), dp(16), dp(14))
            background = rounded(Color.WHITE, 17, greenBorder, 2)
            elevation = dp(2).toFloat()
        }
        content.addView(card, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        card.addView(TextView(this).apply {
            text = if (isNew) "Állítsa be a PIN-kódot!" else "Adja meg a PIN-kódot!"
            gravity = Gravity.CENTER
            setTextColor(greenDark)
            textSize = 17f
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(8) })
        val pin = EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(6))
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            gravity = Gravity.CENTER
            setShowSoftInputOnFocus(false)
            contentDescription = "Hatjegyű belépési PIN"
            fieldStyle(this)
        }
        card.addView(pin, LinearLayout.LayoutParams(-1, dp(51)).apply { bottomMargin = dp(6) })
        val repeat = if (isNew) EditText(this).apply {
            inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD
            filters = arrayOf(InputFilter.LengthFilter(6))
            textAlignment = View.TEXT_ALIGNMENT_CENTER
            gravity = Gravity.CENTER
            setShowSoftInputOnFocus(false)
            contentDescription = "PIN-kód megismétlése"
            fieldStyle(this)
        }.also {
            card.addView(TextView(this).apply {
                text = "PIN megismétlése"
                setTextColor(muted)
                textSize = 13f
                gravity = Gravity.CENTER
            })
            card.addView(it, LinearLayout.LayoutParams(-1, dp(51)))
        } else null
        var focused: EditText = pin
        pin.setOnFocusChangeListener { _, has -> if (has) focused = pin }
        repeat?.setOnFocusChangeListener { _, has -> if (has) focused = repeat }
        pin.requestFocus()
        card.addView(TextView(this).apply {
            text = "Pontosan 6 számjegy. Az alkalmazás nem tárolja a PIN-t olvasható formában."
            textSize = 12f
            gravity = Gravity.CENTER
            setTextColor(muted)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(9) })

        fun submit() {
            val code = pin.text.toString()
            if (code.length != 6 || code.any { !it.isDigit() }) {
                toast("Pontosan 6 számjegy szükséges")
            } else if (isNew) {
                if (code != repeat?.text.toString()) toast("A két PIN nem egyezik")
                else {
                    try { pinGate.register(code); afterAuth() }
                    catch (e: Exception) { toast("Nem sikerült: ${e.message}") }
                }
            } else if (pinGate.verify(code)) afterAuth()
            else toast(if (pinGate.isBlocked())
                "Túl sok sikertelen próbálkozás; 15 percig zárolva." else "Hibás PIN")
        }

        // A látványterv három oszlopos PIN-billentyűzete, jól elérhető gombokkal.
        val keypad = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(keypad, LinearLayout.LayoutParams(-1, -2))
        val rows = listOf(listOf("1", "2", "3"), listOf("4", "5", "6"),
            listOf("7", "8", "9"), listOf("⌫", "0", "✓"))
        rows.forEach { numbers ->
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            keypad.addView(line, LinearLayout.LayoutParams(-1, dp(53)).apply {
                bottomMargin = dp(6)
            })
            numbers.forEach { digit ->
                val key = Button(this).apply {
                    text = digit
                    isAllCaps = false
                    textSize = 21f
                    setTypeface(Typeface.DEFAULT, Typeface.BOLD)
                    setTextColor(if (digit == "✓") Color.WHITE else greenDark)
                    background = touchBackground(if (digit == "✓") green else Color.WHITE,
                        11, greenBorder, if (digit == "✓") 0 else 1)
                    contentDescription = when (digit) {
                        "⌫" -> "Utolsó számjegy törlése"
                        "✓" -> "Belépés vagy PIN mentése"
                        else -> "$digit számjegy"
                    }
                    setOnClickListener {
                        when (digit) {
                            "⌫" -> {
                                val txt = focused.text.toString()
                                if (txt.isNotEmpty()) focused.setText(txt.dropLast(1))
                            }
                            "✓" -> submit()
                            else -> {
                                if (focused.text.length < 6)
                                    focused.setText(focused.text.toString() + digit)
                                if (focused == pin && isNew && pin.text.length == 6)
                                    repeat?.requestFocus()
                            }
                        }
                    }
                }
                line.addView(key, LinearLayout.LayoutParams(0, -1, 1f).apply {
                    leftMargin = dp(3); rightMargin = dp(3)
                })
            }
        }
        content.addView(TextView(this).apply {
            text = "A PIN-kódot csak a készüléken ellenőrizzük."
            gravity = Gravity.CENTER
            textSize = 12f
            setTextColor(muted)
        }, LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(5) })
        shell.addView(Space(this), LinearLayout.LayoutParams(1, 0, 1f))
        shell.addView(TextView(this).apply {
            text = "Verzió 1.12"
            setTextColor(greenDark)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
            gravity = Gravity.CENTER
            textSize = 14f
        }, LinearLayout.LayoutParams(-1, -2))
        setContentView(ScrollView(this).apply {
            isFillViewport = true
            setBackgroundColor(greenLight)
            addView(shell)
        })
    }

    private fun afterAuth() {
        try {
            // Első indításkor egységes, titkosított központi profil: később szerkeszthető.
            store.initializeControllerDefaultsIfAbsent()
            val prefs = getSharedPreferences("app_state", MODE_PRIVATE)
            if (!prefs.getBoolean("seeded_v1", false)) {
                // A mellékelt ív címét és leírását előkészítjük; személyes adatot nem importálunk.
                store.saveCampaign(Campaign(
                    title = "STOP Palagáz!",
                    description = "Ne engedjük, hogy hidraulikus rétegrepesztéssel fúrjanak " +
                        "nemzetközi óriásvállalatok a vízszegény Homokhátságon a profitjuk " +
                        "érdekében, veszélyeztetve a felelős szénhidrogén-gazdálkodást és a vízkészletet!",
                    privacyNotice = DefaultPrivacy.NOTICE
                ))
                prefs.edit().putBoolean("seeded_v1", true).apply()
            }
            // Régi gyári helykitöltő tisztítása kizárólag aláíró nélküli projektnél.
            if (!prefs.getBoolean("policy_placeholder_cleaned_v07", false)) {
                store.campaigns().forEach { c ->
                    if (!c.approvedForRealData && c.privacyNotice.startsWith("DEMO.") &&
                        store.signers(c.id).isEmpty()) store.saveCampaign(c.copy(privacyNotice = ""))
                }
                prefs.edit().putBoolean("policy_placeholder_cleaned_v07", true).apply()
            }
            // Standard szöveg hiányzó tájékoztatóhoz; a saját, már jóváhagyott
            // tájékoztatót soha nem írjuk felül. Jóváhagyás nem automatikus.
            if (!prefs.getBoolean("default_privacy_v09_seeded", false)) {
                store.campaigns().forEach { c ->
                    if (c.privacyNotice.isBlank())
                        store.saveCampaign(c.copy(privacyNotice = DefaultPrivacy.NOTICE,
                            approvedForRealData = false))
                }
                prefs.edit().putBoolean("default_privacy_v09_seeded", true).apply()
            }
            showCampaigns()
        } catch (e: Exception) { showError("Adatbázishiba: ${e.message}") }
    }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()

    private fun confirm(title: String, message: String, action: () -> Unit) {
        AlertDialog.Builder(this).setTitle(title).setMessage(message)
            .setNegativeButton("Mégse", null)
            .setPositiveButton("Igen") { _, _ -> action() }
            .show()
    }

    /** Minden képernyő és export ugyanazt az adatkezelői profilt használja. */
    private fun effectiveCampaign(c: Campaign): Campaign {
        val profile = store.controllerProfile()
        return c.copy(controller = profile.name, contact = profile.contact,
            contactPerson = profile.contactPerson, privacyNotice = profile.privacyNotice)
    }

    private fun showControllerSettings(backToCampaign: Long? = null) {
        speech.stop()
        screen = "CONTROLLER"
        val root = column()
        heading(root, "Központi adatkezelő")
        label(root, "A szervezet, a kapcsolattartó neve és telefonszáma " +
            "és az adatkezelési tájékoztató egységesen jelenik meg minden projektnél. " +
            "A központi tájékoztató módosítása esetén a projektjóváhagyásokat meg kell újítani.")
        val old = store.controllerProfile()
        val name = input(root, "Adatkezelő szervezet *", old.name)
        val person = input(root, "Kapcsolattartó neve *", old.contactPerson)
        val contact = input(root, "Kapcsolattartó telefonszáma *", old.contact,
            InputType.TYPE_CLASS_PHONE)
        val notice = input(root, "Központi adatkezelési tájékoztató *", old.privacyNotice, multi = true)
        label(root, "A tájékoztató legalább 120 karakter legyen; jogi ellenőrzés szükséges.", isWarning = true)
        primaryButton(root, "Központi adatkezelő mentése") {
            val normalizedContact = FieldFormatter.phone(contact.text.toString())
            if (!FieldFormatter.validPhone(normalizedContact)) {
                toast("A telefonszám hibás vagy hiányos – pl. +36 70 613 2776")
                return@primaryButton
            }
            val config = ControllerProfile(name.text.toString().trim(),
                normalizedContact, person.text.toString().trim(),
                notice.text.toString().trim())
            if (!config.complete()) {
                toast("A szervezet, kapcsolattartó és a legalább 120 karakteres tájékoztató kötelező")
                return@primaryButton
            }
            try {
                store.saveControllerProfile(config)
                toast("Az adatkezelő egységesen mentve")
                if (backToCampaign == null) showCampaigns() else showCampaign(backToCampaign)
            } catch (e: Exception) { toast("Mentési hiba: ${e.message}") }
        }
        button(root, "Vissza") {
            if (backToCampaign == null) showCampaigns() else showCampaign(backToCampaign)
        }
        page(root)
    }

    /** Áttekinthető V11-főmenü, lekerekített menükártyákkal és zöld arculattal. */
    private fun showCampaigns() {
        speech.stop(); screen = "PROJECTS"; openCampaign = null
        val root = column()
        brand(root)
        val profile = store.controllerProfile()
        informationCard(root, "Központi adatkezelő",
            if (profile.complete())
                "${profile.name}  •  ${profile.contactPerson}  •  ${profile.contact}"
            else "Az adatkezelői adatok még nincsenek teljesen megadva.")
        menuCard(root, "✍", "Aláírásgyűjtés", "Válasszon projektet a listából") {
            val first = store.campaigns().firstOrNull()
            if (first != null) showCampaign(first.id) else showCampaignEditor(null)
        }
        menuCard(root, "✚", "Új projekt létrehozása", "Cím, leírás, adatkezelés") {
            showCampaignEditor(null)
        }
        menuCard(root, "⇩", "Projekt importálása", "PIN-védett ZIP átvétele másik telefonról") {
            chooseProjectImport()
        }
        menuCard(root, "⚙", "Beállítások", "Adatkezelő és kapcsolattartó") {
            showControllerSettings()
        }
        menuCard(root, "ⓘ", "Használati útmutató", "Részletes, 16 oldalas útmutató; PDF megosztása") {
            showManual()
        }
        label(root, "PROJEKTJEIM", true).apply {
            setPadding(dp(2), dp(14), 0, dp(10))
        }
        try {
            val campaigns = store.campaigns()
            if (campaigns.isEmpty()) informationCard(root,
                "Még nincs projekt", "Hozzon létre egyet a fenti gombbal, vagy importáljon egy meglévőt.")
            campaigns.forEach { c ->
                val count = store.signers(c.id).size
                menuCard(root, "▣", c.title, "$count rögzített aláírás • Megnyitás") {
                    showCampaign(c.id)
                }
            }
        } catch (e: Exception) {
            label(root, "Projektbetöltési hiba: ${e.message}", isWarning = true)
        }
        label(root, "A projektek átadása a projektoldalról PIN-védett ZIP segítségével történik.")
        label(root, "Verzió 1.12", true).apply { gravity = Gravity.CENTER }
        page(root)
    }

    /**
     * A 16 oldalas, a csomag részeként érkező PDF-et közvetlenül a készüléken
     * jelenítjük meg az Android PdfRendererrel. Az útmutató megtekintéséhez
     * sem internetkapcsolat, sem külső PDF-olvasó alkalmazás nem szükséges.
     *
     * Nem a saját aláírói adatbázist jelenítjük meg: az ábrák fiktív adatokat
     * tartalmazó képernyővázlatok, ezért a dokumentum megosztható.
     */
    private fun showManual() {
        speech.stop()
        screen = "GUIDE"
        openCampaign = null
        val root = column()
        heading(root, "Használati útmutató")
        label(root, "Verzió 1.12 • 16 oldal • offline olvasható", true)
        label(root, "A teljes működés, adatkezelés, ZIP PIN-védelem és e-mailes megosztás " +
            "leírása. A képernyőábrák szemléltető illusztrációk.")
        val guide = File(cacheDir, "alairasgyujto_utmutato_v12.pdf")
        try {
            // A telepített alkalmazás assets/ mappájából készül egy helyi példány.
            if (!guide.exists() || guide.length() == 0L) {
                assets.open("utmutato.pdf").use { input ->
                    guide.outputStream().use { output -> input.copyTo(output) }
                }
            }
            // Oldalszámot külön nyitással olvassuk: nincs nyitva tartott PDF leíró.
            val pageCount = ParcelFileDescriptor.open(guide,
                ParcelFileDescriptor.MODE_READ_ONLY).use { descriptor ->
                PdfRenderer(descriptor).use { it.pageCount }
            }
            var current = 0
            val counter = label(root, "1 / $pageCount", true).apply {
                gravity = Gravity.CENTER
            }
            val documentImage = ImageView(this).apply {
                adjustViewBounds = true
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = rounded(Color.WHITE, 12, greenBorder, 2)
                contentDescription = "Használati útmutató, 1. oldal"
            }
            root.addView(documentImage, LinearLayout.LayoutParams(-1, -2).apply {
                bottomMargin = dp(12)
            })
            fun drawCurrentPage() {
                try {
                    ParcelFileDescriptor.open(guide, ParcelFileDescriptor.MODE_READ_ONLY).use { fd ->
                        PdfRenderer(fd).use { renderer ->
                            renderer.openPage(current).use { page ->
                                val maxWidth = (resources.displayMetrics.widthPixels - dp(48))
                                    .coerceIn(320, 1100)
                                val height = (maxWidth.toFloat() * page.height / page.width)
                                    .toInt().coerceAtLeast(1)
                                val bitmap = Bitmap.createBitmap(maxWidth, height,
                                    Bitmap.Config.ARGB_8888)
                                bitmap.eraseColor(Color.WHITE)
                                page.render(bitmap, null, null,
                                    PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                                documentImage.setImageBitmap(bitmap)
                            }
                        }
                    }
                    counter.text = "${current + 1} / $pageCount"
                    documentImage.contentDescription =
                        "Használati útmutató, ${current + 1}. oldal"
                } catch (error: Exception) {
                    toast("PDF oldal nem nyitható meg: ${error.message}")
                }
            }
            val navigation = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
            root.addView(navigation, LinearLayout.LayoutParams(-1, -2))
            val previous = button(navigation, "‹ Előző") {
                if (current > 0) { current--; drawCurrentPage() }
            }
            val next = button(navigation, "Következő ›") {
                if (current + 1 < pageCount) { current++; drawCurrentPage() }
            }
            (previous.layoutParams as LinearLayout.LayoutParams).apply {
                width = 0; weight = 1f; rightMargin = dp(5)
            }
            (next.layoutParams as LinearLayout.LayoutParams).apply {
                width = 0; weight = 1f; leftMargin = dp(5)
            }
            primaryButton(root, "PDF megosztása / e-mail") {
                try {
                    val folder = File(cacheDir, "share_out").apply { mkdirs() }
                    val attachment = File(folder, "Digitalis_Alairasgyujto_V12_Utmutato.pdf")
                    guide.copyTo(attachment, overwrite = true)
                    exporter.openShareSheet(attachment, "application/pdf",
                        "Digitális aláírásgyűjtő – V12 használati útmutató",
                        "A mellékelt PDF az alkalmazás működését és adatbiztonsági tudnivalóit ismerteti.")
                } catch (error: Exception) {
                    toast("Az útmutató nem osztható meg: ${error.message}")
                }
            }
            button(root, "Vissza a főmenübe") { showCampaigns() }
            drawCurrentPage()
            page(root)
        } catch (error: Exception) {
            label(root, "Nem sikerült betölteni a PDF-útmutatót: ${error.message}",
                isWarning = true)
            button(root, "Vissza a főmenübe") { showCampaigns() }
            page(root)
        }
    }

    /** A projektszerkesztő biztosítja a felhasználó által kért tetszőleges kampányokat. */
    private fun showCampaignEditor(existing: Campaign?) {
        screen = "CAMPAIGN_EDIT"; openCampaign = existing?.id
        val root = column()
        heading(root, if (existing == null) "Új projekt" else "Projekt szerkesztése")
        val title = input(root, "Kampány címe *", existing?.title.orEmpty())
        val desc = input(root, "Rövid kampányleírás", existing?.description.orEmpty(), multi = true)
        label(root, "Adatvédelmi beállítások", true)
        val profile = store.controllerProfile()
        label(root, "Adatkezelő szervezet: ${profile.name.ifBlank { "Nincs beállítva" }}")
        label(root, "Kapcsolattartó neve: ${profile.contactPerson.ifBlank { "Nincs beállítva" }}")
        label(root, "Kapcsolattartó telefonszáma: ${profile.contact.ifBlank { "Nincs beállítva" }}")
        button(root, "Központi adatkezelő beállítása") {
            showControllerSettings(existing?.id)
        }
        label(root, "A tájékoztató a központi adatkezelői beállításokban szerkeszthető.")
        label(root, profile.privacyNotice)
        label(root, "A központi szöveg jogi ellenőrzést igényel, a projekthez külön jóváhagyás tartozik.", isWarning = true)
        val policy = input(root, "Tájékoztató verziója", existing?.policyVersion ?: "1.0")
        val retention = input(root, "Megőrzési idő (nap; jogilag jóváhagyandó)",
            (existing?.retentionDays ?: 180).toString(), InputType.TYPE_CLASS_NUMBER)
        val ready = check(root,
            "Az adatkezelő jóváhagyta a szövegeket és az éles adatgyűjtést.",
            existing?.approvedForRealData ?: false)
        label(root, "A pipa nem helyettesíti az adatvédelmi ellenőrzést, és nem automatikus GDPR-megfelelőségi igazolás.", isWarning = true)
        primaryButton(root, "Projekt mentése") {
            val days = retention.text.toString().toIntOrNull()
            if (title.text.isBlank() || days == null || days <= 0) {
                toast("Cím és pozitív megőrzési idő szükséges"); return@primaryButton
            }
            val data = Campaign(existing?.id ?: 0, title.text.toString().trim(),
                desc.text.toString().trim(), profile.name,
                profile.contact, profile.privacyNotice,
                policy.text.toString().trim(), days, ready.isChecked,
                contactPerson = profile.contactPerson)
            if (ready.isChecked && !data.isReadyForRealData()) {
                toast("Éles mód: adatkezelő, kapcsolat, legalább 120 karakteres tájékoztató és megőrzési idő szükséges")
                return@primaryButton
            }
            try {
                val id = store.saveCampaign(data)
                showCampaign(id)
            } catch (e: Exception) { toast("Nem menthető: ${e.message}") }
        }
        if (existing != null) {
            button(root, "Projekt és aláírásai törlése") {
                confirm("Projekt végleges törlése",
                    "A(z) ${existing.title} projekt MINDEN aláírását is véglegesen törli. Folytatja?") {
                    try { store.removeCampaign(existing.id); showCampaigns() }
                    catch (e: Exception) { toast("Törlési hiba: ${e.message}") }
                }
            }
        }
        button(root, "Vissza") {
            if (existing == null) showCampaigns() else showCampaign(existing.id)
        }
        page(root)
    }

    private fun showCampaign(id: Long) {
        speech.stop(); screen = "CAMPAIGN"; openCampaign = id
        val rawCampaign = store.campaign(id)
        if (rawCampaign == null) { showCampaigns(); return }
        val campaign = effectiveCampaign(rawCampaign)
        val root = column()
        brand(root)
        heading(root, campaign.title)
        label(root, campaign.description)
        label(root, "Adatkezelő: ${campaign.controller} | Kapcsolattartó: ${campaign.contactPerson} | ${campaign.contact}")
        if (!campaign.isReadyForRealData())
            label(root, "Az adatrögzítéshez előbb állítsa be a központi adatkezelőt " +
                "és hagyja jóvá a projekt adatkezelési tájékoztatóját.", isWarning = true)
        primaryButton(root, "+ Új személy felvétele") {
            if (campaign.isReadyForRealData()) showSignerEditor(campaign, null)
            else showPrivacyRequired(campaign)
        }
        menuCard(root, "⚙", "Projekt beállításai", "Leírás, adatkezelés és tájékoztató") {
            showCampaignEditor(campaign)
        }
        val all = store.signers(id)
        label(root, "Mentett aláírások: ${all.size}", true)
        label(root, "Kérdőívek táblázatban – megosztás / e-mail", true)
        menuCard(root, "⇧", "Projekt exportálása", "Teljes beállításcsomag, 6 jegyű PIN") {
            showProjectExportDialog(campaign, all)
        }
        menuCard(root, "▤", "Kitöltött adatlapok exportálása", "Titkosított ZIP, 6 jegyű PIN") {
            showEncryptedShareDialog(campaign, all)
        }
        val search = input(root, "Keresés név vagy település szerint")
        val resultList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(resultList)

        fun render(q: String) {
            resultList.removeAllViews()
            val matching = all.filter {
                it.fullName.contains(q, true) || it.city.contains(q, true)
            }
            if (matching.isEmpty()) label(resultList, "Nincs találat.")
            matching.forEach { s ->
                val box = LinearLayout(this).apply {
                    orientation = LinearLayout.VERTICAL
                    setPadding(dp(10), dp(10), dp(10), dp(10))
                    background = rounded(Color.WHITE, 14, greenBorder)
                    elevation = dp(1).toFloat()
                }
                resultList.addView(box, LinearLayout.LayoutParams(-1, -2).apply {
                    bottomMargin = dp(9)
                })
                label(box, s.fullName, true)
                label(box, listOf(s.postalCode, s.city).filter { it.isNotBlank() }
                    .joinToString(" ") + " • " +
                    DateFormat.getDateTimeInstance().format(Date(s.signedAt)))
                label(box, "Hírlevél: ${consentAnswer(s.newsletter)}  •  " +
                    "Szimpatizáns: ${consentAnswer(s.sympathizer)}")
                label(box, "Tájékoztató megismerve: ${consentAnswer(s.privacyRead)}  •  " +
                    "Kifejezett hozzájárulás: ${consentAnswer(s.explicitConsent)}")
                button(box, "Adatlap és hozzájárulások megtekintése") {
                    showSignerDetails(campaign, s)
                }
                button(box, "Adatok módosítása (új aláírással)") {
                    showSignerEditor(campaign, s)
                }
                button(box, "Aláírás törlése") {
                    confirm("Aláírás törlése", "Törli a kiválasztott aláírást? A művelet nem vonható vissza.") {
                        try { store.removeSigner(s); showCampaign(id) }
                        catch (e: Exception) { toast("Törlési hiba: ${e.message}") }
                    }
                }
            }
        }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) = Unit
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {
                render(s?.toString().orEmpty())
            }
            override fun afterTextChanged(s: Editable?) = Unit
        })
        render("")
        button(root, "Vissza a projektekhez") { showCampaigns() }
        page(root)
    }

    /** A MENTETT hozzájárulási állapotok megjelenítése: nincs új hozzájárulás, nincs módosítás. */
    private fun consentAnswer(checked: Boolean): String = if (checked) "Igen" else "Nem"

    private fun showSignerDetails(campaign: Campaign, person: Signer) {
        speech.stop()
        screen = "DETAIL"
        openCampaign = campaign.id
        val root = column()
        heading(root, "Mentett személy és hozzájárulások")
        label(root, "Projekt: ${campaign.title}", true)
        label(root, "Név: ${person.fullName}")
        label(root, "E-mail: ${person.email.ifBlank { "Nincs megadva" }}")
        label(root, "Telefonszám: ${person.phone.ifBlank { "Nincs megadva" }}")
        label(root, "Lakcím: ${listOf(person.postalCode, person.city, person.streetAddress).filter { it.isNotBlank() }.joinToString(" ")}")
        label(root, "Mentéskor rögzített nyilatkozatok", true)
        label(root, "Ezek a jelölések a korábban titkosítva elmentett adatokat mutatják. " +
            "A megtekintés nem jelent új hozzájárulást.")
        val statuses = listOf(
            "Hírlevélre feliratkozott" to person.newsletter,
            "Szimpatizánsnak jelentkezett" to person.sympathizer,
            "Adatkezelési tájékoztatót megismerte" to person.privacyRead,
            "Kifejezett hozzájárulást megadta" to person.explicitConsent
        )
        statuses.forEach { (description, value) ->
            check(root, "$description – ${consentAnswer(value)}", value).apply {
                isEnabled = false
                alpha = 1f // letiltva is jól látható a mentett állapot
            }
        }
        label(root, "Tájékoztató verziója az aláíráskor: ${person.policyVersion.ifBlank { "Nincs rögzítve" }}")
        label(root, "Hozzájárulás rögzítve: ${if (person.consentAt > 0L) DateFormat.getDateTimeInstance().format(Date(person.consentAt)) else "Nincs rögzítve"}")
        label(root, "Aláírás időpontja: ${if (person.signedAt > 0L) DateFormat.getDateTimeInstance().format(Date(person.signedAt)) else "Nincs rögzítve"}")
        label(root, "Rekordazonosító: ${person.recordUid.ifBlank { person.id.toString() }}")
        if (person.signaturePng.isNotEmpty()) {
            val bitmap = BitmapFactory.decodeByteArray(person.signaturePng, 0, person.signaturePng.size)
            if (bitmap != null) {
                label(root, "Rögzített aláírás", true)
                root.addView(ImageView(this).apply {
                    setImageBitmap(bitmap)
                    adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                    background = rounded(greenLight, 14, greenBorder, 3)
                }, LinearLayout.LayoutParams(-1, dp(170)))
            }
        }
        label(root, "Az adatok módosításához új aláírás és ismételt kifejezett hozzájárulás szükséges.")
        primaryButton(root, "Adatok módosítása / új aláírás") {
            showSignerEditor(campaign, person)
        }
        button(root, "Vissza a projekthez") { showCampaign(campaign.id) }
        page(root)
    }

    /** Megosztás: projekt és közös adatkezelői profil, opcionálisan személyek. */
    private fun showProjectExportDialog(campaign: Campaign, signers: List<Signer>) {
        val root = column()
        label(root, "A projekt címe, leírása, adatkezelési tájékoztatója, megőrzési ideje, " +
            "verziója és az adatkezelő teljes kapcsolattartási profilja mindig átkerül.")
        val include = check(root,
            "Személyek és aláírásaik hozzáadása is (${signers.size} rekord) – alapból kikapcsolva", false)
        label(root, "Személyes adatokkal történő továbbküldéshez külön jogalap és " +
            "megfelelő címzett szükséges. Hatjegyű ZIP PIN esetén a titkosítás " +
            "lényegesen gyengébb a hosszú jelszavas védelemnél.", isWarning = true)
        val pin = input(root, "Projektcsomag PIN (pontosan 6 számjegy)", kind =
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val repeat = input(root, "PIN megismétlése", kind =
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        pin.filters = arrayOf(InputFilter.LengthFilter(6))
        repeat.filters = arrayOf(InputFilter.LengthFilter(6))
        val authorized = check(root,
            "Jogosult vagyok a kiválasztott projektadatokat átadni a címzettnek.")
        val dialog = AlertDialog.Builder(this)
            .setTitle("Projekt exportálása")
            .setView(ScrollView(this).apply { addView(root) })
            .setNegativeButton("Mégse", null)
            .setPositiveButton("ZIP készítése és megosztása", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = pin.text.toString()
                if (!value.matches(Regex("[0-9]{6}")) || value != repeat.text.toString()) {
                    toast("Pontosan hat számjegyű, két egyező PIN szükséges")
                    return@setOnClickListener
                }
                if (!authorized.isChecked) {
                    toast("Az adatátadás jogosultságát meg kell erősíteni")
                    return@setOnClickListener
                }
                try {
                    val secret = value.toCharArray()
                    val file = try {
                        transfers.exportProject(campaign, store.controllerProfile(), signers,
                            include.isChecked, secret)
                    } finally { secret.fill('\u0000') }
                    try { store.recordPreparedExport(campaign.id) }
                    catch (e: Exception) { file.delete(); throw e }
                    pin.text?.clear(); repeat.text?.clear()
                    dialog.dismiss()
                    exporter.openShareSheet(file, "application/zip",
                        "Projektátadás – ${campaign.title}",
                        "Titkosított projektcsomag. A hatjegyű PIN-t külön, " +
                            "biztonságos csatornán közölje a címzettel.")
                } catch (e: Exception) { toast("Projekt export hiba: ${e.message}") }
            }
        }
        dialog.show()
    }

    /** Másik készülékről érkezett, titkosított ZIP kiválasztása. */
    private fun chooseProjectImport() {
        val intent = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "application/zip"
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        try { startActivityForResult(intent, importProjectRequest) }
        catch (e: Exception) { toast("Nem nyitható meg a fájlválasztó: ${e.message}") }
    }

    @Deprecated("Legacy activity result")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == importProjectRequest && resultCode == RESULT_OK) {
            data?.data?.let { showProjectImportPinDialog(it) }
        }
    }

    /** Előbb ellenőrizzük a PIN-t és a projektet, csak azután engedjük az importot. */
    private fun showProjectImportPinDialog(uri: Uri) {
        val root = column()
        label(root, "Válassza a projekt átadásakor megadott 6 jegyű PIN-kódot. " +
            "Azonos projekt esetén felajánlja az aláírások egyesítését; a meglévő adatok nem íródnak felül.")
        val pass = input(root, "Projektcsomag PIN", kind =
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        pass.filters = arrayOf(InputFilter.LengthFilter(6))
        val dialog = AlertDialog.Builder(this)
            .setTitle("Projekt ZIP beolvasása")
            .setView(root)
            .setNegativeButton("Mégse", null)
            .setPositiveButton("Beolvasás", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                val value = pass.text.toString()
                if (!value.matches(Regex("[0-9]{6}"))) {
                    toast("A ZIP beolvasásához pontosan 6 számjegy szükséges")
                    return@setOnClickListener
                }
                try {
                    val secret = value.toCharArray()
                    val result = try { transfers.importProject(uri, secret) }
                    finally { secret.fill('\u0000') }
                    pass.text?.clear()
                    dialog.dismiss()
                    confirmImportedProject(result)
                } catch (e: Exception) {
                    toast("Nem olvasható be a projekt: ellenőrizze a PIN-t és a ZIP-et. ${e.message}")
                }
            }
        }
        dialog.show()
    }

    /**
     * V12 projekt-egyesítés: előbb projekt-UUID, majd név ÉS leírás alapján.
     * Csak azonos név nem elég: az egyértelműséget minden esetben kijelezzük.
     * A személyadatok összevonását az adattár tranzakcióban, UUID/aláírás/
     * név+elérhetőség szabállyal, a meglévő adatok felülírása nélkül végzi.
     */
    private fun confirmImportedProject(imported: ProjectTransfer.ImportedProject) {
        val local = store.campaigns()
        val incoming = imported.campaign
        val matchingUid = incoming.projectUid.takeIf { it.isNotBlank() }?.let { uid ->
            local.firstOrNull { it.projectUid == uid }
        }
        val sameContent = local.filter {
            TransferMerge.sameProjectName(it.title, incoming.title) &&
                TransferMerge.sameDescription(it.description, incoming.description)
        }
        val target = matchingUid ?: sameContent.singleOrNull()
        val nameCollision = target == null && local.any {
            TransferMerge.sameProjectName(it.title, incoming.title)
        }
        val preview = target?.let { TransferMerge.preview(store.signers(it.id), imported.signers) }
        val root = column()
        label(root, "Projekt: ${incoming.title}", true)
        label(root, "Leírás: ${incoming.description.take(240)}")
        label(root, "Forrás adatkezelője: ${imported.controller.name} | " +
            "${imported.controller.contactPerson} | ${imported.controller.contact}")
        label(root, "Beérkezett személyek/aláírások: ${imported.signers.size}.")
        if (target != null) {
            label(root, "Egyező projekt található: ${target.title}. Nem készül duplikált projekt.", true)
            label(root, "Egyesítési előnézet: ${preview?.toAdd ?: 0} új, " +
                "${preview?.duplicates ?: 0} már meglévő/azonos aláírási rekord.")
            label(root, "A meglévő adatok, aláírások és projektbeállítások változatlanul maradnak.")
        } else if (nameCollision) {
            label(root, "Figyelem: már van ilyen nevű, de eltérő leírású projekt! " +
                "Az automatikus egyesítés nem biztonságos. Csak külön projekt készíthető; " +
                "kérjük, ellenőrizze a leírásokat.", isWarning = true)
        } else {
            label(root, "Ilyen projekt még nincs. Új projekt jön létre.")
        }
        if (target == null) {
            label(root, "Az új projekt adatkezelési jóváhagyását az import után újra meg kell adni.",
                isWarning = true)
        }
        val updateController = check(root,
            "A csomag adatkezelői profilját állítsuk be a teljes telefon központi " +
                "adatkezelőjének is (minden más projektre hat)", false)
        val accept = if (imported.signers.isNotEmpty()) check(root,
            "Jogosult vagyok a csomag személyes adatainak és aláírásainak importálására.", false)
            else null
        val dialog = AlertDialog.Builder(this)
            .setTitle(if (target != null) "Projekt egyesítése" else "Projekt importálásának jóváhagyása")
            .setView(ScrollView(this).apply { addView(root) })
            .setNegativeButton("Mégse", null)
            .setPositiveButton(if (target != null) "Új aláírások egyesítése" else "Új projekt létrehozása", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (accept != null && !accept.isChecked) {
                    toast("A személyes adatok importálásához külön jogosultság szükséges")
                    return@setOnClickListener
                }
                val execute = {
                    try {
                        val override = if (updateController.isChecked) imported.controller else null
                        if (target != null) {
                            val done = store.mergeTransferredProject(target.id, imported.signers, override)
                            dialog.dismiss()
                            toast("Projekt egyesítve: ${done.toAdd} új, ${done.duplicates} már meglévő rekord")
                            showCampaign(target.id)
                        } else {
                            val safeCampaign = if (nameCollision) incoming.copy(
                                title = incoming.title + " (importált)") else incoming
                            val id = store.importTransferredProject(safeCampaign,
                                imported.signers, override)
                            dialog.dismiss()
                            toast("Projekt sikeresen importálva")
                            showCampaign(id)
                        }
                    } catch (e: Exception) { toast("Importálás nem sikerült: ${e.message}") }
                }
                if (updateController.isChecked) {
                    confirm("Központi adatkezelő módosítása",
                        "Az új profil minden meglévő projekt közös adatkezelőjét is " +
                            "megváltoztatja. Biztosan ezt szeretné?") { execute() }
                } else execute()
            }
        }
        dialog.show()
    }

    private fun showPrivacyRequired(campaign: Campaign) {
        AlertDialog.Builder(this)
            .setTitle("Adatkezelési beállítás szükséges")
            .setMessage("A személyes adatok és digitális aláírások gyűjtése előtt " +
                "adja meg a központi adatkezelőt és a kampány jóváhagyott tájékoztatóját.")
            .setNegativeButton("Mégse", null)
            .setNeutralButton("Adatkezelő") { _, _ -> showControllerSettings(campaign.id) }
            .setPositiveButton("Projekt szerkesztése") { _, _ -> showCampaignEditor(campaign) }
            .show()
    }

    /**
     * A kitöltött adatlapok politikai véleményre utalhatnak: ezért NEM küldünk
     * nyitott CSV-t emailben. A kért 6 számjegyű ZIP PIN rövid és ezért gyenge:
     * a felületen figyelmeztetünk a kockázatra. A PIN nem kerül az emailbe.
     */
    private fun showEncryptedShareDialog(campaign: Campaign, signers: List<Signer>) {
        if (signers.isEmpty()) {
            toast("Ebben a projektben még nincs exportálható adatlap")
            return
        }
        val content = column()
        label(content, "A csatolmány tartalmazza a neveket, elérhetőségeket, " +
            "címeket, hozzájárulásokat és az aláírások PNG-képeit.", isWarning = true)
        label(content, "A fájl AES-256-tal titkosított ZIP lesz. A megnyitáshoz " +
            "7-Zip vagy más AES-ZIP-kompatibilis program szükséges. " +
            "A PIN-t másik, biztonságos csatornán közölje a címzettel.")
        label(content, "FIGYELEM: a pontosan 6 számjegyű PIN csak 1 000 000 " +
            "lehetőségből áll, ezért elveszett vagy illetéktelen kézbe került ZIP " +
            "esetén könnyen próbálgatható. Különösen érzékeny adatok továbbítására " +
            "a hosszú véletlenszerű jelszó biztonságosabb.", isWarning = true)
        val pass = input(content, "ZIP PIN (pontosan 6 számjegy)", kind =
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        val repeat = input(content, "6 jegyű PIN megismétlése", kind =
            InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_VARIATION_PASSWORD)
        pass.filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        repeat.filters = arrayOf(android.text.InputFilter.LengthFilter(6))
        val authorized = check(content,
            "Jogosult vagyok a kiválasztott személyes adatok átadására a címzettnek.")
        val dialog = AlertDialog.Builder(this)
            .setTitle("Biztonságos, táblázatos adatmegosztás")
            .setView(ScrollView(this).apply { addView(content) })
            .setNegativeButton("Mégse", null)
            .setPositiveButton("Titkosított ZIP készítése", null)
            .create()
        dialog.setOnShowListener {
            dialog.getButton(AlertDialog.BUTTON_POSITIVE).setOnClickListener {
                if (!authorized.isChecked) {
                    toast("Az adatátadás jogosultságát igazolni kell")
                    return@setOnClickListener
                }
                val value = pass.text.toString()
                if (!value.matches(Regex("[0-9]{6}")) || value != repeat.text.toString()) {
                    toast("Pontosan 6 számjegyű, kétszer azonos ZIP PIN szükséges")
                    return@setOnClickListener
                }
                try {
                    val chars = value.toCharArray()
                    val file = try {
                        exporter.createEncryptedArchive(campaign, signers, chars)
                    } finally { chars.fill('\u0000') }
                    try { store.recordPreparedExport(campaign.id) } catch (error: Exception) {
                        file.delete() // audit nélkül személyesadat-export nem adható át
                        throw error
                    }
                    pass.text?.clear()
                    repeat.text?.clear()
                    dialog.dismiss()
                    exporter.openShareSheet(
                        file, "application/zip", "Titkosított adatlapok – ${campaign.title}",
                        "A mellékelt ZIP titkosított táblázatot és aláírásképeket " +
                            "tartalmaz. A 6 jegyű ZIP PIN-t külön, biztonságos csatornán küldöm."
                    )
                } catch (e: Exception) {
                    toast("Titkosított export hiba: ${e.message}")
                }
            }
        }
        dialog.show()
    }

    /** Diktálható beviteli mező. Részátirat nyersen, végleges szöveg formázva. */
    private fun dictatedInput(parent: LinearLayout, title: String, initial: String,
                              kind: Int = InputType.TYPE_CLASS_TEXT,
                              field: FieldFormatter.Kind = FieldFormatter.Kind.RAW): EditText {
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
        }
        parent.addView(row)
        row.addView(TextView(this).apply {
            text = title; textSize = 15f; setTextColor(charcoal)
            setTypeface(Typeface.DEFAULT, Typeface.BOLD)
        }, LinearLayout.LayoutParams(0, -2, 1f))
        val ed = EditText(this).apply {
            setSingleLine(true); inputType = kind
            setText(initial)
            fieldStyle(this)
            tag = field
            setOnFocusChangeListener { _, focused ->
                if (!focused) applyFormatting(this)
            }
        }
        row.addView(Button(this).apply {
            text = "🎤"; contentDescription = "$title diktálása"
            isAllCaps = false
            textSize = 21f
            background = touchBackground(greenHighlight, 10, greenBorder)
            setOnClickListener { startVoice(ed) }
        }, LinearLayout.LayoutParams(dp(61), dp(49)))
        parent.addView(ed, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = dp(14) })
        return ed
    }

    private fun applyFormatting(field: EditText) {
        val kind = field.tag as? FieldFormatter.Kind ?: FieldFormatter.Kind.RAW
        val oldValue = field.text.toString()
        val newValue = FieldFormatter.normalize(kind, oldValue)
        if (oldValue != newValue) {
            field.setText(newValue)
            field.setSelection(field.text.length)
        }
    }

    /** Az online szolgáltatást nem választjuk ki automatikusan: egyszeri, tartós jóváhagyás kell. */
    private fun useSystemSpeech() = speechPrefs.getBoolean("system_recognizer_approved", false)
    private fun speechMode() = if (useSystemSpeech()) OfflineSpeech.Mode.SYSTEM else OfflineSpeech.Mode.OFFLINE
    private fun speechModeLabel(): String = if (useSystemSpeech())
        "Felismerő: Android rendszerfelismerő (esetleg online). Az alábbi gombbal módosítható."
    else "Felismerő: helyi magyar modell. Ha 12-es hibát ad, válassza a rendszerfelismerőt a gombbal."

    private fun openSpeechSettings() {
        speech.stop()
        AlertDialog.Builder(this)
            .setTitle("Beszédfelismerés beállítása")
            .setMessage("A helyi feldolgozás csak akkor működik, ha a magyar nyelvi modell " +
                "elérhető a készüléken. Az Android rendszerfelismerője a hangot " +
                "szolgáltatójának hálózatára továbbíthatja. A beállítás elmentésre kerül, " +
                "később bármikor módosítható; hangot nem tárolunk.")
            .setNegativeButton("Helyi mód") { _, _ ->
                speechPrefs.edit().putBoolean("system_recognizer_approved", false).apply()
                voiceStatus?.text = speechModeLabel()
            }
            .setPositiveButton("Rendszerfelismerő engedélyezése") { _, _ ->
                if (!speech.systemAvailable()) {
                    toast("A rendszerfelismerő nincs telepítve vagy nem érhető el.")
                } else {
                    speechPrefs.edit().putBoolean("system_recognizer_approved", true).apply()
                    voiceStatus?.text = speechModeLabel()
                }
            }
            .setNeutralButton("Mégse", null)
            .show()
    }

    private fun startVoice(target: EditText, mode: OfflineSpeech.Mode = speechMode()) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            voiceEdit = target
            activeVoiceMode = mode
            if (shouldShowRequestPermissionRationale(Manifest.permission.RECORD_AUDIO)) {
                AlertDialog.Builder(this)
                    .setTitle("Mikrofonjogosultság")
                    .setMessage("Csak a diktáláshoz kérjük a mikrofont. " +
                        "Ha az Android minden alkalommal rákérdez, a telefon beállításaiban " +
                        "a »Csak az alkalmazás használata közben« engedély választható.")
                    .setNegativeButton("Gépelés", null)
                    .setPositiveButton("Engedély kérése") { _, _ ->
                        requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 400)
                    }.show()
            } else {
                requestPermissions(arrayOf(Manifest.permission.RECORD_AUDIO), 400)
            }
            return
        }
        if (mode == OfflineSpeech.Mode.OFFLINE && !speech.available()) {
            voiceStatus?.text = "Ezen a készüléken nincs helyi felismerő. " +
                "Nyissa meg a »Felismerő választása« beállítást."
            toast("Nem elérhető a helyi beszédfelismerő; a mező kézzel is kitölthető.")
            return
        }
        if (mode == OfflineSpeech.Mode.SYSTEM && !speech.systemAvailable()) {
            voiceStatus?.text = "Android rendszerfelismerő nem érhető el. A beállításoknál módosítható."
            return
        }
        speech.start(mode,
            onText = { words ->
                if (target.isAttachedToWindow) {
                    target.setText(words)  // a részeredményt még nem formázzuk át
                    target.setSelection(target.text.length)
                }
            },
            onStatus = { status -> voiceStatus?.text = status },
            onError = { error ->
                if (error == SpeechRecognizer.ERROR_LANGUAGE_NOT_SUPPORTED &&
                    mode == OfflineSpeech.Mode.OFFLINE) {
                    voiceStatus?.text = "A magyar offline nyelv ezen a felismerőn nem támogatott " +
                        "(12). A »Felismerő választása« gombbal válthat másik módra."
                } else if (error == SpeechRecognizer.ERROR_LANGUAGE_UNAVAILABLE &&
                    mode == OfflineSpeech.Mode.OFFLINE) {
                    voiceStatus?.text = "A magyar offline modell nincs telepítve (13). " +
                        "A telefon nyelvi csomagjai között tölthető le, ha támogatott."
                }
                // Nem nyitunk többé automatikusan minden hibánál engedélyező panelt.
            },
            onFinal = { words ->
                if (target.isAttachedToWindow) {
                    val kind = target.tag as? FieldFormatter.Kind ?: FieldFormatter.Kind.RAW
                    target.setText(FieldFormatter.normalize(kind, words))
                    target.setSelection(target.text.length)
                }
            }
        )
    }

    override fun onRequestPermissionsResult(requestCode: Int,
                                           permissions: Array<out String>,
                                           grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 400) {
            val saved = voiceEdit
            voiceEdit = null
            if (grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED && saved != null)
                startVoice(saved, activeVoiceMode)
            else toast("Mikrofonengedély nélkül a mező billentyűzettel kitölthető.")
        }
    }

    private fun showSignerEditor(campaign: Campaign, old: Signer?) {
        speech.stop(); screen = "ENTRY"; openCampaign = campaign.id
        val root = column()
        heading(root, if (old == null) "Új digitális aláírás" else "Adatok módosítása")
        label(root, campaign.title, true)
        label(root, campaign.description)
        if (!campaign.isReadyForRealData()) {
            showPrivacyRequired(campaign)
            return
        }
        label(root, "Adatok felvétele billentyűzettel vagy mezőnkénti mikrofonos diktálással. A felismerés azonnal szerkeszthető.")
        voiceStatus = label(root, speechModeLabel())
        button(root, "🎤 Felismerő választása / engedélyezése") { openSpeechSettings() }
        label(root, "Formázás: a diktálás végén vagy a mező elhagyásakor. " +
            "Mindig ellenőrizze a számokat és az elírásokat.")
        val name = dictatedInput(root, "Olvasható név *", old?.fullName.orEmpty(),
            field = FieldFormatter.Kind.NAME)
        val email = dictatedInput(root, "E-mail-cím", old?.email.orEmpty(),
            InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS,
            FieldFormatter.Kind.EMAIL)
        val phone = dictatedInput(root, "Telefonszám (mobil vagy vezetékes)", old?.phone.orEmpty(),
            InputType.TYPE_CLASS_PHONE, FieldFormatter.Kind.PHONE)
        val postal = dictatedInput(root, "Irányítószám", old?.postalCode.orEmpty(),
            InputType.TYPE_CLASS_NUMBER, FieldFormatter.Kind.POSTAL)
        val city = dictatedInput(root, "Település", old?.city.orEmpty(),
            field = FieldFormatter.Kind.CITY)
        val address = dictatedInput(root, "Utca, házszám", old?.streetAddress.orEmpty(),
            field = FieldFormatter.Kind.ADDRESS)
        label(root, "Önkéntes, külön célú választások", true)
        val newsletter = check(root, "Hírlevélre feliratkozom (külön hozzájárulás)",
            old?.newsletter ?: false)
        val sympathizer = check(root, "Szimpatizánsnak jelentkezem (külön hozzájárulás)",
            old?.sympathizer ?: false)
        label(root, "Adatkezelő: ${campaign.controller.ifBlank { "Nincs beállítva" }}")
        label(root, "Kapcsolat: ${campaign.contact.ifBlank { "Nincs beállítva" }}")
        label(root, "Adatkezelési tájékoztató, ${campaign.policyVersion} verzió:", true)
        label(root, campaign.privacyNotice.ifBlank { "A tájékoztató nincs beállítva." })
        if (old != null) {
            label(root, "Korábban rögzített állapotok: tájékoztató megismerve: " +
                "${consentAnswer(old.privacyRead)}; kifejezett hozzájárulás: " +
                "${consentAnswer(old.explicitConsent)}.")
            label(root, "Új aláíráshoz az alábbi két nyilatkozatot ismét, önkéntesen be kell jelölni.")
        }
        val readPrivacy = check(root, "A jelenlegi adatkezelési tájékoztatót megismertem.", false)
        val explicit = check(root,
            "Most kifejezetten hozzájárulok ahhoz, hogy adataimat és aláírásomat " +
                "kizárólag a fenti kampány támogatásának dokumentálásához kezeljék.", false)
        label(root, "Aláírás rajzolása ujjával vagy érintőtollal", true)
        if (old != null) {
            label(root, "Változtatás esetén ismét alá kell írni. A korábbi aláírás csak megtekinthető, nem vihető át változtatás nélkül.", isWarning = true)
            val bitmap = BitmapFactory.decodeByteArray(old.signaturePng, 0, old.signaturePng.size)
            if (bitmap != null) {
                root.addView(ImageView(this).apply {
                    setImageBitmap(bitmap); adjustViewBounds = true
                    scaleType = ImageView.ScaleType.FIT_CENTER
                }, LinearLayout.LayoutParams(-1, dp(90)))
            }
        }
        val pad = SignaturePad(this)
        // Nagyobb aláírásfelület: telefonon 360dp, tableten 460dp.
        val signatureHeight = if (resources.configuration.smallestScreenWidthDp >= 600) 460 else 360
        root.addView(pad, LinearLayout.LayoutParams(-1, dp(signatureHeight)).apply {
            topMargin = dp(12); bottomMargin = dp(12)
        })
        button(root, "Aláírás törlése / újrarajzolás") { pad.clear() }
        primaryButton(root, "Ellenőrzött adatok és aláírás mentése") {
            speech.stop()
            listOf(name, email, phone, postal, city, address).forEach(::applyFormatting)
            if (name.text.toString().isBlank()) { toast("A név kötelező"); return@primaryButton }
            if (!readPrivacy.isChecked || !explicit.isChecked) {
                toast("A tájékoztató megismerése és a kifejezett hozzájárulás szükséges")
                return@primaryButton
            }
            if (!pad.hasNewSignature()) { toast("Kérjük az aláírás megrajzolását"); return@primaryButton }
            if (!FieldFormatter.validPhone(phone.text.toString())) {
                toast("A telefonszám nem teljes; magyar számnál +36 és 8 vagy 9 helyi számjegy szükséges")
                return@primaryButton
            }
            val mail = email.text.toString().trim()
            if (mail.isNotEmpty() && !android.util.Patterns.EMAIL_ADDRESS.matcher(mail).matches()) {
                toast("Az e-mail-cím hibásnak tűnik – ellenőrizze"); return@primaryButton
            }
            val save = {
                try {
                    val time = System.currentTimeMillis()
                    val signer = Signer(id = old?.id ?: 0, campaignId = campaign.id,
                        fullName = name.text.toString().trim(), email = mail,
                        phone = phone.text.toString().trim(),
                        postalCode = postal.text.toString().trim(),
                        city = city.text.toString().trim(),
                        streetAddress = address.text.toString().trim(),
                        newsletter = newsletter.isChecked,
                        sympathizer = sympathizer.isChecked,
                        privacyRead = readPrivacy.isChecked,
                        explicitConsent = explicit.isChecked,
                        policyVersion = campaign.policyVersion,
                        consentAt = time, signedAt = time,
                        signaturePng = pad.exportPng(),
                        createdAt = old?.createdAt ?: time,
                        updatedAt = time,
                        recordUid = old?.recordUid.orEmpty())
                    store.saveSigner(signer)
                    toast("Titkosítva mentve")
                    showCampaign(campaign.id)
                } catch (e: Exception) { toast("Mentési hiba: ${e.message}") }
            }
            if (campaign.isReadyForRealData()) save() else showPrivacyRequired(campaign)
        }
        button(root, "Mégse / vissza") { showCampaign(campaign.id) }
        page(root)
    }
}

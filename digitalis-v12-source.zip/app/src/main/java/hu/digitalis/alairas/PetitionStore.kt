package hu.digitalis.alairas

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import org.json.JSONObject
import java.util.UUID

/**
 * Natív SQLite: két fő tábla (projektek + aláírások), egy minimális technikai napló.
 * Minden aláíró MINDEN kitölthető mezője egyetlen titkosított JSON/BLOB rekordban van.
 * A naplóban nincs név, cím, e-mail, telefon vagy kézírásos kép.
 * Az új mezők JSON-ban kompatibilisen bővíthetők; sémamigráció szükséges módosításkor.
 */
class PetitionStore(ctx: Context, private val cipher: RecordCipher) :
    SQLiteOpenHelper(ctx, "digitalis_alairas.db", null, 2) {

    override fun onConfigure(db: SQLiteDatabase) {
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""CREATE TABLE campaigns (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           payload BLOB NOT NULL,
           created_at INTEGER NOT NULL,
           updated_at INTEGER NOT NULL
        )""")
        db.execSQL("""CREATE TABLE signatures (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           campaign_id INTEGER NOT NULL REFERENCES campaigns(id) ON DELETE CASCADE,
           payload BLOB NOT NULL,
           signature_png BLOB NOT NULL,
           created_at INTEGER NOT NULL,
           updated_at INTEGER NOT NULL
        )""")
        db.execSQL("CREATE INDEX idx_signatures_campaign ON signatures(campaign_id)")
        db.execSQL("CREATE TABLE app_settings (key TEXT PRIMARY KEY, payload BLOB NOT NULL)")
        db.execSQL("""CREATE TABLE audit (
           id INTEGER PRIMARY KEY AUTOINCREMENT,
           at INTEGER NOT NULL, action TEXT NOT NULL,
           campaign_id INTEGER NOT NULL, signature_id INTEGER
        )""")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        // V1 -> V2: csak új központi beállítási tábla; a kampányok/aláírások változatlanok.
        if (oldVersion == 1 && newVersion == 2) {
            db.execSQL("CREATE TABLE IF NOT EXISTS app_settings (key TEXT PRIMARY KEY, payload BLOB NOT NULL)")
        } else {
            error("Ismeretlen adatbázis-migráció: $oldVersion → $newVersion")
        }
    }

    private fun audit(db: SQLiteDatabase, action: String, cid: Long, sid: Long? = null) {
        val cv = ContentValues().apply {
            put("at", System.currentTimeMillis()); put("action", action)
            put("campaign_id", cid); if (sid == null) putNull("signature_id") else put("signature_id", sid)
        }
        db.insertOrThrow("audit", null, cv)
    }

    /** Az összes projekt közös adatkezelője, rekordtitkosítással. */
    fun controllerProfile(): ControllerProfile {
        readableDatabase.rawQuery("SELECT payload FROM app_settings WHERE key=?",
            arrayOf("controller_profile")).use { cursor ->
            if (!cursor.moveToFirst()) return ControllerProfile()
            return ControllerProfile.fromJson(JSONObject(cipher.decryptText(cursor.getBlob(0))))
        }
    }

    /** Csak a teljesen új telepítésben tölti fel a központi profilt.
     * Korábban mentett adatkezelőt nem írunk felül.
     */
    fun initializeControllerDefaultsIfAbsent() {
        val exists = readableDatabase.rawQuery(
            "SELECT 1 FROM app_settings WHERE key=?", arrayOf("controller_profile")
        ).use { it.moveToFirst() }
        if (!exists) saveControllerProfile(ControllerProfile())
    }

    fun saveControllerProfile(profile: ControllerProfile) {
        require(profile.complete()) { "Adatkezelő neve és elérhetősége szükséges" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val data = ContentValues().apply {
                put("key", "controller_profile")
                put("payload", cipher.encryptText(profile.toJson().toString()))
            }
            val previous = db.rawQuery("SELECT payload FROM app_settings WHERE key=?",
                arrayOf("controller_profile")).use { cur ->
                if (!cur.moveToFirst()) ControllerProfile() else
                    ControllerProfile.fromJson(JSONObject(cipher.decryptText(cur.getBlob(0))))
            }
            db.insertWithOnConflict("app_settings", null, data, SQLiteDatabase.CONFLICT_REPLACE)
            if (previous.privacyNotice != profile.privacyNotice) {
                db.rawQuery("SELECT id,payload FROM campaigns", null).use { cur ->
                    while (cur.moveToNext()) {
                        val id = cur.getLong(0)
                        val old = Campaign.fromJson(id,
                            JSONObject(cipher.decryptText(cur.getBlob(1))))
                        val updated = old.copy(approvedForRealData = false)
                        db.update("campaigns", ContentValues().apply {
                            put("payload", cipher.encryptText(updated.toJson().toString()))
                            put("updated_at", System.currentTimeMillis())
                        }, "id=?", arrayOf(id.toString()))
                    }
                }
                audit(db, "NOTICE_CHANGE_REQUIRES_REAPPROVAL", 0)
            }
            audit(db, "CONTROLLER_PROFILE_UPDATED", 0)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun saveCampaign(c: Campaign): Long {
        val now = System.currentTimeMillis()
        val withUid = if (c.projectUid.isBlank()) c.copy(projectUid = UUID.randomUUID().toString()) else c
        val cv = ContentValues().apply {
            put("payload", cipher.encryptText(withUid.toJson().toString())); put("updated_at", now)
        }
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = if (c.id == 0L) {
                cv.put("created_at", now); db.insertOrThrow("campaigns", null, cv)
            } else {
                check(db.update("campaigns", cv, "id=?", arrayOf(c.id.toString())) == 1)
                c.id
            }
            audit(db, if (c.id == 0L) "CAMPAIGN_CREATE" else "CAMPAIGN_EDIT", id)
            db.setTransactionSuccessful(); id
        } finally { db.endTransaction() }
    }

    fun campaigns(): List<Campaign> {
        val result = arrayListOf<Campaign>()
        readableDatabase.rawQuery("SELECT id,payload FROM campaigns ORDER BY id DESC", null).use { cur ->
            while (cur.moveToNext()) {
                result.add(Campaign.fromJson(cur.getLong(0),
                    JSONObject(cipher.decryptText(cur.getBlob(1)))))
            }
        }
        return result
    }

    fun campaign(id: Long): Campaign? = campaigns().firstOrNull { it.id == id }

    fun saveSigner(s: Signer): Long {
        require(s.fullName.isNotBlank() && s.privacyRead && s.explicitConsent && s.signaturePng.isNotEmpty())
        val now = System.currentTimeMillis()
        val withUid = if (s.recordUid.isBlank()) s.copy(recordUid = UUID.randomUUID().toString()) else s
        val cv = ContentValues().apply {
            put("campaign_id", s.campaignId)
            put("payload", cipher.encryptText(withUid.toJson().toString()))
            put("signature_png", cipher.encrypt(s.signaturePng))
            put("updated_at", now)
        }
        val db = writableDatabase
        db.beginTransaction()
        return try {
            val id = if (s.id == 0L) {
                cv.put("created_at", now); db.insertOrThrow("signatures", null, cv)
            } else {
                check(db.update("signatures", cv, "id=?", arrayOf(s.id.toString())) == 1)
                s.id
            }
            audit(db, if (s.id == 0L) "SIGN" else "RESIGN_EDIT", s.campaignId, id)
            db.setTransactionSuccessful(); id
        } finally { db.endTransaction() }
    }

    fun signers(campaignId: Long): List<Signer> {
        val list = arrayListOf<Signer>()
        readableDatabase.rawQuery("""SELECT id,payload,signature_png,created_at,updated_at
            FROM signatures WHERE campaign_id=? ORDER BY id DESC""",
            arrayOf(campaignId.toString())).use { cur ->
            while (cur.moveToNext()) {
                list.add(Signer.fromJson(cur.getLong(0), campaignId,
                    JSONObject(cipher.decryptText(cur.getBlob(1))),
                    cipher.decrypt(cur.getBlob(2)), cur.getLong(3), cur.getLong(4)))
            }
        }
        return list
    }

    fun signer(campaignId: Long, signerId: Long): Signer? =
        signers(campaignId).firstOrNull { it.id == signerId }

    /**
     * Auditnapló: a készüléken létrehozott exporttény, címzett és személyes adat nélkül.
     * A tényleges küldést a külső Android-alkalmazás végzi, ezért azt itt nem állítjuk.
     */
    fun recordPreparedExport(campaignId: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            audit(db, "ENCRYPTED_EXPORT_PREPARED", campaignId)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    /**
     * Projektexportból teljesen új projekt, opcionálisan áthozott személyek.
     * Egyetlen adatbázis-tranzakció: hiba esetén nem marad félkész import.
     * A központi adatkezelő csak a fogadó kifejezett engedélyével változhat.
     */
    fun importTransferredProject(
        campaign: Campaign,
        signers: List<Signer>,
        controllerOverride: ControllerProfile?
    ): Long {
        require(campaign.title.isNotBlank() && campaign.retentionDays > 0)
        val db = writableDatabase
        val now = System.currentTimeMillis()
        db.beginTransaction()
        try {
            val fresh = campaign.copy(id = 0, approvedForRealData = false,
                projectUid = campaign.projectUid.ifBlank { UUID.randomUUID().toString() })
            val projectValues = ContentValues().apply {
                put("payload", cipher.encryptText(fresh.toJson().toString()))
                put("created_at", now)
                put("updated_at", now)
            }
            val newId = db.insertOrThrow("campaigns", null, projectValues)
            signers.forEach { old ->
                require(old.fullName.isNotBlank() && old.privacyRead &&
                    old.explicitConsent && old.signaturePng.isNotEmpty())
                val newSigner = old.copy(id = 0, campaignId = newId,
                    recordUid = old.recordUid.ifBlank { UUID.randomUUID().toString() })
                val values = ContentValues().apply {
                    put("campaign_id", newId)
                    put("payload", cipher.encryptText(newSigner.toJson().toString()))
                    put("signature_png", cipher.encrypt(old.signaturePng))
                    put("created_at", old.createdAt.takeIf { it > 0L } ?: now)
                    put("updated_at", old.updatedAt.takeIf { it > 0L } ?: now)
                }
                db.insertOrThrow("signatures", null, values)
            }
            if (controllerOverride != null) {
                require(controllerOverride.complete())
                db.insertWithOnConflict("app_settings", null, ContentValues().apply {
                    put("key", "controller_profile")
                    put("payload", cipher.encryptText(controllerOverride.toJson().toString()))
                }, SQLiteDatabase.CONFLICT_REPLACE)
                audit(db, "CONTROLLER_PROFILE_IMPORTED", 0)
            }
            audit(db, "PROJECT_IMPORT_WITH_${signers.size}_RECORDS", newId)
            db.setTransactionSuccessful()
            return newId
        } finally { db.endTransaction() }
    }

    /**
     * Ugyanazon projektbe történő, atomi egyesítés. Sem a kampány korábban
     * jóváhagyott beállításait, sem a már helyben tárolt aláírásokat NEM írja felül.
     * Deduplikáció kézzel ellenőrizhető személyazonosító-jegyekkel.
     */
    fun mergeTransferredProject(existingCampaignId: Long, incoming: List<Signer>,
                                controllerOverride: ControllerProfile?): TransferMerge.Preview {
        require(campaign(existingCampaignId) != null) { "A célprojekt nem létezik" }
        val db = writableDatabase
        db.beginTransaction()
        try {
            val all = mutableListOf<Signer>()
            db.rawQuery("SELECT id,payload,signature_png,created_at,updated_at FROM signatures WHERE campaign_id=?",
                arrayOf(existingCampaignId.toString())).use { cur ->
                while (cur.moveToNext()) all.add(Signer.fromJson(cur.getLong(0), existingCampaignId,
                    JSONObject(cipher.decryptText(cur.getBlob(1))),
                    cipher.decrypt(cur.getBlob(2)), cur.getLong(3), cur.getLong(4)))
            }
            val before = all.size
            var duplicates = 0
            val now = System.currentTimeMillis()
            for (original in incoming) {
                require(original.fullName.isNotBlank() && original.privacyRead &&
                    original.explicitConsent && original.signaturePng.isNotEmpty())
                if (all.any { TransferMerge.samePerson(it, original) }) {
                    duplicates++
                    continue
                }
                val imported = original.copy(id = 0, campaignId = existingCampaignId,
                    recordUid = original.recordUid.ifBlank { UUID.randomUUID().toString() })
                db.insertOrThrow("signatures", null, ContentValues().apply {
                    put("campaign_id", existingCampaignId)
                    put("payload", cipher.encryptText(imported.toJson().toString()))
                    put("signature_png", cipher.encrypt(imported.signaturePng))
                    put("created_at", imported.createdAt.takeIf { it > 0 } ?: now)
                    put("updated_at", imported.updatedAt.takeIf { it > 0 } ?: now)
                })
                all.add(imported)
            }
            if (controllerOverride != null) {
                require(controllerOverride.complete())
                db.insertWithOnConflict("app_settings", null, ContentValues().apply {
                    put("key", "controller_profile")
                    put("payload", cipher.encryptText(controllerOverride.toJson().toString()))
                }, SQLiteDatabase.CONFLICT_REPLACE)
                audit(db, "CONTROLLER_PROFILE_IMPORTED", 0)
            }
            audit(db, "PROJECT_MERGE_ADDED_${all.size - before}_SKIPPED_$duplicates", existingCampaignId)
            db.setTransactionSuccessful()
            return TransferMerge.Preview(all.size - before, duplicates)
        } finally { db.endTransaction() }
    }

    fun removeSigner(s: Signer) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("signatures", "id=? AND campaign_id=?",
                arrayOf(s.id.toString(), s.campaignId.toString()))
            audit(db, "SIGNATURE_DELETE", s.campaignId, s.id)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }

    fun removeCampaign(id: Long) {
        val db = writableDatabase
        db.beginTransaction()
        try {
            db.delete("campaigns", "id=?", arrayOf(id.toString()))
            audit(db, "CAMPAIGN_DELETE_WITH_RECORDS", id)
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }
    }
}

package hu.digitalis.alairas

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.pdf.PdfDocument
import java.io.ByteArrayOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** A Mi Hazánk emblémával és a rajzolt aláírásokkal készült, többoldalas PDF. */
class PetitionPdf(private val context: Context) {
    private val green = Color.rgb(18, 103, 30)
    private val dark = Color.rgb(38, 48, 39)
    private val paperWidth = 595
    private val paperHeight = 842
    private val margin = 38f
    private val body = Paint(Paint.ANTI_ALIAS_FLAG).apply { color=dark; textSize=10f }
    private val bold = Paint(body).apply { isFakeBoldText=true; textSize=11f }
    private val title = Paint(body).apply { color=green; textSize=18f; isFakeBoldText=true }

    fun render(campaign: Campaign, signers: List<Signer>): ByteArray {
        val pdf = PdfDocument()
        var pageNumber = 0
        val logo = BitmapFactory.decodeResource(context.resources, R.drawable.mi_hazank)
        fun next(): Pair<PdfDocument.Page, Canvas> {
            pageNumber++
            val page = pdf.startPage(PdfDocument.PageInfo.Builder(paperWidth, paperHeight, pageNumber).create())
            val canvas = page.canvas
            canvas.drawColor(Color.WHITE)
            canvas.drawRect(0f, 0f, paperWidth.toFloat(), 8f,
                Paint().apply { color=green })
            if (logo != null) canvas.drawBitmap(logo, null, RectF(margin, 17f, 170f, 80f), null)
            canvas.drawText("DIGITÁLIS ALÁÍRÁSGYŰJTÉS", 185f, 50f, title)
            canvas.drawText("Projekt: ${campaign.title.take(55)}", margin, 100f, bold)
            canvas.drawText("Oldal: $pageNumber", paperWidth-95f, paperHeight-26f, body)
            return page to canvas
        }
        fun lineWrap(canvas: Canvas, content: String, x: Float, y: Float, width: Float,
                     maxBottom: Float, paint: Paint = body): Float {
            var yy = y
            for (paragraph in content.replace("\r", "").split("\n")) {
                var line = ""
                for (word in paragraph.split(Regex("\\s+"))) {
                    val candidate = (line + " " + word).trim()
                    if (paint.measureText(candidate) > width && line.isNotBlank()) {
                        if (yy > maxBottom) return yy
                        canvas.drawText(line, x, yy, paint); yy += 14f; line = word
                    } else line = candidate
                }
                if (line.isNotBlank() && yy <= maxBottom) {
                    canvas.drawText(line, x, yy, paint); yy += 14f
                }
                yy += 4f
            }
            return yy
        }
        try {
            val first = next()
            var y = 130f
            y = lineWrap(first.second, "A projekt leírása: ${campaign.description}", margin, y, 510f, 430f)
            y += 10
            y = lineWrap(first.second, "Adatkezelő: ${campaign.controller}; kapcsolattartó: ${campaign.contactPerson}; elérhetőség: ${campaign.contact}", margin, y, 510f, 455f)
            y += 12
            first.second.drawText("ADATKEZELÉSI TÁJÉKOZTATÓ", margin, y, bold)
            y += 18
            y = lineWrap(first.second, campaign.privacyNotice, margin, y, 510f, 715f)
            y += 12
            y = lineWrap(first.second, "Tájékoztató verzió: ${campaign.policyVersion}; megőrzés: ${campaign.retentionDays} nap; személyek száma: ${signers.size}.", margin, y, 510f, 755f)
            first.second.drawText("A digitális aláírás nem minősített elektronikus aláírás.", margin, 778f, body)
            pdf.finishPage(first.first)
            // Egy aláíró teljes adatai külön blokkban; az eredeti PNG a személy alatt.
            var pair: Pair<PdfDocument.Page, Canvas>? = null
            var yy = 0f
            signers.forEachIndexed { idx, person ->
                if (pair == null || yy > 655f) {
                    pair?.let { pdf.finishPage(it.first) }
                    pair = next(); yy=130f
                    pair!!.second.drawText("ALÁÍRÓK ÉS DIGITÁLIS ALÁÍRÁSOK", margin, yy, bold); yy+=23f
                }
                val canvas = pair!!.second
                val rect = RectF(margin, yy-10f, paperWidth-margin, yy+92f)
                canvas.drawRoundRect(rect, 8f, 8f,
                    Paint(Paint.ANTI_ALIAS_FLAG).apply { color=Color.rgb(239,248,236) })
                canvas.drawText("${idx + 1}. ${person.fullName.take(80)}", margin+10f, yy+7f, bold)
                canvas.drawText("Azonosító: ${person.recordUid.ifBlank { person.id.toString() }.take(50)}", margin+10f, yy+23f, body)
                canvas.drawText("${person.postalCode} ${person.city}, ${person.streetAddress}".take(82), margin+10f, yy+39f, body)
                canvas.drawText("${person.email} | ${person.phone}".take(82), margin+10f, yy+55f, body)
                canvas.drawText("Aláírás: ${SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.ROOT).format(Date(person.signedAt))}", margin+10f, yy+72f, body)
                if (person.signaturePng.isNotEmpty()) {
                    val image = BitmapFactory.decodeByteArray(person.signaturePng, 0, person.signaturePng.size)
                    if (image != null) {
                        val w = image.width.toFloat(); val h = image.height.toFloat()
                        val scale = minOf(135f/w, 72f/h)
                        val iw = w*scale; val ih=h*scale
                        canvas.drawBitmap(image,null,RectF(398f, yy+4f, 398f+iw, yy+4f+ih),null)
                        image.recycle()
                    }
                }
                yy += 117f
            }
            pair?.let { pdf.finishPage(it.first) }
            val out = ByteArrayOutputStream()
            pdf.writeTo(out)
            return out.toByteArray()
        } finally { pdf.close(); logo?.recycle() }
    }
}

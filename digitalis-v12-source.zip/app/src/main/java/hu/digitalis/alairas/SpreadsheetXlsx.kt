package hu.digitalis.alairas

import java.io.ByteArrayOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipOutputStream

/**
 * Egyszerű OOXML XLSX készítő KÜLSŐ SDK NÉLKÜL.
 * A táblázatban az aláírás nemcsak hivatkozás: DrawingML PNG-ként a sorhoz kötve megjelenik.
 * A mezők mind inlineStr-ként kerülnek be, tehát semmilyen képletet nem értékel az Excel.
 * Az így összeállított XLSX csak titkosított ZIP-be kerül, önálló nyitott fájlként nem.
 */
object SpreadsheetXlsx {
    val columns = listOf("Rekordazonosító", "Név", "E-mail", "Telefonszám", "Irányítószám",
        "Település", "Utca, házszám", "Hírlevél", "Szimpatizáns", "Tájékoztató megismerve",
        "Kifejezett hozzájárulás", "Tájékoztató verziója", "Hozzájárulás dátuma",
        "Aláírás dátuma", "Létrehozva", "Módosítva", "Aláírásfájl", "Aláíráskép")

    fun rows(signers: List<Signer>, date: (Long) -> String): List<List<String>> = signers.map { s ->
        listOf(s.recordUid.ifBlank { s.id.toString() }, s.fullName, s.email, s.phone,
            s.postalCode, s.city, s.streetAddress, yes(s.newsletter), yes(s.sympathizer),
            yes(s.privacyRead), yes(s.explicitConsent), s.policyVersion,
            date(s.consentAt), date(s.signedAt), date(s.createdAt), date(s.updatedAt),
            if (s.signaturePng.isNotEmpty()) "alairasok/alairas_${s.id}.png" else "", "")
    }

    private fun yes(v: Boolean) = if (v) "Igen" else "Nem"
    private fun xml(v: String) = buildString {
        v.forEach { c ->
            when(c) {
                '&' -> append("&amp;")
                '<' -> append("&lt;")
                '>' -> append("&gt;")
                '\"' -> append("&quot;")
                '\'' -> append("&apos;")
                else -> if ((c.code >= 32 && c.code <= 0xD7FF) || c == '\n' || c == '\t' ||
                    (c.code in 0xE000..0xFFFD)) append(c)
            }
        }
    }
    private fun colName(i: Int): String {
        var n = i + 1
        var value = ""
        while(n > 0) { n--; value = ('A' + (n % 26)) + value; n /= 26 }
        return value
    }

    fun write(signers: List<Signer>, date: (Long) -> String): ByteArray {
        require(signers.size <= 1500) { "Az XLSX-be legfeljebb 1500 sor kerülhet." }
        val data = listOf(columns) + rows(signers, date)
        val validImages = signers.withIndex().filter { it.value.signaturePng.size >= 8 }
        val sheet = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?>
<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheetViews><sheetView workbookViewId="0"/></sheetViews><sheetFormatPr defaultRowHeight="15"/><cols>
""")
        for (i in columns.indices) sheet.append("<col min=\"${i+1}\" max=\"${i+1}\" width=\"${if(i==1||i==6) 29 else if(i==17) 23 else 19}\" customWidth=\"1\"/>")
        sheet.append("</cols><sheetData>")
        data.forEachIndexed { r, row ->
            sheet.append("<row r=\"${r+1}\" ht=\"${if (r == 0) 25 else 59}\" customHeight=\"1\">")
            row.forEachIndexed { c, value ->
                sheet.append("<c r=\"${colName(c)}${r+1}\" t=\"inlineStr\"><is><t xml:space=\"preserve\">${xml(value)}</t></is></c>")
            }
            sheet.append("</row>")
        }
        sheet.append("</sheetData>")
        if (validImages.isNotEmpty()) sheet.append("<drawing r:id=\"rId1\"/>")
        sheet.append("</worksheet>")
        val out = ByteArrayOutputStream()
        ZipOutputStream(out).use { zip ->
            fun add(name: String, value: String) { addBytes(zip, name, value.toByteArray(Charsets.UTF_8)) }
            add("[Content_Types].xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Default Extension="png" ContentType="image/png"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/><Override PartName="/xl/worksheets/sheet1.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/><Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/><Override PartName="/xl/drawings/drawing1.xml" ContentType="application/vnd.openxmlformats-officedocument.drawing+xml"/></Types>""")
            add("_rels/.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>""")
            add("xl/workbook.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets><sheet name="Aláírók" sheetId="1" r:id="rId1"/></sheets></workbook>""")
            add("xl/_rels/workbook.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet1.xml"/><Relationship Id="rId2" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>""")
            add("xl/styles.xml", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><fonts count="1"><font><sz val="11"/><name val="Calibri"/></font></fonts><fills count="1"><fill><patternFill patternType="none"/></fill></fills><borders count="1"><border/></borders><cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs><cellXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/></cellXfs></styleSheet>""")
            add("xl/worksheets/sheet1.xml", sheet.toString())
            if (validImages.isNotEmpty()) {
                add("xl/worksheets/_rels/sheet1.xml.rels", """<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/drawing" Target="../drawings/drawing1.xml"/></Relationships>""")
                val drawing = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><xdr:wsDr xmlns:xdr="http://schemas.openxmlformats.org/drawingml/2006/spreadsheetDrawing" xmlns:a="http://schemas.openxmlformats.org/drawingml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">""")
                val relations = StringBuilder("""<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">""")
                validImages.forEachIndexed { idx, indexed ->
                    val rid = idx + 1
                    val filename = "signature_${rid}.png"
                    addBytes(zip, "xl/media/$filename", indexed.value.signaturePng)
                    relations.append("<Relationship Id=\"rId$rid\" Type=\"http://schemas.openxmlformats.org/officeDocument/2006/relationships/image\" Target=\"../media/$filename\"/>")
                    val sheetRow = indexed.index + 1
                    drawing.append("""<xdr:oneCellAnchor><xdr:from><xdr:col>17</xdr:col><xdr:colOff>0</xdr:colOff><xdr:row>$sheetRow</xdr:row><xdr:rowOff>0</xdr:rowOff></xdr:from><xdr:ext cx="1650000" cy="470000"/><xdr:pic><xdr:nvPicPr><xdr:cNvPr id="$rid" name="Alairas_$rid"/><xdr:cNvPicPr/></xdr:nvPicPr><xdr:blipFill><a:blip r:embed="rId$rid"/><a:stretch><a:fillRect/></a:stretch></xdr:blipFill><xdr:spPr><a:prstGeom prst="rect"><a:avLst/></a:prstGeom></xdr:spPr></xdr:pic><xdr:clientData/></xdr:oneCellAnchor>""")
                }
                drawing.append("</xdr:wsDr>")
                relations.append("</Relationships>")
                add("xl/drawings/drawing1.xml", drawing.toString())
                add("xl/drawings/_rels/drawing1.xml.rels", relations.toString())
            }
        }
        return out.toByteArray()
    }
    private fun addBytes(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        zip.putNextEntry(ZipEntry(name)); zip.write(bytes); zip.closeEntry()
    }
}

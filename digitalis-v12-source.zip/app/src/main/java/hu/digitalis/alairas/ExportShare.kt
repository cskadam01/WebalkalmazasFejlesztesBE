package hu.digitalis.alairas

import android.content.ClipData
import android.content.Context
import android.content.Intent
import androidx.core.content.FileProvider
import net.lingala.zip4j.io.outputstream.ZipOutputStream
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

/**
 * Export és Android rendszermegosztás, kampányonként.
 *
 * BIZTONSÁGI ELV:
 * - Kitöltött táblázat: CSV és a PNG aláírások KIZÁRÓLAG AES-256-tal
 *   titkosított ZIP-fájlba kerülnek, sosem íródnak átmeneti sima CSV-ként.
 * - A ZIP jelszava nem kerül bele sem az e-mail tárgyába, sem a levelébe.
 * - A Content URI csak átmeneti olvasási engedélyt ad a címzett alkalmazásnak.
 *
 * A küldés végrehajtását az Androidon a felhasználó hagyja jóvá a megosztóban;
 * a program nem küld e-mailt és nem kér INTERNET jogosultságot.
 */
class ExportShare(private val context: Context) {
    private val exportDirectory = File(context.cacheDir, "share_out")

    /** A korábbi, ideiglenes megosztási csatolmányok 24 óra után törlődnek. */
    fun cleanExpired() {
        if (!exportDirectory.exists()) return
        val cutoff = System.currentTimeMillis() - 24L * 60L * 60L * 1000L
        exportDirectory.listFiles()?.forEach { file ->
            if (file.isFile && file.lastModified() < cutoff) file.delete()
        }
    }

    /**
     * A táblázat tartalmazza az összes felvett adatot és a külön hozzájárulásokat.
     * A PNG-k a ZIP belsejében sorszám/azonosító alapján vannak elnevezve;
     * személyes adat nem szerepel a fájlnevekben.
     *
     * Fontos: ez egy felhasználó által kezdeményezett, jogosultsághoz kötött
     * kézi export, NEM automata adatküldés/szinkronizáció.
     */
    fun createEncryptedArchive(campaign: Campaign, signers: List<Signer>, password: CharArray): File {
        require(password.size == 6 && password.all { it in '0'..'9' }) {
            "Pontosan 6 számjegyű ZIP PIN szükséges."
        }
        require(signers.isNotEmpty()) { "Üres adatlapot nem exportálunk" }
        if (!exportDirectory.exists()) exportDirectory.mkdirs()
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
        val base = "${TransferFilename.slug(campaign.title)}_alairas_gyujtemeny_$stamp"
        val file = TransferFilename.uniqueFile(exportDirectory, base, "zip")
        try {
            // A szöveges fájl, a CSV, az XLSX, a PDF és a PNG csak titkosított ZIP-be kerül.
            val xlsx = SpreadsheetXlsx.write(signers, ::date)
            val pdf = PetitionPdf(context).render(campaign, signers)
            require(xlsx.size <= 60 * 1024 * 1024 && pdf.size <= 60 * 1024 * 1024) {
                "A képes export túl nagy ehhez a készülékhez."
            }
            FileOutputStream(file).use { stream ->
                ZipOutputStream(stream, password).use { zip ->
                    putEncrypted(zip, "projekt.txt", projectText(campaign).toByteArray(Charsets.UTF_8))
                    putEncrypted(zip, "szemelyek.csv", csvBytes(signers))
                    putEncrypted(zip, "szemelyek_alairassal.xlsx", xlsx)
                    putEncrypted(zip, "teljes_alairasgyujtemeny.pdf", pdf)
                    signers.forEach { signer ->
                        if (signer.signaturePng.isNotEmpty()) {
                            putEncrypted(zip, "alairasok/alairas_${signer.id}.png", signer.signaturePng)
                        }
                    }
                }
            }
            return file
        } catch (error: Exception) {
            file.delete()
            throw error
        }
    }

    private fun projectText(c: Campaign): String = """
        PROJEKT – ADATKEZELÉSI ÉS ALÁÍRÁSI TÁJÉKOZTATÓ
        Projekt neve: ${c.title}
        Leírás: ${c.description}
        Adatkezelő: ${c.controller}
        Kapcsolattartó: ${c.contactPerson}
        Telefonszám: ${c.contact}
        Adatkezelési tájékoztató verziója: ${c.policyVersion}
        Adatmegőrzési idő (nap): ${c.retentionDays}

        ADATKEZELÉSI TÁJÉKOZTATÓ
        ${c.privacyNotice}

        Az aláírásokhoz tartozó személyes adatok a szemelyek.csv és a
        szemelyek_alairassal.xlsx fájlban vannak; a képek az alairasok mappában.
        Az aláírás nem minősített elektronikus aláírás. A 6 jegyű PIN gyenge
        védelmet jelent egy erős jelszóhoz képest; bizalmasan és külön továbbítsa.
    """.trimIndent()

    private fun putEncrypted(zip: ZipOutputStream, name: String, bytes: ByteArray) {
        val parameters = ZipParameters().apply {
            fileNameInZip = name
            compressionMethod = CompressionMethod.DEFLATE
            isEncryptFiles = true
            encryptionMethod = EncryptionMethod.AES
            aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
        }
        zip.putNextEntry(parameters)
        zip.write(bytes)
        zip.closeEntry()
    }

    /** CSV: kizárólag személyek és hivatkozás az azonosítóval nevezett PNG-re. */
    private fun csvBytes(signers: List<Signer>): ByteArray {
        val sb = StringBuilder(SpreadsheetXlsx.columns.joinToString(";") { csvField(it) })
            .append("\r\n")
        SpreadsheetXlsx.rows(signers, ::date).forEach { row ->
            sb.append(row.joinToString(";") { csvField(it) }).append("\r\n")
        }
        return utf8Bom + sb.toString().toByteArray(Charsets.UTF_8)
    }

    /**
     * A táblázatot úgy alakítjuk, hogy rosszindulatú szöveg se válhasson
     * képletté Excel vagy LibreOffice alatt (CSV formula injection).
     * Az apostróf a cella szöveg-jellegét jelzi.
     */
    private fun csvField(text: String): String {
        val safe = text.replace("\u0000", "").replace("\r", " ").replace("\n", " ")
        val trimmed = safe.trimStart()
        val formula = trimmed.startsWith("=") || trimmed.startsWith("+") ||
            trimmed.startsWith("-") || trimmed.startsWith("@") ||
            trimmed.startsWith("\t")
        val protectedValue = if (formula) "'" + safe else safe
        return "\"${protectedValue.replace("\"", "\"\"")}\""
    }

    private fun date(millis: Long): String = if (millis <= 0L) "" else
        SimpleDateFormat("yyyy-MM-dd HH:mm:ss XXX", Locale.ROOT).format(Date(millis))

    private fun yesNo(value: Boolean): String = if (value) "Igen" else "Nem"

    /**
     * Natív Android ACTION_SEND: felhasználó választhat Gmailt, Outlookot,
     * levelezőt, vagy más alkalmas megosztási alkalmazást.
     */
    fun openShareSheet(file: File, mime: String, subject: String, body: String) {
        val uri = FileProvider.getUriForFile(
            context, "${context.packageName}.shareprovider", file
        )
        val share = Intent(Intent.ACTION_SEND).apply {
            type = mime
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            clipData = ClipData.newUri(context.contentResolver, "Csatolmány", uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        context.startActivity(Intent.createChooser(share, "Megosztás – e-mail vagy más alkalmazás"))
    }

    companion object {
        private val utf8Bom = byteArrayOf(0xEF.toByte(), 0xBB.toByte(), 0xBF.toByte())
    }
}

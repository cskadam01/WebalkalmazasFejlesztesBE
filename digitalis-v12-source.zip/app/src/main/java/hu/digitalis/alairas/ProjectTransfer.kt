package hu.digitalis.alairas

import android.content.Context
import android.net.Uri
import android.util.Base64
import net.lingala.zip4j.ZipFile
import net.lingala.zip4j.io.outputstream.ZipOutputStream
import net.lingala.zip4j.model.ZipParameters
import net.lingala.zip4j.model.enums.AesKeyStrength
import net.lingala.zip4j.model.enums.CompressionMethod
import net.lingala.zip4j.model.enums.EncryptionMethod
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.io.File
import java.io.FileOutputStream
import java.io.IOException
import java.util.UUID
import java.text.Normalizer
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Két telefon közötti, kézzel indított PROJEKTÁTVITEL. Az állomány egyetlen,
 * AES-256-tal titkosított ZIP-bejegyzésből áll; soha nem írunk egyszerű, nyitott
 * JSON-t az Android fájlrendszerére. A rövid (6-jegyű) PIN gyengébb a hosszú
 * véletlen jelszónál, ezért a névvel történő export külön jóváhagyást igényel.
 *
 * A projektbeállítások: teljes Campaign JSON és ControllerProfile JSON.
 * A személyek/opcionális aláírások csak includePeople=true esetén szerepelnek.
 * Az import az egyező helyi projektbe egyesíthető; NEM veszi át automatikusan
 * a forráskészülék adatkezelői jóváhagyását.
 */
class ProjectTransfer(private val context: Context) {
    data class ImportedProject(
        val campaign: Campaign,
        val controller: ControllerProfile,
        val signers: List<Signer>,
        val includedPeople: Boolean
    )

    private val maxArchiveBytes = 30L * 1024L * 1024L
    private val maxJsonBytes = 32L * 1024L * 1024L
    private val maxPeople = 1_000
    private val maxSignatureBytes = 2 * 1024 * 1024

    private fun requirePin(pin: CharArray) {
        require(pin.size == 6 && pin.all { it in '0'..'9' }) {
            "Pontosan 6 számjegyű PIN-kód szükséges"
        }
    }

    fun exportProject(
        campaign: Campaign,
        controller: ControllerProfile,
        signers: List<Signer>,
        includePeople: Boolean,
        pin: CharArray
    ): File {
        requirePin(pin)
        val selected = if (includePeople) signers else emptyList()
        require(selected.size <= maxPeople) { "Túl sok személy van egy átviteli csomagban" }
        val people = JSONArray()
        selected.forEach { signer ->
            require(signer.signaturePng.size in 1..maxSignatureBytes) {
                "Az egyik aláírás nem megfelelő méretű"
            }
            people.put(JSONObject()
                .put("data", signer.toJson())
                .put("createdAt", signer.createdAt)
                .put("updatedAt", signer.updatedAt)
                .put("signaturePngBase64", Base64.encodeToString(signer.signaturePng, Base64.NO_WRAP)))
        }
        val root = JSONObject()
            .put("format", "hu.digitalis.alairas.project-transfer")
            .put("schemaVersion", 2)
            .put("exportedAt", System.currentTimeMillis())
            .put("campaign", campaign.toJson())
            .put("controllerProfile", controller.toJson())
            .put("peopleIncluded", includePeople)
            .put("signers", people)
        val data = root.toString().toByteArray(Charsets.UTF_8)
        require(data.size <= maxJsonBytes) { "Túl nagy a projektcsomag" }
        val directory = File(context.cacheDir, "share_out")
        if (!directory.exists() && !directory.mkdirs()) {
            throw IOException("Nem hozható létre a megosztási könyvtár")
        }
        val slug = TransferFilename.slug(campaign.title)
        val stamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.ROOT).format(Date())
        val file = TransferFilename.uniqueFile(directory, "${slug}_projekt_$stamp", "zip")
        try {
            FileOutputStream(file).use { stream ->
                ZipOutputStream(stream, pin).use { zip ->
                    val params = ZipParameters().apply {
                        fileNameInZip = "projekt.json"
                        compressionMethod = CompressionMethod.DEFLATE
                        isEncryptFiles = true
                        encryptionMethod = EncryptionMethod.AES
                        aesKeyStrength = AesKeyStrength.KEY_STRENGTH_256
                    }
                    zip.putNextEntry(params)
                    zip.write(data)
                    zip.closeEntry()
                }
            }
            require(file.length() <= maxArchiveBytes) { "A projekt ZIP túl nagy" }
            return file
        } catch (error: Exception) {
            file.delete()
            throw error
        }
    }

    /** A külső ZIP-et csak átmenetileg tároljuk; bemeneti méretet is ellenőrzünk. */
    fun importProject(uri: Uri, pin: CharArray): ImportedProject {
        requirePin(pin)
        val inputFile = File.createTempFile("projekt_beolvasas_", ".zip", context.cacheDir)
        try {
            context.contentResolver.openInputStream(uri)?.use { input ->
                FileOutputStream(inputFile).use { output ->
                    val buffer = ByteArray(8192)
                    var total = 0L
                    while (true) {
                        val count = input.read(buffer)
                        if (count < 0) break
                        total += count
                        require(total <= maxArchiveBytes) { "Túl nagy a beolvasott ZIP" }
                        output.write(buffer, 0, count)
                    }
                }
            } ?: throw IOException("A kiválasztott fájl nem olvasható")
            ZipFile(inputFile, pin).use { zip ->
                val headers = zip.fileHeaders
                require(headers.size == 1 && headers[0].fileName == "projekt.json" &&
                    headers[0].isEncrypted) { "Nem támogatott, vagy nem titkosított projekt ZIP" }
                val header = headers[0]
                require(header.uncompressedSize <= maxJsonBytes) { "Túl nagy a projektadat" }
                val jsonBytes = ByteArrayOutputStream()
                zip.getInputStream(header).use { stream ->
                    val buffer = ByteArray(8192)
                    while (true) {
                        val count = stream.read(buffer)
                        if (count < 0) break
                        require(jsonBytes.size().toLong() + count <= maxJsonBytes) {
                            "Túl nagy a kicsomagolt projektadat"
                        }
                        jsonBytes.write(buffer, 0, count)
                    }
                }
                val root = JSONObject(jsonBytes.toString("UTF-8"))
                require(root.optString("format") == "hu.digitalis.alairas.project-transfer" &&
                    root.optInt("schemaVersion") in 1..2) { "Nem kompatibilis projektcsomag" }
                val source = root.getJSONObject("campaign")
                val campaign = Campaign.fromJson(0, source).copy(
                    id = 0, approvedForRealData = false)
                require(campaign.title.isNotBlank() && campaign.title.length <= 250 &&
                    campaign.description.length <= 50_000 &&
                    campaign.privacyNotice.length <= 200_000 &&
                    campaign.retentionDays in 1..36_500) { "Hibás projektbeállítások" }
                val controller = ControllerProfile.fromJson(root.getJSONObject("controllerProfile"))
                require(controller.complete()) { "Hiányos adatkezelői profil" }
                val allowed = root.optBoolean("peopleIncluded", false)
                val arr = root.getJSONArray("signers")
                require(arr.length() <= maxPeople) { "Túl sok személy található a csomagban" }
                require(allowed || arr.length() == 0) { "Hibás személyadat-jelölés" }
                val people = ArrayList<Signer>(arr.length())
                for (i in 0 until arr.length()) {
                    val item = arr.getJSONObject(i)
                    val image = Base64.decode(item.getString("signaturePngBase64"), Base64.DEFAULT)
                    require(image.size in 8..maxSignatureBytes &&
                        image[0] == 0x89.toByte() && image[1] == 0x50.toByte() &&
                        image[2] == 0x4E.toByte() && image[3] == 0x47.toByte()) {
                        "Hibás aláírásfájl"
                    }
                    val person = Signer.fromJson(
                        0, 0, item.getJSONObject("data"), image,
                        item.optLong("createdAt"), item.optLong("updatedAt"))
                    require(person.fullName.isNotBlank() && person.privacyRead &&
                        person.explicitConsent) { "Hibás vagy hiányos hozzájárulási rekord" }
                    people.add(person)
                }
                return ImportedProject(campaign, controller, people, allowed)
            }
        } finally {
            inputFile.delete() // Titkosított ZIP-gyűjtőfájl se maradjon a cache-ben.
        }
    }
}

package hu.digitalis.alairas

import java.text.Normalizer
import java.util.Locale

/**
 * Konzervatív deduplikáció. A névegyezés ÖNMAGÁBAN NEM személyazonosság.
 * A régi (V11) csomagok még nem tartalmaznak globális rekord-UUID-t, ezért
 * aláírásképpel vagy név + egyező, konkrét elérhetőséggel azonosítunk.
 * Azonos személynél a már meglévő helyi adatot és eredeti aláírást megőrizzük.
 */
object TransferMerge {
    private fun norm(s: String) = Normalizer.normalize(s.trim().lowercase(Locale.ROOT),
        Normalizer.Form.NFD).replace(Regex("\\p{M}+"), "")
        .replace(Regex("\\s+"), " ")
    fun sameProjectName(a: String, b: String) = norm(a) == norm(b)
    fun sameDescription(a: String, b: String) = norm(a) == norm(b)
    fun samePerson(a: Signer, b: Signer): Boolean {
        if (a.recordUid.isNotBlank() && a.recordUid == b.recordUid) return true
        if (a.signaturePng.isNotEmpty() && a.signaturePng.contentEquals(b.signaturePng)) return true
        if (norm(a.fullName) != norm(b.fullName) || a.fullName.isBlank()) return false
        val aEmail = a.email.trim().lowercase(Locale.ROOT)
        val bEmail = b.email.trim().lowercase(Locale.ROOT)
        if (aEmail.isNotBlank() && bEmail.isNotBlank() && aEmail == bEmail) return true
        val aPhone = a.phone.filter(Char::isDigit).removePrefix("36").removePrefix("06")
        val bPhone = b.phone.filter(Char::isDigit).removePrefix("36").removePrefix("06")
        if (aPhone.length >= 8 && aPhone == bPhone) return true
        val address = norm(a.streetAddress)
        return address.isNotBlank() && norm(b.streetAddress) == address &&
            norm(a.city).isNotBlank() && norm(a.city) == norm(b.city) &&
            a.postalCode.isNotBlank() && a.postalCode == b.postalCode
    }

    data class Preview(val toAdd: Int, val duplicates: Int)
    fun preview(local: List<Signer>, incoming: List<Signer>): Preview {
        val accepted = local.toMutableList()
        var dup = 0
        for (one in incoming) {
            if (accepted.any { samePerson(it, one) }) dup++ else accepted.add(one)
        }
        return Preview(accepted.size - local.size, dup)
    }
}

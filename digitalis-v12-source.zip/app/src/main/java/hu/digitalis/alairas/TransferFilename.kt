package hu.digitalis.alairas

import java.io.File
import java.text.Normalizer

/** Közérthető, ékezet és speciális karakter nélküli, ütközésbiztos fájlnév. */
object TransferFilename {
    fun slug(value: String): String {
        val text = Normalizer.normalize(value, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
            .replace("ß", "ss")
            .replace(Regex("[^A-Za-z0-9]+"), "_")
            .trim('_').take(55).trimEnd('_')
        return text.ifBlank { "projekt" }
    }
    fun uniqueFile(dir: File, base: String, ext: String): File {
        require(dir.exists() || dir.mkdirs()) { "Nem hozható létre az exportkönyvtár" }
        var n = 1
        var file: File
        do {
            file = File(dir, base + (if (n == 1) "" else "_$n") + ".$ext")
            n++
        } while (file.exists())
        return file
    }
}

package hu.digitalis.alairas

import java.util.Locale

/**
 * Adatmezők óvatos, determinisztikus normalizálása.
 * - Nem egészíti ki találgatással a hiányzó személyes adatokat.
 * - A részeredményeket soha nem formázzuk: csak végleges felismeréskor,
 *   mezőelhagyáskor és a felhasználó által indított mentés előtt.
 * - A kimenet minden esetben szerkeszthető marad.
 */
object FieldFormatter {
    enum class Kind { RAW, NAME, EMAIL, PHONE, POSTAL, CITY, ADDRESS }
    private val hu = Locale.forLanguageTag("hu-HU")
    private val word = Regex("[\\p{L}]+")
    private val streetTypes = setOf("út", "utca", "tér", "köz", "körút", "sétány", "rakpart", "sor", "dűlő", "fasor", "park", "tere", "útja", "utca")

    fun normalize(kind: Kind, input: String): String = when (kind) {
        Kind.NAME -> title(input)
        Kind.CITY -> title(input)
        Kind.ADDRESS -> address(input)
        Kind.EMAIL -> email(input)
        Kind.PHONE -> phone(input)
        Kind.POSTAL -> postal(input)
        Kind.RAW -> clean(input)
    }

    private fun clean(value: String) = value.trim().replace(Regex("\\s+"), " ")

    private fun title(value: String): String {
        val cleaned = clean(value)
        if (cleaned.isEmpty()) return cleaned
        return word.replace(cleaned) { match ->
            val w = match.value.lowercase(hu)
            w.replaceFirstChar { c -> c.titlecase(hu) }
        }
    }

    private fun address(value: String): String {
        val normalized = title(value)
        if (normalized.isEmpty()) return normalized
        var wordNumber = 0
        return word.replace(normalized) { match ->
            val raw = match.value
            val lowered = raw.lowercase(hu)
            val out = if (wordNumber > 0 && lowered in streetTypes) lowered else raw
            wordNumber++
            out
        }
    }

    private fun email(value: String): String {
        var v = clean(value).lowercase(hu)
        if (v.isEmpty()) return v
        // Példa: 'jakab pont david kukac gmail pont com' -> 'jakab.david@gmail.com'.
        // Az egybeírt értékek közepén nem cserélünk szórészeket.
        v = v.replace(Regex("(?i)\\s*\\b(kukacjel|kukac|et|at)\\b\\s*"), "@")
            .replace(Regex("(?i)\\s*\\b(pont)\\b\\s*"), ".")
            .replace(Regex("(?i)\\s*\\b(alsóvonás|alsóvonal)\\b\\s*"), "_")
            .replace(Regex("(?i)\\s*\\b(kötőjel|kötővonal)\\b\\s*"), "-")
            .replace(" ", "")
        return v
    }

    /**
     * A magyar számokat egységesen +36 ... formátumban adja vissza.
     * 06 70 613 2776 -> +36 70 613 2776
     * 70 613 2776    -> +36 70 613 2776
     * 06 1 234 5678  -> +36 1 234 5678 (budapesti vezetékes)
     * 23 123456      -> +36 23 123 456 (vidéki vezetékes)
     * Külföldi + előhívót változatlanul hagyunk; a hiányos számokat nem egészítjük ki.
     */
    fun phone(value: String): String {
        var v = clean(value)
        if (v.isEmpty()) return v
        v = v.replace(Regex("(?i)^\\s*plusz\\s*"), "+")
        val converted = speechNumberDigits(v)
        if (converted != null) v = converted
        // Telefon mezőbe mondott elválasztók és kötőjelek nem számítanak.
        val canonical = v.replace(Regex("[\\s()./-]+"), "")
        if (!canonical.matches(Regex("\\+?[0-9]+"))) return v
        val number = when {
            canonical.startsWith("0036") -> "+36" + canonical.drop(4)
            canonical.startsWith("+36") -> canonical
            canonical.startsWith("06") -> "+36" + canonical.drop(2)
            canonical.startsWith("+") -> return canonical  // más ország előhívója
            canonical.startsWith("36") && canonical.length in 10..11 -> "+" + canonical
            canonical.length == 8 || canonical.length == 9 -> "+36" + canonical
            else -> return v  // a hiányzó számjegyeket nem találgatjuk
        }
        val national = number.removePrefix("+36")
        return when {
            national.length == 9 && national.take(2) in setOf("20", "30", "31", "50", "70") ->
                "+36 ${national.take(2)} ${national.substring(2,5)} ${national.substring(5)}"
            national.length == 8 && national.startsWith("1") ->
                "+36 1 ${national.substring(1,4)} ${national.substring(4)}"
            national.length == 8 && national[0] in '2'..'9' ->
                "+36 ${national.take(2)} ${national.substring(2,5)} ${national.substring(5)}"
            else -> number  // nem próbálunk hamis körzetszámot előállítani
        }
    }

    /** Nem mentünk el helytelen hosszúságú számot figyelmeztetés nélkül. */
    fun validPhone(value: String): Boolean {
        if (value.isBlank()) return true // nem kötelező adatmező
        val canonical = phone(value).replace(Regex("[\\s-]+"), "")
        if (!canonical.startsWith("+")) return false
        val numbers = canonical.drop(1)
        if (!numbers.matches(Regex("[0-9]{7,15}"))) return false
        return if (numbers.startsWith("36")) {
            val national = numbers.drop(2)
            (national.length == 9 && national.take(2) in setOf("20", "30", "31", "50", "70")) ||
                (national.length == 8 && ((national.startsWith("1")) || national[0] in '2'..'9'))
        } else true
    }

    /**
     * Óvatos számnév-felismerés, kizárólag a telefonmezőben:
     * "nulla hat hetven hat egy három kettő hét hét hat" -> "06706132776".
     * Ha ismeretlen kifejezés van a mondatban, visszaadunk nullt.
     */
    private fun speechNumberDigits(value: String): String? {
        if (!value.any { it.isLetter() }) return null
        val tokens = value.lowercase(hu).replace("-", " ")
            .replace(Regex("[,;]+"), " ").trim().split(Regex("\\s+"))
        val singles = mapOf("nulla" to "0", "egy" to "1", "kettő" to "2",
            "kettö" to "2", "két" to "2", "három" to "3", "négy" to "4",
            "öt" to "5", "hat" to "6", "hét" to "7", "nyolc" to "8", "kilenc" to "9")
        val tens = mapOf("tíz" to "10", "húsz" to "20", "harminc" to "30",
            "negyven" to "40", "ötven" to "50", "hatvan" to "60",
            "hetven" to "70", "nyolcvan" to "80", "kilencven" to "90")
        val result = StringBuilder()
        for (token in tokens) {
            if (token == "plusz") { if (result.isNotEmpty()) return null; result.append('+'); continue }
            if (token.all { it.isDigit() }) { result.append(token); continue }
            val fixed = singles[token] ?: tens[token]
            if (fixed != null) { result.append(fixed); continue }
            val compound = when {
                token.startsWith("huszon") -> 20 to token.removePrefix("huszon")
                token.startsWith("tizen") -> 10 to token.removePrefix("tizen")
                else -> null
            }
            if (compound != null && singles.containsKey(compound.second)) {
                result.append(compound.first + singles.getValue(compound.second).toInt())
            } else return null
        }
        return result.toString().takeIf { it.isNotEmpty() }
    }

    private fun postal(value: String): String {
        val cleaned = clean(value)
        val digitsWithSpaces = cleaned.replace(" ", "")
        return if (digitsWithSpaces.matches(Regex("\\d{4}"))) digitsWithSpaces else cleaned
    }
}

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "hu.digitalis.alairas"
    compileSdk = 36

    defaultConfig {
        applicationId = "hu.digitalis.alairas.v13"
        minSdk = 31 // Android 12+, helyi felismerés és külön jóváhagyott rendszerfelismerő
        targetSdk = 35
        versionCode = 15
        versionName = "1.13"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildTypes { release { isMinifyEnabled = false } }
}

// Nincs analitikai/reklám SDK, INTERNET jogosultság vagy automatikus
// felhőkapcsolat. A két alábbi nyílt könyvtár csak helyi fájlkészítést
// és biztonságos Android-megosztást biztosít.

// Az Android FileProvider biztonságos content:// csatolmányt ad a megosztáshoz.
// A Zip4j AES-256 titkosítású ZIP-et készít; semmi nem kerül felhőbe automatikusan.
dependencies {
    implementation("androidx.core:core:1.17.0")
    implementation("net.lingala.zip4j:zip4j:2.11.6")
}

package hu.digitalis.alairas

import java.text.Normalizer
import java.util.Locale

/**
 * Szabályalapú, teljesen helyi magyar adatlap-szétválasztás.
 * Nem tanul be személyes adatot, nem küld semmit hálózatra, és NEM ment automatikusan.
 * A hiányzó / bizonytalan részeket szerkeszthető előnézetként, figyelmeztetéssel adja vissza.
 */
data class DictatedSignerFields(
    val name: String = "",
    val email: String = "",
    val phone: String = "",
    val postal: String = "",
    val city: String = "",
    val street: String = "",
    val warnings: List<String> = emptyList()
) {
    fun isEmpty(): Boolean = listOf(name, email, phone, postal, city, street).all { it.isBlank() }

    fun summary(): String = buildString {
        appendLine("Név: ${name.ifBlank { "—" }}")
        appendLine("Irányítószám: ${postal.ifBlank { "—" }}")
        appendLine("Település: ${city.ifBlank { "—" }}")
        appendLine("Utca, házszám: ${street.ifBlank { "—" }}")
        appendLine("Telefon: ${phone.ifBlank { "—" }}")
        appendLine("E-mail: ${email.ifBlank { "—" }}")
        if (warnings.isNotEmpty()) {
            appendLine()
            appendLine("Ellenőrizendő:")
            warnings.forEach { appendLine("• $it") }
        }
    }.trim()
}

object HungarianFullDictation {
    private val locale = Locale.forLanguageTag("hu-HU")
    private val whites = Regex("\\s+")
    private val markers = Regex(
        "(?iu)(?<![\\p{L}\\p{N}])(?:az?\\s+)?" +
            "(e-?mail(?:\\s*[- ]?\\s*címem|\\s+cím|\\s*[- ]?\\s*cím)|emailcímem|" +
            "ímélem|ímélcímem|villanypostacímem|" +
            "telefonszámom|telefonszám|mobiltelefonszámom|mobilom|telefonom|" +
            "irányítószámom|irányítószám|postai\\s+irányítószám|" +
            "lakcímem|lakcím|lakhelyem|címem|" +
            "településem|település|városom|város|" +
            "nevem|teljes\\s+nevem|név)\\b"
    )
    private val postalCode = Regex("(?<!\\d)[1-9]\\d{3}(?!\\d)")
    private val streetType = Regex("(?iu)(?<![\\p{L}])(utca|út|útja|körút|tér|köz|sor|sétány|fasor|park|dűlő|rakpart|tere)(?![\\p{L}])")
    private val emailPattern = Regex("(?i)^[a-z0-9._%+\\-]+@[a-z0-9.-]+\\.[a-z]{2,}$")
    private val spokenDigits = mapOf("nulla" to "0", "egy" to "1", "kettő" to "2", "két" to "2",
        "három" to "3", "négy" to "4", "öt" to "5", "hat" to "6", "hét" to "7", "nyolc" to "8", "kilenc" to "9")

    private fun typeOf(text: String): String {
        val t = text.lowercase(locale)
        return when {
            t.contains("mail") || t.contains("ímél") || t.contains("villanyposta") -> "email"
            t.contains("telefon") || t.contains("mobil") -> "phone"
            t.contains("irányítószám") -> "postal"
            t.contains("települ") || t.contains("város") -> "city"
            t.contains("lakcím") || t.contains("lakhely") || t.contains("címem") -> "address"
            else -> "name"
        }
    }

    private fun trimPart(s: String): String = s
        .trim(' ', ',', '.', ';', ':', '\n', '\t', '!')
        .replace(Regex("(?iu)^(?:az?\\s+)?(?:pedig\\s+|meg\\s+|és\\s+)+"), "")
        .replace(Regex("(?iu)\\s+(?:és|meg|köszönöm|ennyi)$"), "")
        .trim()

    /** A számjegyekként külön-külön kimondott irányítószámot is értelmezi. */
    private fun spokenPostal(value: String): String {
        val s = value.trim()
        val plain = s.replace(" ", "")
        if (plain.matches(Regex("[1-9]\\d{3}"))) return plain
        val words = s.lowercase(locale).split(whites)
        if (words.size == 4 && words.all { it in spokenDigits }) {
            val result = words.joinToString("") { spokenDigits.getValue(it) }
            if (result[0] != '0') return result
        }
        return s
    }

    /** Ékezetek nélküli, számjegyeket tartalmazó átlagos e-mail-címekre. */
    private fun spokenPhone(value: String): String {
        val text = trimPart(value)
        val tokens = text.lowercase(locale).replace(Regex("[,.();-]"), " ").split(whites)
        if (tokens.isEmpty() || tokens.none { it.any(Char::isLetter) }) return text
        val tens = mapOf("tíz" to "10", "húsz" to "20", "harminc" to "30",
            "negyven" to "40", "ötven" to "50", "hatvan" to "60",
            "hetven" to "70", "nyolcvan" to "80", "kilencven" to "90")
        val numbers = StringBuilder()
        for (token in tokens) {
            when {
                token == "plusz" && numbers.isEmpty() -> numbers.append('+')
                token.all(Char::isDigit) -> numbers.append(token)
                token in spokenDigits -> numbers.append(spokenDigits.getValue(token))
                token in tens -> numbers.append(tens.getValue(token))
                token == "harminchat" -> numbers.append("36")
                token.startsWith("huszon") && token.removePrefix("huszon") in spokenDigits ->
                    numbers.append(20 + spokenDigits.getValue(token.removePrefix("huszon")).toInt())
                token.startsWith("tizen") && token.removePrefix("tizen") in spokenDigits ->
                    numbers.append(10 + spokenDigits.getValue(token.removePrefix("tizen")).toInt())
                else -> return text // Ismeretlen szót nem értelmezünk találgatással.
            }
        }
        return numbers.toString()
    }

    private fun spokenEmail(value: String): String {
        var text = trimPart(value).lowercase(locale)
        val replacements = spokenDigits.entries.sortedByDescending { it.key.length }
        for ((word, digit) in replacements) {
            text = text.replace(Regex("(?iu)(?<![\\p{L}])${Regex.escape(word)}(?![\\p{L}])"), digit)
        }
        text = FieldFormatter.normalize(FieldFormatter.Kind.EMAIL, text)
        // Szokásos ASCII e-mail: ékezetet nem küldünk és nem találunk ki domainnevet.
        text = Normalizer.normalize(text, Normalizer.Form.NFD)
            .replace(Regex("\\p{M}+"), "")
        return text
    }

    fun parse(spokenText: String): DictatedSignerFields {
        val input = spokenText.replace(Regex("[\\r\\n]+"), " ").replace(whites, " ").trim()
        if (input.isEmpty()) return DictatedSignerFields(warnings = listOf("Nem érkezett felismerhető szöveg."))
        val matches = markers.findAll(input).toList()
        val values = linkedMapOf<String, String>()
        for (i in matches.indices) {
            val label = matches[i]
            val nextStart = matches.getOrNull(i + 1)?.range?.first ?: input.length
            val key = typeOf(label.value)
            val raw = trimPart(input.substring(label.range.last + 1, nextStart))
            if (raw.isNotBlank() && values[key].isNullOrBlank()) values[key] = raw
        }
        val warnings = mutableListOf<String>()
        val beginning = if (matches.isNotEmpty()) input.substring(0, matches[0].range.first) else input
        var rawName = values["name"].orEmpty()
        if (rawName.isBlank()) {
            rawName = Regex("(?iu)^\\s*(?:én\\s+)?([\\p{L}.'\\- ]{4,90}?)\\s+vagyok\\b")
                .find(beginning)?.groupValues?.get(1).orEmpty()
        }
        rawName = trimPart(rawName).replace(Regex("(?iu)\\s+vagyok$"), "")
        val name = FieldFormatter.normalize(FieldFormatter.Kind.NAME, rawName)
        var rawPostal = values["postal"].orEmpty()
        var rawCity = values["city"].orEmpty()
        var rawStreet = ""
        var address = values["address"].orEmpty()
        if (address.isNotBlank()) {
            val p = postalCode.find(address)
            if (p != null) {
                if (rawPostal.isBlank()) rawPostal = p.value
                address = (address.take(p.range.first) + " " + address.drop(p.range.last + 1)).trim()
            }
            address = address.trim(' ', ',', '.', ';')
            val road = streetType.find(address)
            if (road != null) {
                val head = address.substring(0, road.range.first).trim(' ', ',')
                val tail = address.substring(road.range.first).trim()
                val headWords = head.split(whites).filter { it.isNotBlank() }
                if (rawCity.isBlank() && headWords.size >= 2) {
                    rawCity = headWords.first()
                    rawStreet = headWords.drop(1).joinToString(" ") + " " + tail
                    if (headWords.size > 2)
                        warnings += "Többszavas településnév lehetséges; a cím felosztását ellenőrizze."
                } else if (rawCity.isBlank() && headWords.size == 1) {
                    // Pl. „Fő út 12” → csak utca; a települést nem találjuk ki.
                    rawStreet = "$head $tail"
                } else {
                    rawStreet = (head + " " + tail).trim()
                }
            } else {
                // Utcanév nélküli címrész: nem tippeljük meg automatikusan a települést.
                rawStreet = address
                warnings += "A lakcím nem tartalmaz egyértelmű közterület-jelölést; ellenőrizze."
            }
        }
        val postal = FieldFormatter.normalize(FieldFormatter.Kind.POSTAL, spokenPostal(rawPostal))
        val city = FieldFormatter.normalize(FieldFormatter.Kind.CITY, rawCity)
        val street = FieldFormatter.normalize(FieldFormatter.Kind.ADDRESS, rawStreet)
        val phone = FieldFormatter.normalize(FieldFormatter.Kind.PHONE, spokenPhone(values["phone"].orEmpty()))
        val email = spokenEmail(values["email"].orEmpty())
        if (phone.isNotBlank() && !FieldFormatter.validPhone(phone)) warnings += "A telefonszám hosszát vagy előhívóját ellenőrizze."
        if (email.isNotBlank() && !emailPattern.matches(email)) warnings += "Az e-mail-cím formátuma ellenőrzést igényel."
        if (name.isBlank()) warnings += "A név nem volt egyértelmű; diktálja külön vagy írja be."
        if (listOf(postal, city, street).any { it.isBlank() }) warnings += "A cím egy vagy több mezője hiányzik; egészítse ki kézzel."
        if (phone.isBlank()) warnings += "Telefonszám nem volt felismerhető."
        if (email.isBlank()) warnings += "E-mail-cím nem volt felismerhető."
        return DictatedSignerFields(name, email, phone, postal, city, street, warnings)
    }
}
